const { Client: Client6 } = require('es6');
const { Client: Client7 } = require('es7');

const clientV6 = new Client6({
  node: process.env.es_url || 'http://localhost:9200',
});

const clientV7 = new Client7({
  node: process.env.es_url_v7 || 'http://localhost:9300',
});

const wrapper6 = (method, params) => {
  return clientV6[method](params);
};

const wrapper7 = (method, params) => {
  return clientV7[method](params);
};

const es6 = {
  search: (params) => {
    return wrapper6('search', params);
  },
  update: (params) => {
    return wrapper6('update', params);
  },
  updateByQuery: (params) => {
    return wrapper6('updateByQuery', params);
  },
  index: (params) => {
    return wrapper6('index', params);
  },
};

const es7 = {
  search: (params) => {
    return wrapper7('search', params);
  },
  update: (params) => {
    return wrapper7('update', params);
  },
  updateByQuery: (params) => {
    return wrapper7('updateByQuery', params);
  },
  index: (params) => {
    return wrapper7('index', params);
  },
};

module.exports = { es6: es6, es7: es7 };
