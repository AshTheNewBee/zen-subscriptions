const { es7 } = require('../../esclient');
module.exports = {
  updateByQueryFeatureData: (options) => {
    const query = {
      query: {
        match: {
          'properties.ExternalId': options.attributes.ExternalId,
        },
      },
      script: {
        inline:
          'ctx._source.properties = params.properties; ctx._source.geometry.coordinates = params.coordinates',
        params: {
          properties: options.attributes,
          coordinates: [options.geometry.x, options.geometry.y],
        },
      },
    };

    return es7
      .updateByQuery({
        index: options.index,
        type: 'doc',
        body: query,
        refresh: true,
      })
      .then((results) => {
        return results.body.updated > 0
          ? {
              result: results.body,
            }
          : {
              result: null,
            };
      })
      .catch((error) => {
        return error.body;
      });
  },

  insertFeatureData: (options) => {
    const query = {
      type: 'Feature',
      geometry: {
        type: 'Point',
        coordinates: [options.geometry.x, options.geometry.y],
      },
      properties: options.attributes,
    };
    return es7
      .index({
        index: options.index,
        body: query,
      })
      .then((results) => {
        return results.body;
      })
      .catch((error) => {
        return error.body;
      });
  },

  updateFeatureData: (options) => {
    const query = {
      script: {
        inline:
          'ctx._source.properties = params.properties; ctx._source.geometry.coordinates = params.coordinates',
        params: {
          properties: options.attributes,
          coordinates: [options.geometry.x, options.geometry.y],
        },
      },
    };

    return es7
      .update({
        index: options.index,
        id: options.id,
        body: query,
        refresh: true,
      })
      .then((results) => {
        return results.body;
      })
      .catch((error) => {
        return error.body;
      });
  },
};
