const { es7 } = require('../../esclient');

module.exports = {
  searchGeoDistance: (options) => {
    const lat = parseFloat(options.latitude);
    const lon = parseFloat(options.longitude);
    const query = {
      _source: ['geometry.coordinates', 'properties.*'],
      query: {
        bool: {
          must: [
            {
              match_all: {},
            },
          ],
          must_not: [
            {
              match: {
                'properties.Status': 'Inactive',
              },
            },
          ],
          filter: {
            geo_distance: {
              distance: options.radius + 'km',
              'geometry.coordinates': {
                lat: lat,
                lon: lon,
              },
            },
          },
        },
      },
      sort: {
        _geo_distance: {
          order: 'asc',
          'geometry.coordinates': {
            lat: lat,
            lon: lon,
          },
        },
      },
      size: options.size,
      from: options.from,
    };

    return es7
      .search({
        index: options.index,
        body: query,
      })
      .then((results) => {
        return results.body.hits.total.value > 0
          ? {
              result: results.body,
            }
          : {
              result: null,
            };
      })
      .catch((error) => {
        throw Error(error);
      });
  },

  searchByPostcode: (options) => {
    const lat = parseFloat(options.latitude);
    const lon = parseFloat(options.longitude);
    const query = {
      _source: ['geometry.coordinates', 'properties.*'],
      query: {
        bool: {
          must: {
            match: {
              'properties.postcodes_allocated': options.postcode,
            },
          },
        },
      },
      sort: [
        {
          'properties.store_type_code': {
            order: 'asc',
          },
        },
        {
          _geo_distance: {
            order: 'asc',
            'geometry.coordinates': {
              lat: lat,
              lon: lon,
            },
          },
        },
      ],

      size: options.size,
      from: options.from,
    };

    return es7
      .search({
        index: options.index,
        body: query,
      })
      .then((results) => {
        return results.body.hits.total.value > 0
          ? {
              result: results.body,
            }
          : {
              result: null,
            };
      })
      .catch((error) => {
        throw Error(error);
      });
  },

  searchGeoBoundingBox: (options) => {
    const top = parseFloat(options.top);
    const left = parseFloat(options.left);
    const bottom = parseFloat(options.bottom);
    const right = parseFloat(options.right);

    let query = {
      _source: ['geometry.coordinates', 'properties.*'],
      query: {
        bool: {
          must: [
            {
              match_all: {},
            },
          ],
          must_not: [
            {
              match: {
                'properties.Status': 'Inactive',
              },
            },
          ],
          filter: {
            geo_bounding_box: {
              'geometry.coordinates': {
                top: top,
                left: left,
                bottom: bottom,
                right: right,
              },
            },
          },
        },
      },
      size: options.size,
      from: options.from,
    };

    let queryAgg = {
      query: {
        bool: {
          must: [
            {
              match_all: {},
            },
          ],
          must_not: [
            {
              match: {
                'properties.Status': 'Inactive',
              },
            },
          ],
        },
      },
      aggregations: {
        'zoomed-in': {
          filter: {
            geo_bounding_box: {
              'geometry.coordinates': {
                top: top,
                left: left,
                bottom: bottom,
                right: right,
              },
            },
          },
          aggregations: {
            zoom1: {
              geotile_grid: {
                field: 'geometry.coordinates',
                precision: options.zoom,
              },
              aggregations: {
                centroid: {
                  geo_centroid: {
                    field: 'geometry.coordinates',
                  },
                },
              },
            },
          },
        },
      },
    };

    if (options.latitude && options.longitude) {
      const lat = parseFloat(options.latitude);
      const lon = parseFloat(options.longitude);

      query.sort = {
        _geo_distance: {
          order: 'asc',
          'geometry.coordinates': {
            lat: lat,
            lon: lon,
          },
        },
      };
    }

    return es7
      .search({
        index: options.index,
        body: options.zoom ? queryAgg : query,
      })
      .then((results) => {
        return results.body.hits.total.value > 0
          ? {
              result: results.body,
            }
          : {
              result: null,
            };
      })
      .catch((error) => {
        throw Error(error);
      });
  },

  searchQuery: (options) => {
    const query = {
      size: 1,
      _source: ['properties.*', 'geometry.coordinates'],
      query: {
        bool: {
          must: [
            {
              match: {
                ['properties.' + options.key + '.keyword']:
                  options.attributes[options.key],
              },
            },
          ],
        },
      },
      sort: [
        {
          'properties.created_date': {
            order: 'asc',
          },
        },
        {
          'properties.last_edited_date': {
            order: 'desc',
          },
        },
      ],
    };
    return es7
      .search({
        index: options.index,
        body: query,
      })
      .then((results) => {
        return results.body.hits;
      })
      .catch((error) => {
        throw Error(error);
      });
  },

  stringSearchQuery: (options) => {
    const query = {
      // _source: options.source,
      query: {
        match: {
          [`${options.field}.keyword`]: options.value,
        },
      },
    };
    return es7
      .search({
        index: options.index,
        body: query,
        //filter_path: [options.filter_path],
      })
      .then((results) => {
        return results.body.hits.hits;
      })
      .catch((error) => {
        throw Error(error);
      });
  },

  getAllHits: (options) => {
    const query = {
      size: options.size,
      from: options.from,
      _source: options.source,
      query: {
        bool: {
          must: [
            {
              match: {
                'properties.status': 'Active',
              },
            },
          ],
        },
      },
    };
    options.subquery &&
      query.query.bool.must.push({
        match: {
          [options.subquery.key + '.keyword']: options.subquery.value,
        },
      });

    return es7
      .search({
        index: options.index,
        body: query,
        filter_path: [options.filter_path],
      })
      .then((results) => {
        return results.body.hits.hits;
      })
      .catch((error) => {
        throw Error(error);
      });
  },
};
