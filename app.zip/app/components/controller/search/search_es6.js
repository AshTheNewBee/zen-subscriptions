const { es6 } = require('../../esclient');

module.exports = {
  searchGeoShape: (options) => {
    // get lat and lon from request and set in query
    const lat = parseFloat(options.latitude);
    const lon = parseFloat(options.longitude);
    // flag for nearby 5g lookup
    const query = options.nearbyLookup
      ? {
          query: {
            geo_shape: {
              geometry: {
                shape: {
                  type: 'circle',
                  radius: '1km',
                  coordinates: [lon, lat],
                },
              },
            },
          },
        }
      : {
          query: {
            bool: {
              must: {
                match_all: {},
              },
              filter: {
                geo_shape: {
                  geometry: {
                    relation: 'contains',
                    shape: {
                      type: 'point',
                      coordinates: [lon, lat],
                    },
                  },
                },
              },
            },
          },
        };

    // make es.search to search and return response based on the results
    return es6
      .search({
        index: options.index,
        body: query,
      })
      .then((results) => {
        return results.body.hits.total > 0
          ? {
              result: results.body,
            }
          : {
              result: null,
            };
      })
      .catch((error) => {
        throw Error(error);
      });
  },

  stringSearchQuery: (options) => {
    const query = {
      _source: options.source,
      query: {
        bool: {
          must: [
            {
              match: {
                [options.key]: options.value,
              },
            },
          ],
        },
      },
    };
    return es6
      .search({
        index: options.index,
        body: query,
        filter_path: [options.filter_path],
      })
      .then((results) => {
        return results.body.hits.hits;
      })
      .catch((error) => {
        throw Error(error);
      });
  },

  getDisclaimerText: (options) => {
    const query = {
      query: {
        match: {
          [options.key]: options.value,
        },
      },
    };
    return es6
      .search({
        index: options.index,
        body: query,
      })
      .then((results) => {
        return results.body.hits.hits;
      })
      .catch((error) => {
        throw Error(error);
      });
  },
};
