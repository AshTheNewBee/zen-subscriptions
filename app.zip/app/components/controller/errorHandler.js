// class ServerError extends Error {
//   constructor(message, cause) {
//     super(message);
//     this.cause = cause;
//     this.name = 'ServerError';
//   }
// }

const handleError = (res, statusCode, message) => {
  res.status(statusCode).json({
    status: 'error',
    statusCode,
    message,
  });
};

module.exports = {
  handleError,
};
