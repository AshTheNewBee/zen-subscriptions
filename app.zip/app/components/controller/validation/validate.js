const isValidCoordinates = require('is-valid-coordinates');
const Coordinates = require('coordinate-parser');

//Homespot update use only
async function validateCoordinates(longitude, latitude) {
  try {
    if (latitude != null && longitude != null) {
      const lat = parseFloat(latitude);
      const lon = parseFloat(longitude);
      if (isValidCoordinates(lon, lat)) {
        return true;
      } else {
        throw Error('Invalid coordinates');
      }
    } else {
      throw Error('Invalid coordinates');
    }
  } catch (error) {
    throw Error('Invalid coordinates');
  }
}

async function getValidCoordinates(longitude, latitude) {
  try {
    let coordinates = new Coordinates(latitude + ', ' + longitude);
    if (
      isValidCoordinates(coordinates.getLongitude(), coordinates.getLatitude())
    ) {
      return coordinates;
    } else {
      throw Error('Invalid coordinates');
    }
  } catch (error) {
    throw Error('Invalid coordinates');
  }
}

module.exports = {
  validateCoordinates,
  getValidCoordinates,
};
