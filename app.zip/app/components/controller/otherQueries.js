// components/search.js

const { sqs } = require('./awsclient');
const { sqsUrl } = require('./consts');

module.exports = {
  sendMessageToQueue: (options, action) => {
    return new Promise((resolve, reject) => {
      try {
        if (!process.env.PLATFORM && !sqsUrl) {
          resolve({});
        } else {
          options.geometry.spatialReference = {
            wkid: 4326,
          };
          delete options.index;
          const body = [];
          body.push(options);
          const params = {
            MessageBody: JSON.stringify(body),
            MessageAttributes: {
              action: {
                DataType: 'String',
                StringValue: action,
              },
            },
            QueueUrl: sqsUrl,
          };
          sqs.sendMessage(params, (err, data) => {
            if (err) {
              console.log('Error ocuured while sending message to SQS');
              console.error(err);
              reject(err);
            } else {
              resolve(data);
            }
          });
        }
      } catch (err) {
        console.log('Error ocuured in SQS');
        console.error(err);
        reject(err);
      }
    });
  },
};
