const validator = require('validator');
const { searchGeoShape, getDisclaimerText } = require('../search/search_es6');

const {
  searchGeoDistance,
  searchGeoBoundingBox,
  stringSearchQuery,
  searchByPostcode,
} = require('../search/search_es7');

const { searchQuery, getAllHits } = require('../search/search_es7');
const { getValidCoordinates } = require('../validation/validate');

const { handleError } = require('../errorHandler');

const findSearch = async (searchType, options) => {
  switch (searchType) {
    case 'searchGeoShape':
      return await searchGeoShape(options);
    case 'searchGeoDistance':
      return await searchGeoDistance(options);
    case 'searchQuery':
      return await searchQuery(options);
    case 'searchGeoBoundingBox':
      return await searchGeoBoundingBox(options);
    case 'getAllHits':
      return await getAllHits(options);
    case 'stringSearchQuery':
      return await stringSearchQuery(options);
    case 'searchByPostcode':
      return await searchByPostcode(options);
    case 'getDisclaimerText':
      console.log('findSearch.....');
      return await getDisclaimerText(options);
  }
};

async function searchES(options, searchType) {
  try {
    return await findSearch(searchType, options);
  } catch (error) {
    throw Error(error.message);
  }
}

function getGenericCovResponse(response, res, servicename) {
  if (response.error) {
    handleError(res, 500, `Unable to fetch ${servicename} data`);
  } else if (response.result) {
    return true;
  } else {
    return false;
  }
}

async function returnValidCoordinates(res, longitude, latitude) {
  try {
    const coordinates = await getValidCoordinates(longitude, latitude);
    const options = {
      latitude: coordinates.getLatitude(),
      longitude: coordinates.getLongitude(),
    };
    return options;
  } catch (error) {
    throw Error(error.message);
  }
}

async function validateExtentCoordinates(req, res) {
  let validateTopLeft = await getValidCoordinates(
    req.body.extent.left,
    req.body.extent.top
  );

  let validateBottomRight = await getValidCoordinates(
    req.body.extent.right,
    req.body.extent.bottom
  );

  let validateCenter =
    req.body.center &&
    req.body.center.lon &&
    req.body.center.lat &&
    (await getValidCoordinates(req.body.center.lon, req.body.center.lat));

  return Promise.all([
    validateTopLeft,
    validateBottomRight,
    validateCenter,
  ]).catch((error) => {
    throw Error(error.message);
  });
}

function getPagination(req, options, maxVal = 100, defaultVal = 5) {
  options.size =
    req.body.pagination &&
    validator.isInt(req.body.pagination.size.toString(), { max: maxVal })
      ? req.body.pagination.size.toString()
      : defaultVal;
  options.from =
    req.body.pagination &&
    req.body.pagination.from &&
    validator.isInt(req.body.pagination.from.toString())
      ? req.body.pagination.from.toString()
      : 0;
  options.view =
    req.body.view && req.body.view === 'internal' ? 'internal' : '';
  return options;
}

module.exports = {
  searchES,
  getGenericCovResponse,
  returnValidCoordinates,
  validateExtentCoordinates,
  getPagination,
};
