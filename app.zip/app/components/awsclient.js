// components/awsclient.js

const aws = require('aws-sdk');

const awsConfig = {
  region: 'ap-southeast-2',
};

aws.config.update(awsConfig);
const sqs = new aws.SQS();

module.exports = {
  sqs,
};
