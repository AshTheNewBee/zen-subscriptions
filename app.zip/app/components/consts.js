const resInternet4gfw = {
  results: [
    {
      paramName: 'result',
      dataType: 'gpArray',
      value: [
        {
          serviceType: { voice: true, data: true },
          technology: '4GFW',
          antennaRequired: false,
          coverage: false,
        },
      ],
    },
  ],
  messages: [],
};

const resSmartModem = {
  results: [
    {
      paramName: 'result',
      dataType: 'gpString',
      value: false,
    },
  ],
  messages: [],
};

const resMobileCoverage = {
  results: [
    {
      paramName: 'result',
      dataType: 'gpMap',
      value: {},
    },
  ],
  messages: [],
};

const resNBNCoverage = {
  results: [
    {
      paramName: 'result',
      dataType: 'gpArray',
      value: [
        {
          techType: '',
          status: '',
          deliveryType: '',
          rfsDate: '',
        },
      ],
    },
  ],
  messages: [],
};

const resFeatureList = {
  results: [
    {
      paramName: 'result',
      dataType: 'gpArray',
      value: [],
    },
  ],
  messages: [],
};

const resUpdateFeature = {
  results: [
    {
      action: '',
      success: '',
      globalId: '',
    },
  ],
  messages: [],
};

const resCoverageDiclaimer = {
  results: [
    {
      paramName: 'result',
      dataType: 'gpMap',
      value: {
        disclaimer: {},
      },
    },
  ],
  messages: [],
};

const resTG = {
  results: [
    {
      paramName: 'result',
      dataType: 'gpArray',
      value: [],
    },
  ],
  messages: [],
};

const resCable = {
  results: [
    {
      paramName: 'result',
      dataType: 'type',
      value: [
        {
          lines: [],
          network: '',
        },
      ],
    },
  ],
  messages: [],
};

// Whitelist for GPservice, unstructured address, Map-UI, Telstra Where v2 and v3
const whitelist = [
  'http://localhost:3000',
  'http://localhost:3001',
  'http://localhost:63342',
  'http://localhost:4502',
  'http://localhost:5000',
  'https://dev-tools-gcm.sdpamp.com',
  'https://test-tools-gcm.sdpamp.com',
  'https://dev-maps.gcm.telstra.com.au',
  'https://test-maps.gcm.telstra.com.au',
  'https://maps.gcm.telstra.com.au',
  'https://tools.gcm.telstra.com.au',
  'http://lxapp7040.dc.corp.telstra.com:8345',
  'https://onesource.in.telstra.com.au',
  'https://onesource.inside.telstra.com',
  'https://onesource-prodsupport.in.telstra.com.au',
  'https://cat.in.telstra.com.au',
  'https://retail.cat.in.telstra.com.au',
  'https://retail.cat.telstra.com.au',
  'https://v.author.tcom.corp.telstra.com',
  'https://publish.tcom.corp.telstra.com',
  'https://telstra.com',
  'https://dev.aem.telstra.com.au',
  'https://test.aem.telstra.com.au',
  'https://stage.aem.telstra.net',
  'https://aem.telstra.com.au',
  'https://stage.telstra.com.au',
  'https://author.dev.aem.telstra.com.au',
  'https://author.test.aem.telstra.com.au',
  'https://author.aem.telstra.com.au',
  'https://www.telstra.com.au',
  'https://fn1.my.np.in.telstra.com.au',
  'https://staging.my.telstra.com.au',
  'https://myservices.telstra.com.au',
  'https://www.myservices.telstra.com.au',
  'https://nbnplusdev1.service-now.com',
  'https://nbnplusdev4.service-now.com',
  'https://nbnplussit.service-now.com',
  'https://nbnplustest.service-now.com',
  'http://nbnplusvt.service-now.com',
  'http://nbnpluspreprod.service-now.com',
  'https://bcdev.service-now.com',
  'https://businesscontentsit.service-now.com',
  'https://businesstraining.service-now.com',
  'https://nbnplus.service-now.com',
  'https://staging5.boost.com.au',
  'https://staging6.boost.com.au',
  'https://boost.com.au',
  'https://pre-prod.lanes.telstra.com',
  'https://pre-prod.lanes.in.telstra.com.au',
  'https://lanes.telstra.com',
  'https://lanes.in.telstra.com.au',
  'https://author.telstrawholesale.com.au',
  'https://www.telstrawholesale.com.au',
  'https://mobilemaps.net.au',
  'https://b2cdev61-telstra-retail.cs137.force.com',
  'https://b2cdev61-telstra-retail.cs151.force.com',
  'https://b2cdev08-telstra-retail.cs115.force.com',
  'https://b2csit02-telstra-retail.cs151.force.com',
  'https://b2csqi26-telstra-retail.cs115.force.com',
  'https://b2csqi29-telstra-retail.cs116.force.com',
  'https://b2csqi12-telstra-retail.cs115.force.com',
  'https://b2csitnew-telstra-retail.cs115.force.com',
  'https://b2cprodsup-telstra-retail.cs115.force.com',
  'https://communities.inside.telstra.com',
  'https://rdmub58255.stage.lithium.com',
  'https://crowdsupport.telstra.com.au',
  'https://telstra-retail--gotham0122.lightning.force.com',
  'https://telstra-retail--gotham0122.my.salesforce.com',
  'https://telstra-retail--gotham0122--c.visualforce.com',
  'https://telstra-retail--gotham0823.lightning.force.com',
  'https://telstra-retail--gotham0823.my.salesforce.com',
  'https://telstra-retail--gotham0823--c.visualforce.com',
  'https://telstra-retail--gotham1524.lightning.force.com',
  'https://telstra-retail--gotham1524.my.salesforce.com',
  'https://telstra-retail--gotham1524--c.visualforce.com',
  'https://telstra-retail--gotham2225.lightning.force.com',
  'https://telstra-retail--gotham2225.my.salesforce.com',
  'https://telstra-retail--gotham2225--c.visualforce.com',
  'https://telstra-retail--gotham2521.lightning.force.com',
  'https://telstra-retail--gotham2521.my.salesforce.com',
  'https://telstra-retail--gotham2521--c.visualforce.com',
  'https://telstra-retail--gotham2926.lightning.force.com',
  'https://telstra-retail--gotham2926.my.salesforce.com',
  'https://telstra-retail--gotham2926--c.visualforce.com',
  'https://telstra-retail--b2ccsbsqi1.lightning.force.com',
  'https://telstra-retail--b2ccsbsqi1.my.salesforce.com',
  'https://telstra-retail--b2ccsbsqi1--c.cs115.visual.force.com',
  'https://telstra-retail--b2ccsbsqi1--c.visualforce.com',
  'https://telstra-retail--b2cprodsup.lightning.force.com',
  'https://telstra-retail--b2cprodsup.my.salesforce.com',
  'https://telstra-retail--b2cprodsup--c.cs115.visual.force.com',
  'https://telstra-retail--b2cprodsup--c.visualforce.com',
  'https://telstra-retail--b2csitnew.lightning.force.com',
  'https://telstra-retail--b2csitnew.my.salesforce.com',
  'https://telstra-retail--b2csitnew--c.cs115.visual.force.com',
  'https://telstra-retail--b2csitnew--c.visualforce.com',
  'https://telstra-retail--datamask--c.cs116.visual.force.com',
  'https://telstra-retail.lightning.force.com',
  'https://telstra-retail.my.salesforce.com',
  'https://telstra-retail.visualforce.com',
  'https://telstra-retail--c.ap22.visual.force.com',
  'https://telstra-retail--c.visualforce.com',
];

module.exports = {
  whitelist: whitelist,
  serviceUrl: '/services/gpservice',
  sqsUrl: process.env.sqs_url || '',
  resInternet4gfw: resInternet4gfw,
  resSmartModem: resSmartModem,
  resMobileCoverage: resMobileCoverage,
  resNBNCoverage: resNBNCoverage,
  resFeatureList: resFeatureList,
  resUpdateFeature: resUpdateFeature,
  resCoverageDiclaimer: resCoverageDiclaimer,
  resTG: resTG,
  resCable: resCable,
};
