// routes/index.js
const v1_internet_4gfw = require('./v1/internet/4gfw'); // 4G Fixed Wireless SQ
const v1_internet_smartmodem = require('./v1/internet/smartmodem'); // Smart Modem SQ

const {
  v1_mobile_coverage,
  v1_mobile_coveragePost,
} = require('./v1/mobile/coverage'); // Inbuilding & Device Only detailed coverage SQ

const v1_nbn_coverage = require('./v1/nbn/coverage'); // NBN Service Availability
const {v1_wholesale_coverage} = require('./v1/wholesale/coverage'); // Wholesale Coverage Details

const v1_telstra_air = require('./v1/telstra/air'); // Telstra Air nearby public hotspots List
const v1_telstra_shops = require('./v1/telstra/shops'); // Telstra Shops nearby store List
const v1_telstra_business_centres = require('./v1/telstra/businesscentres'); // Telstra Business Centres nearby store List

const v1_feature_update_air_private = require('./v1/feature/update/homespot');

const v1_auth_mapui = require('./v1/auth/mapui');

const v1_coverage_disclaimer = require('./v1/coverage/disclaimer');

const v1_telstraGlobal_features = require('./v1/telstraglobal/features');

module.exports = function (app) {
  v1_internet_4gfw(app);
  v1_internet_smartmodem(app);

  v1_mobile_coverage(app);
  v1_mobile_coveragePost(app);

  v1_wholesale_coverage(app);
  v1_nbn_coverage(app);

  v1_telstra_air.topHotspots(app);
  v1_telstra_air.telstraAirHotspotList(app);
  v1_telstra_air.telstraAirMap(app);

  v1_telstra_shops.topTelstraShops(app);
  v1_telstra_shops.telstraShopsList(app);
  v1_telstra_shops.telstraShopsMap(app);
  v1_telstra_shops.telstraShopDetails(app);

  v1_telstra_business_centres.telstraBusinessCentresList(app);
  v1_telstra_business_centres.telstraBusinessCentresMap(app);
  v1_telstra_business_centres.telstraBusinesscentresDetails(app);

  v1_feature_update_air_private(app);

  v1_auth_mapui(app);
  v1_coverage_disclaimer(app);

  v1_telstraGlobal_features(app);
};
