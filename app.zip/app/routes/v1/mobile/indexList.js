const indexList = [
  { name: '5G', type: 'outdoor', index: ['mobile_5g_hh'] },
  { name: '5G', type: 'indoor', index: ['mobile_5g_ibc'] },
  { name: '5G', type: 'extAntenna', index: [] },
  { name: '5G', type: 'outdoorFuture', index: ['mobile_5g_future'] },
  { name: '5G', type: 'outdoorNearby', index: ['mobile_5g_hh'] },

  { name: '4G', type: 'outdoor', index: ['speedmaps_4gx_int', 'lte_int'] },
  { name: '4G', type: 'indoor', index: ['speedmaps_4gx_ibc', 'lte_ibc'] },
  { name: '4G', type: 'extAntenna', index: ['speedmaps_4gx_ext', 'lte_ext'] },
  { name: '4G', type: 'outdoorFuture', index: ['speedmaps_4gx_future'] },

  { name: '4GX', type: 'outdoor', index: ['speedmaps_4gx_int'] },
  { name: '4GX', type: 'indoor', index: ['speedmaps_4gx_ibc'] },
  { name: '4GX', type: 'extAntenna', index: ['speedmaps_4gx_ext'] },
  { name: '4GX', type: 'outdoorFuture', index: ['speedmaps_4gx_future'] },

  { name: 'LTE', type: 'outdoor', index: ['lte_int'] },
  { name: 'LTE', type: 'indoor', index: ['lte_ibc'] },
  { name: 'LTE', type: 'extAntenna', index: ['lte_ext'] },
  { name: 'LTE', type: 'outdoorFuture', index: [] },

  { name: '3G', type: 'outdoor', index: ['nextg_hh', 'christmas_island_hh'] },
  { name: '3G', type: 'indoor', index: ['nextg_ibc'] },
  {
    name: '3G',
    type: 'extAntenna',
    index: ['nextg_ck', 'christmas_island_ck'],
  },
  { name: '3G', type: 'outdoorFuture', index: ['nextg_hh_future'] },
];

const indexListACT2 = [
  { name: '5G', type: 'outdoor', index: ['retail_5g_hh'] },
  { name: '5G', type: 'indoor', index: ['retail_5g_ib'] },
  { name: '5G', type: 'extAntenna', index: [] },
  { name: '5G', type: 'outdoorFuture', index: ['future_5g_hh'] },
  { name: '5G', type: 'outdoorNearby', index: ['retail_5g_hh'] },

  {
    name: '4G',
    type: 'outdoor',
    index: ['retail_4g_hh_700', 'retail_4g_hh_1800'],
  },
  {
    name: '4G',
    type: 'indoor',
    index: ['retail_4g_ib_700', 'retail_4g_ib_1800'],
  },
  {
    name: '4G',
    type: 'extAntenna',
    index: ['retail_4g_ea_700', 'retail_4g_ea_1800'],
  },
  { name: '4G', type: 'outdoorFuture', index: ['future_4g_hh_700'] },

  { name: '4GX', type: 'outdoor', index: ['retail_4g_hh_700'] },
  { name: '4GX', type: 'indoor', index: ['retail_4g_ib_700'] },
  { name: '4GX', type: 'extAntenna', index: ['retail_4g_ea_700'] },
  { name: '4GX', type: 'outdoorFuture', index: ['future_4g_hh_700'] },

  { name: 'LTE', type: 'outdoor', index: ['retail_4g_hh_1800'] },
  { name: 'LTE', type: 'indoor', index: ['retail_4g_ib_1800'] },
  { name: 'LTE', type: 'extAntenna', index: ['retail_4g_ea_1800'] },
  { name: 'LTE', type: 'outdoorFuture', index: [] },

  { name: '3G', type: 'outdoor', index: ['retail_3g_hh', 'retail_2g_hh'] },
  { name: '3G', type: 'indoor', index: ['retail_3g_ib'] },
  {
    name: '3G',
    type: 'extAntenna',
    index: ['retail_3g_ea', 'retail_2g_ea'],
  },
  { name: '3G', type: 'outdoorFuture', index: ['future_3g_hh'] },
];

module.exports = {
  indexList,
  indexListACT2,
};
