// routes/v1/mobile/coverage.js

const {
  getValidCoordinates,
} = require('../../../components/controller/validation/validate');
const { serviceUrl, resMobileCoverage } = require('../../../components/consts');
const {
  searchES,
  getGenericCovResponse,
} = require('../../../components/controller/helpers/helper');

const { handleError } = require('../../../components/controller/errorHandler');

const { indexListACT2, indexList } = require('./indexList');

module.exports = {
  v1_mobile_coverage: (app) => {
    app.get(serviceUrl + '/v1/mobile/coverage', (req, res) => {
      const config = {
        longitude: req.query.longitude,
        latitude: req.query.latitude,
        techTypes: '',
        internalView: true,
        excludeCovTypes: ['outdoorFuture', 'outdoorNearby'],
        legacy: true,
        useACT2Index: true,
      };
      sendResponse(config, req, res);
    });
  },

  v1_mobile_coveragePost: (app) => {
    app.post(serviceUrl + '/v1/mobile/coverage', (req, res) => {
      const config = {
        longitude: req.body.longitude,
        latitude: req.body.latitude,
        techTypes: req.body.techType,
        internalView: req.body.view && req.body.view === 'internal',
        excludeCovTypes: [
          req.body.extAntenna === undefined || req.body.extAntenna === true
            ? ''
            : 'extAntenna',
          req.body.futureCoverage === undefined ||
          req.body.futureCoverage === false
            ? 'outdoorFuture'
            : '',
          req.body.nearbyLookup === undefined || req.body.nearbyLookup === false
            ? 'outdoorNearby'
            : req.body.futureCoverage === undefined ||
              req.body.futureCoverage === false
            ? 'outdoorNearby'
            : '',
        ],
        useACT2Index: true,
      };
      sendResponse(config, req, res);
    });
  },
  getFilteredIndexArr,
};

function getFilteredIndexArr(config) {
  const defaultTechTypes = config.internalView
    ? ['5G', '4GX', 'LTE', '3G']
    : ['5G', '4G', '3G'];
  const filteredTechTypes = Array.isArray(config.techTypes)
    ? config.techTypes.filter((techType) => defaultTechTypes.includes(techType))
    : defaultTechTypes;

  const indexArray = config.useACT2Index ? indexListACT2 : indexList;
  return indexArray
    .filter((index) => filteredTechTypes.includes(index.name))
    .filter((index) => !config.excludeCovTypes.includes(index.type));
}

async function sendResponse(config, req, res) {
  const filteredIndexArr = getFilteredIndexArr(config);
  try {
    const coordinates = await getValidCoordinates(
      config.longitude,
      config.latitude
    ).catch((err) => handleError(res, 400, 'Invalid request parameters'));
    const options = {
      latitude: coordinates.getLatitude(),
      longitude: coordinates.getLongitude(),
    };
    await searchServices(res, options, filteredIndexArr)
      .then((result) => {
        if (config.legacy) {
          resMobileCoverage.results[0].value = result;
        } else {
          let coverageRes = {};
          Object.keys(result).forEach((key) => {
            coverageRes[key] = {
              indoor: { coverage: result[key].indoor },
              outdoor: { coverage: result[key].outdoor },
            };
            if (
              !config.excludeCovTypes.includes('extAntenna') &&
              (!result[key].indoor || !result[key].outdoor)
            ) {
              coverageRes[key].extAntenna = {
                coverage: result[key].extAntenna,
              };
            }
            if (
              !config.excludeCovTypes.includes('outdoorFuture') &&
              !result[key].outdoor
            ) {
              coverageRes[key].outdoor.future = result[key].outdoorFuture;
            }
            if (
              !config.excludeCovTypes.includes('outdoorNearby') &&
              !result[key].outdoor &&
              !result[key].outdoorFuture
            ) {
              coverageRes[key].outdoor.nearby = result[key].outdoorNearby;
            }
          });
          resMobileCoverage.results[0].value = coverageRes;
        }
        res.send(resMobileCoverage);
      })
      .catch((err) => handleError(res, 500, 'Unable to find mobile coverage'));
  } catch (error) {
    return error;
  }
}

async function searchServices(res, options, _indexList) {
  try {
    let resultObj = {};

    let promiseAll = await Promise.all(
      _indexList.map(async (layer) => {
        if (!resultObj[layer.name]) {
          resultObj[layer.name] = {
            outdoor: false,
            indoor: false,
          };
        }
        options.index = layer.index;
        options.nearbyLookup = layer.type === 'outdoorNearby' ? true : false;

        await searchIndex(res, options).then((response) => {
          resultObj[layer.name][layer.type] = response;
        });
      })
    )
      .then(() => {
        return resultObj;
      })
      .catch((error) => {
        handleError(res, 500, 'Unable to map mobile data');
      });
    return promiseAll;
  } catch (error) {
    handleError(res, 500, 'Unable to map mobile data');
  }
}

async function searchIndex(res, options) {
  if (Array.isArray(options.index) && options.index.length > 0) {
    const response = await searchES(options, 'searchGeoShape');

    return getGenericCovResponse(response, res, 'mobile');
  } else {
    return false;
  }
}
