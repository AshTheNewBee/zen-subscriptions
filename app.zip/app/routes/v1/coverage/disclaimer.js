// routes/coverage/disclaimer.js

const {
  serviceUrl,
  resCoverageDiclaimer,
} = require('../../../components/consts');

const {
  searchES,
  getGenericCovResponse,
} = require('../../../components/controller/helpers/helper');

const { handleError } = require('../../../components/controller/errorHandler');

const modes = [
  'mcm',
  'mobile',
  'nbn',
  'iot',
  'air',
  'shops',
  'twhere',
  'boost',
  'lanes',
  '4G',
  'wholesale',
];

module.exports = async function (app) {
  app.get(serviceUrl + '/v1/coverage/disclaimer', async (req, res) => {
    validateInputAndSearch(req, res);
  });
};

async function validateInputAndSearch(req, res) {
  try {
    if (modes.indexOf(req.query.mode) !== -1) {
      const options = {
        key: '_id',
        value: req.query.mode,
        index: 'disclaimer',
      };
      const response = await searchES(options, 'getDisclaimerText');
      if (response[0]._source.text) {
        resCoverageDiclaimer.results[0].value.disclaimer =
          response[0]._source.text;
        res.send(resCoverageDiclaimer);
      } else {
        handleError(res, 500, 'No Disclaimer data found');
      }
    } else {
      handleError(res, 400, 'invalid request');
    }
  } catch (error) {
    handleError(res, 500, 'Unable to fetch Disclaimer data');
  }
}
