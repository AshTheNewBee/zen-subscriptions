// routes/auth/mapui.js

const { serviceUrl, whitelist } = require('../../../components/consts');
const validator = require('validator');

const mapui_modes = [
  'mcm',
  'mobile',
  'nbn',
  'iot',
  'air',
  'shops',
  'twhere',
  'boost',
  'lanes',
  '4G',
  'tbc',
  'nwmap',
  'wholesale',
];

module.exports = function (app) {
  app.post(serviceUrl + '/v1/auth/mapui', (req, res) => {
    validateInputAndSearch(req, res);
  });
};

function validateInputAndSearch(req, res) {
  if (
    whitelist.indexOf(req.body.p1) !== -1 &&
    mapui_modes.indexOf(req.body.m1) !== -1
  ) {
    res.send(req.body);
  } else {
    res.status(400).json({ error: 'invalid request' });
  }
}
