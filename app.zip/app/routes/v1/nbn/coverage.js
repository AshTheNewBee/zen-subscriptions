// routes/v1/nbn/coverage.js

const {
  getValidCoordinates,
} = require('../../../components/controller/validation/validate');
const { serviceUrl, resNBNCoverage } = require('../../../components/consts');
const { searchES } = require('../../../components/controller/helpers/helper');

const { handleError } = require('../../../components/controller/errorHandler');

module.exports = async function (app) {
  app.get(serviceUrl + '/v1/nbn/coverage', async (req, res) => {
    sendResponse(req, res);
  });
};

async function sendResponse(req, res) {
  try {
    const coordinates = await getValidCoordinates(
      req.query.longitude,
      req.query.latitude
    );
    const options = {
      latitude: coordinates.getLatitude(),
      longitude: coordinates.getLongitude(),
    };
    const result = await searchServices(res, options, resNBNCoverage);
    res.send(result);
  } catch (error) {
    handleError(res, 400, 'Invalid request parameters');
  }
}

async function searchServices(res, options, apiResponse) {
  options.index = 'nbn_fixed_line,nbn_fixed_wireless';
  return await searchIndex(res, options)
    .then((response_nbn) => {
      if (response_nbn.result != null) {
        apiResponse.results[0].value[0].techType =
          response_nbn.result._source.properties.tech_type;
        apiResponse.results[0].value[0].status =
          response_nbn.result._source.properties.status;
        apiResponse.results[0].value[0].deliveryType =
          response_nbn.result._index.includes('nbn_fixed_line')
            ? 'Fixed Line'
            : 'Fixed Wireless';
        apiResponse.results[0].value[0].rfsDate =
          response_nbn.result._source.properties.rfs_date;
        return apiResponse;
      } else {
        apiResponse.results[0].value[0].techType = '';
        apiResponse.results[0].value[0].status = '';
        apiResponse.results[0].value[0].deliveryType = '';
        apiResponse.results[0].value[0].rfsDate = '';
        return apiResponse;
      }
    })
    .catch((error) => handleError(res, 500, 'Unable to fetch NBN data'));
}

async function searchIndex(res, options) {
  const response = await searchES(options, 'searchGeoShape');
  if (response.result !== null) {
    return { result: response.result.hits.hits[0] };
  } else {
    return { result: null };
  }
}
