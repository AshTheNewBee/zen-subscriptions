// routes/v1/telstra/air.js
const {
  searchQuery,
} = require('../../../../components/controller/search/search_es7');
const {
  validateCoordinates,
} = require('../../../../components/controller/validation/validate');
const {
  insertFeatureData,
  updateFeatureData,
} = require('../../../../components/controller/update/update');
const {
  serviceUrl,
  resUpdateFeature,
} = require('../../../../components/consts');
const validator = require('validator');
const moment = require('moment-timezone');
const { v4: uuidv4 } = require('uuid');
const uc = require('upper-case');

module.exports = function (app) {
  app.post(serviceUrl + '/v1/feature/update/homespot', (req, res) => {
    validateInputAndUpdate(req, res);
  });
};

function validateInputAndUpdate(req, res) {
  const fDate = moment().tz('Australia/Sydney').format('YYYY/MM/DD HH:mm:ss');

  const options =
    (req.body instanceof Array && req.body.length > 0 && req.body[0]) || {};

  // Check mandatory fields
  try {
    options.attributes = options.attributes || {};
    validator.isEmpty(options.attributes.ExternalId);
  } catch (error) {
    return res.status(400).json({ error: 'missing mandatory params' });
  }

  options.index = 'telstra_air_homespots';

  queryFeatureId(options)
    .then((response) => {
      // Set last edited user and date as hotspot will either added or updated
      options.attributes.last_edited_user = 'HotspotManagementAPI';
      options.attributes.last_edited_date = fDate;

      // Set empty point hash in case it is missing from body
      options.geometry = options.geometry || {};

      // Set geometry in options in case of existing hotspot but not sent in request for update
      if (response.geometry && !options.geometry.x && !options.geometry.y) {
        options.geometry.x = response.geometry.x;
        options.geometry.y = response.geometry.y;
      }

      // Validate Coordinates for add/update/delete with new value or update/delete with existing value
      validateCoordinates(options.geometry.x, options.geometry.y)
        .then(() => {
          if (response._id) {
            // add scenario
            options.id = response._id;
            options.attributes = {
              ...response.properties,
              ...options.attributes,
            };
            updateFeature(options)
              .then((result) => {
                resUpdateFeature.results[0].action = 'update';
                resUpdateFeature.results[0].success = true;
                resUpdateFeature.results[0].globalId =
                  options.attributes.GlobalID || result._id;
                resUpdateFeature.results[0].geometry = options.geometry;
                resUpdateFeature.results[0].geometry.spatialReference = {
                  wkid: 4326,
                };
                res.send(resUpdateFeature);
              })
              .catch((error) => {
                res.status(500).json({ error: error });
              });
          } else {
            options.attributes.created_user = 'HotspotManagementAPI';
            options.attributes.created_date = fDate;
            generateGlobalId(options)
              .then(() => {
                insertFeature(options)
                  .then((result) => {
                    resUpdateFeature.results[0].action = 'add';
                    resUpdateFeature.results[0].success = true;
                    resUpdateFeature.results[0].globalId =
                      options.attributes.GlobalID || result._id;
                    resUpdateFeature.results[0].geometry = options.geometry;
                    resUpdateFeature.results[0].geometry.spatialReference = {
                      wkid: 4326,
                    };
                    res.send(resUpdateFeature);
                  })
                  .catch((error) => {
                    res.status(500).json({ error: error });
                  });
              })
              .catch((error) => {
                res.status(500).json({ error: error });
              });
          }
        })
        .catch((error) => {
          res.status(400).json({ error: 'invalid geometry' });
        });
    })
    .catch((error) => {
      res.status(500).json({ error: error });
    });
}

function queryFeatureId(options) {
  return new Promise((resolve, reject) => {
    options.key = 'ExternalId';
    searchQuery(options).then((response) => {
      if (response.error) {
        reject(response.error);
      } else if (response.total.value !== 0) {
        resolve({
          _id: response.hits[0]._id,
          properties: response.hits[0]._source.properties,
          geometry: {
            x: response.hits[0]._source.geometry.coordinates[0],
            y: response.hits[0]._source.geometry.coordinates[1],
          },
        });
      } else {
        resolve({});
      }
    });
  });
}

function updateFeature(options) {
  return new Promise((resolve, reject) => {
    updateFeatureData(options)
      .then((response) => {
        if (response.error) {
          reject({
            error: response.error,
          });
        } else if (response && response.result === 'updated') {
          resolve(response);
        } else {
          reject({
            error: response.result,
          });
        }
      })
      .catch((error) => {
        reject(error);
      });
  });
}

function insertFeature(options) {
  return new Promise((resolve, reject) => {
    insertFeatureData(options)
      .then((response) => {
        if (response.error) {
          reject({
            error: response.error,
          });
        } else if (response && response.result === 'created') {
          resolve(response);
        } else {
          reject({
            error: response.result,
          });
        }
      })
      .catch((error) => {
        reject(error);
      });
  });
}

function generateGlobalId(options) {
  return new Promise((resolve, reject) => {
    options.key = 'GlobalID';
    options.attributes[options.key] = '{' + uc.upperCase(uuidv4()) + '}';
    searchQuery(options).then((response) => {
      if (response.error) {
        reject(response.error);
      } else if (response.total.value !== 0) {
        generateGlobalId(options).then(resolve).catch(reject);
      } else {
        resolve({});
      }
    });
  });
}
