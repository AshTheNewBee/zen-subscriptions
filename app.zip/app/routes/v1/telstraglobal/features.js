const { searchES } = require('../../../components/controller/helpers/helper');

const { handleError } = require('../../../components/controller/errorHandler');

const { serviceUrl, resTG } = require('../../../components/consts');

const listOptions = {
  'network-point': { index: 'int_network_nodes_point' },
  'network-line': { index: 'int_network_cable_line' },
  'pop-pops-point': { index: 'int_points_of_presence_point' },
  'pop-tpn-point': { index: 'int_programmable_network_point' },
  'pop-colocation-point': { index: 'int_colocation_point' },
  'infra-data-centre-point': { index: 'int_data_centres_point' },
  'infra-cloud-nodes-point': { index: 'int_cloud_nodes_point' },
  'infra-sat-teleports-point': {
    index: 'int_teleports_point',
    subquery: { key: 'properties.type', value: 'Satellite Teleports' },
  },
  'infra-partner-teleports-point': {
    index: 'int_teleports_point',
    subquery: { key: 'properties.type', value: 'Partner Teleports' },
  },
  'other-office-point': { index: 'int_office_point' },
  'media-point': { index: 'int_global_media_network_point' },
  'media-line': { index: 'int_global_media_network_line' },
};

module.exports = (app) => {
  app.post(serviceUrl + '/v1/telstraglobal/features', async (req, res) => {
    sendResponse(req, res);
  });
};

async function sendResponse(req, res) {
  let reqFeature = req.body.feature || '';
  let reqType = req.body.type || '';
  let reqFeatureType = req.body.featureType || '';
  let options = {};

  if (listOptions[reqFeature + '-' + reqType]) {
    options = {
      index: listOptions[reqFeature + '-' + reqType].index,
      subquery: listOptions[reqFeature + '-' + reqType].subquery,
    };

    await getESData(res, options, reqFeature, reqType, reqFeatureType)
      .then((values) => {
        let flatArr = [];
        values.map((val, i) => {
          flatArr = flatArr.concat(val);
        });
        resTG.results[0].value = flatArr;
        res.send(resTG);
      })
      .catch((error) => {
        handleError(res, 500, 'Unable to fetch global map data');
      });
  } else {
    handleError(res, 400, 'Invalid feature name');
  }
}

async function getESData(res, options, feature, type, featureType) {
  options.size = 5000;
  options.from = 0;
  const response = await searchES(options, 'getAllHits').catch((error) =>
    handleError(res, 500, 'Unable to fetch global map data')
  );
  if (response && response.error) {
    handleError(res, 500, 'Unable to fetch global map data');
  } else {
    return appendData(response, feature, type, featureType);
  }
}

function appendData(esResList, feature, type, featureType) {
  let resultArr = [];

  esResList.forEach((hit) => {
    let properties = hit._source.properties;
    let commonRes = {
      geometry: hit._source.geometry,
      properties: {
        _id: feature,
        _featureType: featureType,
        _type: feature + '-' + type,
        city: properties.city,
        country: properties.country,
        region:
          properties.region && !Array.isArray(properties.region)
            ? properties.region.split(',')
            : properties.region,
        label: properties.label,
      },
    };
    switch (feature + '-' + type) {
      case 'network-point': {
        const source = {
          _id: properties.cable_id,
        };
        Object.assign(commonRes.properties, source);
        break;
      }
      case 'network-line': {
        const source = {
          _id: properties.networkid,
          name: properties.name,
          cabletype: properties.cabletype,
          length: properties.length,
          fibrepairs: properties.fibrepairs,
          linetype: properties.linetype,
          stroke: properties.stroke || properties.color,
        };
        Object.assign(commonRes.properties, source);
        break;
      }
      case 'pop-pops-point': {
        let typeList = popType(properties);
        if (typeList.length == 0) {
          commonRes = null;
          break;
        }
        const source = {
          typeList,
        };
        Object.assign(commonRes.properties, source);
        break;
      }
      case 'infra-data-centre-point': {
        const source = {
          _id: properties.dc_name,
        };
        Object.assign(commonRes.properties, source);
        break;
      }
      case 'other-office-point': {
        const source = {
          address: properties.address,
        };
        Object.assign(commonRes.properties, source);
        break;
      }
      case 'media-line': {
        const source = {
          capacity: properties.capacity,
          stroke: properties.stroke,
          linetype: properties.linetype,
        };
        Object.assign(commonRes.properties, source);
        break;
      }
    }

    if (commonRes) resultArr = [...resultArr, commonRes];
  });

  return resultArr;
}

function popType(properties) {
  let typeList = [];
  if (properties.epl_express_pop) {
    let item = {
      _id: 'sub-pop-eplx',
      label: 'EPLX',
    };
    typeList = [...typeList, item];
  }
  if (properties.epl_pop || properties.ipl_pop) {
    let item = {
      _id: 'sub-pop-ipl-epl',
      label: 'Point to Point (IPL/EPL)',
    };
    typeList = [...typeList, item];
  }
  if (properties.evpl_pop || properties.vpls_pop) {
    let item = {
      _id: 'sub-pop-evpn',
      label: 'EVPN (VPLS/EVPL)',
    };
    typeList = [...typeList, item];
  }
  if (
    properties.ipvpn_pop ||
    properties.ipvpn_remote_site_access_gateway ||
    properties.ipvpn_secure_mobile_access
  ) {
    let item = {
      _id: 'sub-pop-ipvpn',
      label: 'IPVPN',
    };
    typeList = [...typeList, item];
  }
  if (
    properties.gid_pop ||
    properties.gid_tid ||
    properties.gie_pop ||
    properties.ipt_pop
  ) {
    let item = {
      _id: 'sub-pop-internet',
      label: 'Internet (GID/IPT)',
    };
    typeList = [...typeList, item];
  }
  return typeList;
}
