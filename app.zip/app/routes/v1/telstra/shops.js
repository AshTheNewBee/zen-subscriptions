// routes/telstra/shops.js
const { serviceUrl, resFeatureList } = require('../../../components/consts');
const validator = require('validator');
const { returnValue } = require('./shared');

const { handleError } = require('../../../components/controller/errorHandler');
const {
  searchES,
  returnValidCoordinates,
  validateExtentCoordinates,
  getPagination,
} = require('../../../components/controller/helpers/helper');

const { shopResponse } = require('./_shopResponse');

module.exports.topTelstraShops = function async(app) {
  app.get(serviceUrl + '/v1/telstra/shops', async (req, res) => {
    validateInputAndSearch(req, res);
  });
};

module.exports.telstraShopsList = function (app) {
  app.post(serviceUrl + '/v1/telstra/shops/list', (req, res) => {
    validateListInputAndSearch(req, res);
  });
};

module.exports.telstraShopsMap = function (app) {
  app.post(serviceUrl + '/v1/telstra/shops/map', (req, res) => {
    validateMapInputAndSearch(req, res);
  });
};

module.exports.telstraShopDetails = async function (app) {
  app.get(serviceUrl + '/v1/telstra/shops/details', async (req, res) => {
    if (req.query.storecode) {
      const options = {
        field: 'properties.storecode',
        value: req.query.storecode,
        type: 'value',
      };
      const result = await searchServices(res, options, resFeatureList);
      res.send(result);
    } else {
      handleError(res, 400, 'Invalid request parameters');
    }
  });
};

async function validateInputAndSearch(req, res) {
  try {
    const coordinates = await returnValidCoordinates(
      res,
      req.query.longitude,
      req.query.latitude
    );

    const options = {
      ...coordinates,
    };
    options.radius = 1;
    options.size = 5;
    options.from = 0;
    options.type = 'list';
    options.legacy = true;

    const result = await searchServices(res, options, resFeatureList);
    res.send(result);
  } catch (error) {
    if (error.message === 'Invalid coordinates') {
      handleError(res, 400, 'Invalid request parameters');
    } else {
      handleError(res, 500, 'Unable to fetch Telstra Shops data');
    }
  }
}

async function validateListInputAndSearch(req, res) {
  // Set empty point hash in case it is missing from body
  req.body.point = req.body.point || {};

  try {
    const coordinates = await returnValidCoordinates(
      res,
      req.body.point.lon,
      req.body.point.lat
    );

    let options = {
      ...coordinates,
    };
    options.radius =
      req.body.radius && validator.isInt(req.body.radius.toString())
        ? req.body.radius.toString()
        : 100000;
    options = getPagination(req, options);
    options.type = 'list';
    const result = await searchServices(res, options, resFeatureList);
    res.send(result);
  } catch (error) {
    if (error.message === 'Invalid coordinates') {
      handleError(res, 400, 'Invalid request parameters');
    } else {
      handleError(res, 500, 'Unable to fetch Telstra Shops data');
    }
  }
}

async function validateMapInputAndSearch(req, res) {
  req.body.extent = req.body.extent || {};
  try {
    await validateExtentCoordinates(req, res).then(async () => {
      let options = {
        top: req.body.extent.top,
        left: req.body.extent.left,
        bottom: req.body.extent.bottom,
        right: req.body.extent.right,
        latitude: req.body.center ? req.body.center.lat : '',
        longitude: req.body.center ? req.body.center.lon : '',
      };
      options = getPagination(req, options, 100, 100);
      options.type = 'map';
      const result = await searchServices(res, options, resFeatureList);
      res.send(result);
    });
  } catch (error) {
    if (error.message === 'Invalid coordinates') {
      handleError(res, 400, 'Invalid request parameters');
    } else {
      handleError(res, 500, 'Unable to fetch Telstra Shops data');
    }
  }
}

async function searchServices(res, options, apiResponse) {
  options.index = 'telstra_shops';
  return await searchIndex(res, options)
    .then((response) => {
      apiResponse.results[0].value = [{}];
      if (options.legacy) {
        apiResponse.results[0].value[0].storeList = [];
      } else {
        apiResponse.results[0].value[0].featureList = [];
      }
      if (response.result != null) {
        for (const value of response.result.hits) {
          const obj = shopResponse(value);
          obj.type = options.view ? value._source.properties.type : 'store';
          obj.icon =
            options.view && value._source.properties.type !== 'TSN'
              ? 'Shop_Blue'
              : 'Shop_Green';

          if (options.latitude && options.longitude) {
            obj.distance = parseInt(value.sort[0].toFixed(), 10);
          }
          apiResponse.results[0].value[0].storeList &&
            apiResponse.results[0].value[0].storeList.push(obj);
          apiResponse.results[0].value[0].featureList &&
            apiResponse.results[0].value[0].featureList.push(obj);
        }
        if (!options.legacy) {
          apiResponse.results[0].value[0].type = 'point';
          apiResponse.results[0].value[0].legend = {
            icon: {
              path: 'https://maps.gcm.telstra.com.au/api/map-ui/v1/assets/images/',
              type: ['svg', 'pdf', 'png'],
            },
          };
          if (options.type !== 'value') {
            apiResponse.results[0].value[0].pagination = {
              total: response.result.total.value,
              count: response.result.hits.length,
              size: parseInt(options.size, 10),
              from: parseInt(options.from, 10),
            };
          }
        } else {
          apiResponse.results[0].value[0].radius = '1km';
        }
      }
      return apiResponse;
    })
    .catch((error) =>
      handleError(res, 500, 'Unable to fetch Telstra Shops data')
    );
}

async function searchIndex(res, options) {
  let searchPromise =
    options.type === 'map'
      ? 'searchGeoBoundingBox'
      : options.type === 'list'
      ? 'searchGeoDistance'
      : 'stringSearchQuery';
  const response = await searchES(options, searchPromise);
  return returnValue(options.type, response);
}
