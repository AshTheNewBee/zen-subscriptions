const returnValue = (optionType, response) => {
  if (optionType === 'value') {
    const storeCodeRes = response.length > 0 ? [response[0]] : [];
    return {
      result: {
        hits: storeCodeRes,
      },
    };
  } else if (response.result !== null) {
    return { result: response.result.hits };
  } else {
    return { result: { total: { value: 0 }, hits: [] } };
  }
};

const validateStoreCodeReq = (storecode, field) => {
  if (storecode) {
    return {
      field: field,
      value: storecode,
      type: "value",
    };
  } else {
    handleError(res, 400, "Invalid request parameters");
  }
};

module.exports = {
  returnValue,
  validateStoreCodeReq,
};
