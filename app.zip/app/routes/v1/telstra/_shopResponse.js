const shopResponse = (value) => {
  return {
    latitude: value._source.geometry.coordinates[1],
    longitude: value._source.geometry.coordinates[0],
    title: value._source.properties.title || null,
    address:
      (value._source.properties.address_display &&
        value._source.properties.address_display.replace(/<br>/gi, '\n')) ||
      null,
    suburb: value._source.properties.suburb || null,
    postcode: value._source.properties.postcode || null,
    state: value._source.properties.state || null,
    phone: value._source.properties.phone || null,
    store_email: value._source.properties.store_email || null,
    storecode: value._source.properties.storecode || null,
    booking: value._source.properties.booking || null,
    hrs_mon: value._source.properties.hrs_mon || null,
    hrs_tue: value._source.properties.hrs_tue || null,
    hrs_wed: value._source.properties.hrs_wed || null,
    hrs_thu: value._source.properties.hrs_thu || null,
    hrs_fri: value._source.properties.hrs_fri || null,
    hrs_sat: value._source.properties.hrs_sat || null,
    hrs_sun: value._source.properties.hrs_sun || null,
    store_manager: value._source.properties.store_manager || null,
    store_manager_email: value._source.properties.store_manager_email || null,
    store_manager_mobile: value._source.properties.store_manager_mobile || null,
    timezoneId: value._source.properties.timezoneId || null,
    myStoreQueueParticipated:
      value._source.properties.myStoreQueueParticipated || null,
    languages: value._source.properties.languages || null,
  };
};

module.exports = {
  shopResponse,
};
