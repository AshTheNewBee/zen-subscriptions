// routes/telstra/businesscentres.js
const { serviceUrl, resFeatureList } = require("../../../components/consts");
const { returnValue } = require("./shared");

const validator = require("validator");
const {
  searchES,
  getPagination,
  returnValidCoordinates,
  validateExtentCoordinates,
} = require("../../../components/controller/helpers/helper");

const { handleError } = require("../../../components/controller/errorHandler");

module.exports.telstraBusinessCentresList = function (app) {
  app.post(serviceUrl + "/v1/telstra/businesscentres/list", (req, res) => {
    validateListInputAndSearch(req, res);
  });
};

module.exports.telstraBusinessCentresMap = function (app) {
  app.post(serviceUrl + "/v1/telstra/businesscentres/map", (req, res) => {
    validateMapInputAndSearch(req, res);
  });
};

module.exports.telstraBusinesscentresDetails = async function (app) {
  app.get(
    serviceUrl + "/v1/telstra/businesscentres/details",
    async (req, res) => {
      if (req.query.storecode) {
        const options = {
          field: "properties.id",
          value: req.query.storecode,
          type: "value",
        };
        const result = await searchServices(
          res,
          options,
          resFeatureList,
          "stringSearchQuery"
        );
        res.send(result);
      } else {
        handleError(res, 400, "Invalid request parameters");
      }
    }
  );
};

async function validateListInputAndSearch(req, res) {
  // Set empty point hash in case it is missing from body
  req.body.point = req.body.point || {};

  try {
    const coordinates = await returnValidCoordinates(
      res,
      req.body.point.lon,
      req.body.point.lat
    );

    let options = {
      ...coordinates,
    };
    options.radius =
      req.body.radius && validator.isInt(req.body.radius.toString())
        ? req.body.radius.toString()
        : 100000;

    options = getPagination(req, options);
    options.type = "list";

    options.postcode = req.body.postcode;
    const result = await searchServices(res, options, resFeatureList);
    res.send(result);
  } catch (error) {
    if (error.message === "Invalid coordinates") {
      handleError(res, 400, "Invalid request parameters");
    } else {
      handleError(res, 500, "Unable to fetch Telstra Business Centres data");
    }
  }
}

async function validateMapInputAndSearch(req, res) {
  try {
    await validateExtentCoordinates(req, res).then(async () => {
      let options = {
        top: req.body.extent.top,
        left: req.body.extent.left,
        bottom: req.body.extent.bottom,
        right: req.body.extent.right,
        latitude: req.body.center ? req.body.center.lat : "",
        longitude: req.body.center ? req.body.center.lon : "",
      };
      options = getPagination(req, options, 100, 100);
      options.type = "map";

      const result = await searchServices(res, options, resFeatureList);
      res.send(result);
    });
  } catch (error) {
    if (error.message === "Invalid coordinates") {
      handleError(res, 400, "Invalid request parameters");
    } else {
      handleError(res, 500, "Unable to fetch Telstra Business Centres data");
    }
  }
}

async function searchServices(res, options, apiResponse, searchType) {
  options.index = "telstra_business_centres";
  try {
    return await searchIndex(res, options, searchType).then((response) => {
      apiResponse.results[0].value = [{}];
      apiResponse.results[0].value[0].featureList = [];

      if (response.result != null) {
        for (const value of response.result.hits) {
          const obj = {
            latitude: value._source.geometry.coordinates[1],
            longitude: value._source.geometry.coordinates[0],
            title: value._source.properties.title,
            address:
              value._source.properties.address_display &&
              value._source.properties.address_display.replace(/<br>/gi, "\n"),
            suburb: value._source.properties.suburb,
            postcode: value._source.properties.postcode,
            state: value._source.properties.state,
            business_hours_phone: value._source.properties.business_hours_phone,
            hrs_mon: value._source.properties.hrs_mon,
            hrs_tue: value._source.properties.hrs_tue,
            hrs_wed: value._source.properties.hrs_wed,
            hrs_thu: value._source.properties.hrs_thu,
            hrs_fri: value._source.properties.hrs_fri,
            hrs_sat: value._source.properties.hrs_sat,
            hrs_sun: value._source.properties.hrs_sun,
            sales_manager: value._source.properties.sales_manager,
            sales_manager_phone: value._source.properties.sales_manager_phone,
            sales_manager_email: value._source.properties.sales_manager_email,
          };
          obj.type = options.view
            ? value._source.properties.store_type
            : "BUSINESS_CENTRE";
          obj.icon =
            options.view &&
            value._source.properties.store_type !== "TECHNOLOGY_CENTRE"
              ? "Shop_DarkBlue"
              : "Shop_Purple";

          if (options.latitude && options.longitude) {
            const dist = options.postcode ? value.sort[1] : value.sort[0];
            obj.distance = parseInt(dist.toFixed(), 10);
          }
          apiResponse.results[0].value[0].featureList &&
            apiResponse.results[0].value[0].featureList.push(obj);
        }
      }
      if (options.type !== "value") {
        apiResponse.results[0].value[0].type = "point";
        apiResponse.results[0].value[0].legend = {
          icon: {
            path: "https://maps.gcm.telstra.com.au/api/map-ui/v1/assets/images/",
            type: ["svg", "pdf", "png"],
          },
        };
        apiResponse.results[0].value[0].pagination = {
          total: response.result.total.value,
          count: response.result.hits.length,
          size: parseInt(options.size, 10),
          from: parseInt(options.from, 10),
        };
      } else {
        apiResponse.results[0].value[0].radius = "1km";
      }
      return apiResponse;
    });
  } catch (error) {
    handleError(res, 500, "Unable to fetch business centres data");
  }
}

async function searchIndex(res, options, searchType) {
  let searchPromise =
    searchType ||
    (options.type === "map"
      ? "searchGeoBoundingBox"
      : options.postcode
      ? "searchByPostcode"
      : "searchGeoDistance");

  const response = await searchES(options, searchPromise);
  return returnValue(options.type, response);
}
