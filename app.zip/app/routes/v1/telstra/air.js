// routes/v1/telstra/air.js
const { serviceUrl, resFeatureList } = require('../../../components/consts');
const validator = require('validator');
const { handleError } = require('../../../components/controller/errorHandler');
const {
  searchES,
  returnValidCoordinates,
  validateExtentCoordinates,
  getPagination,
} = require('../../../components/controller/helpers/helper');

module.exports.telstraAirHotspotList = function (app) {
  app.post(serviceUrl + '/v1/telstra/air/list', (req, res) => {
    validateListInputAndSearch(req, res);
  });
};

module.exports.telstraAirMap = function (app) {
  app.post(serviceUrl + '/v1/telstra/air/map', (req, res) => {
    validateMapInputAndSearch(req, res);
  });
};

module.exports.topHotspots = async function (app) {
  app.get(serviceUrl + '/v1/telstra/air', async (req, res) => {
    try {
      const coordinates = await returnValidCoordinates(
        res,
        req.query.longitude,
        req.query.latitude
      ).catch((error) => handleError(res, 400, 'Invalid request parameters'));

      const options = {
        ...coordinates,
      };
      options.radius = 1;
      options.size = 5;
      options.from = 0;
      options.legacy = true;

      const result = await searchServices(res, options, resFeatureList);
      res.send(result);
    } catch (error) {
      return error;
    }
  });
};

async function validateListInputAndSearch(req, res) {
  // Set empty point hash in case it is missing from body
  try {
    req.body.point = req.body.point || {};
    const coordinates = await returnValidCoordinates(
      res,
      req.body.point.lon,
      req.body.point.lat
    );

    let options = {
      ...coordinates,
    };

    options.radius =
      req.body.radius && validator.isInt(req.body.radius.toString())
        ? req.body.radius.toString()
        : 100000;
    options = getPagination(req, options, 500, 5);
    options.type = 'list';

    const result = await searchServices(res, options, resFeatureList);
    res.send(result);
  } catch (error) {
    if (error.message === 'Invalid coordinates') {
      handleError(res, 400, 'Invalid request parameters');
    } else {
      handleError(res, 500, 'Unable to fetch Telstra Air data');
    }
  }
}

async function validateMapInputAndSearch(req, res) {
  // Set empty extent hash in case it is missing from body
  req.body.extent = req.body.extent || {};
  try {
    await validateExtentCoordinates(req, res).then(async () => {
      let options = {
        top: req.body.extent.top,
        left: req.body.extent.left,
        bottom: req.body.extent.bottom,
        right: req.body.extent.right,
        latitude: req.body.center ? req.body.center.lat : '',
        longitude: req.body.center ? req.body.center.lon : '',
      };

      if (validator.isInt(req.body.zoom.toString(), { min: 3, max: 15 })) {
        options.zoom = req.body.zoom.toString();
      }

      options = getPagination(req, options, 1000, 1000);
      options.type = 'map';
      const result = await searchServices(res, options, resFeatureList);
      res.send(result);
    });
  } catch (error) {
    if (error.message === 'Invalid coordinates') {
      handleError(res, 400, 'Invalid request parameters');
    } else {
      handleError(res, 500, 'Unable to fetch Telstra Air data');
    }
  }
}

async function searchServices(res, options, apiResponse) {
  if (options.type === 'map' && options.view === 'internal') {
    options.index = 'telstra_air_hotspots,telstra_air_homespots';
  } else {
    options.index = 'telstra_air_hotspots';
  }
  return await searchIndex(res, options)
    .then((response) => {
      apiResponse.results[0].value = [{}];
      if (options.legacy) {
        apiResponse.results[0].value[0].topPublicHotspots = [];
      } else {
        apiResponse.results[0].value[0].featureList = [];
      }

      if (response.result != null) {
        if (response.result['zoomed-in'] != null) {
          for (const value of response.result['zoomed-in'].zoom1.buckets) {
            const obj = {
              latitude: value.centroid.location.lat,
              longitude: value.centroid.location.lon,
              count: value.centroid.count,
            };
            apiResponse.results[0].value[0].featureList &&
              apiResponse.results[0].value[0].featureList.push(obj);
          }
          apiResponse.results[0].value[0].type = 'cluster';
          apiResponse.results[0].value[0].pagination = {
            total: response.result['zoomed-in'].zoom1.buckets.length,
            count: response.result['zoomed-in'].zoom1.buckets.length,
            size: parseInt(options.size, 10),
            from: parseInt(options.from, 10),
          };
        } else {
          for (const value of response.result.hits) {
            const obj = {
              latitude: value._source.geometry.coordinates[1],
              longitude: value._source.geometry.coordinates[0],
            };
            obj.type = value._source.properties.hotspot_type
              ? options.view
                ? value._source.properties.hotspot_type
                : 'hotspot'
              : 'homespot';
            obj.icon = value._source.properties.hotspot_type
              ? options.view
                ? (function (type) {
                    switch (type) {
                      case 'Merchant':
                        return 'WiFi_Public_Blue';
                      case 'Store':
                        return 'WiFi_Public_Green';
                      case 'Partner':
                        return 'WiFi_Public_Purple';
                      default:
                        return 'WiFi_Public_Pink';
                    }
                  })(value._source.properties.hotspot_type)
                : 'WiFi_Public_Pink'
              : 'WiFi_Home_Pink';
            obj.address = value._source.properties.street_address;
            if (options.latitude && options.longitude) {
              obj.distance = value && parseInt(value.sort[0].toFixed(), 10);
            }
            apiResponse.results[0].value[0].topPublicHotspots &&
              apiResponse.results[0].value[0].topPublicHotspots.push(obj);
            apiResponse.results[0].value[0].featureList &&
              apiResponse.results[0].value[0].featureList.push(obj);
          }
          apiResponse.results[0].value[0].type = 'point';
          if (options.type) {
            apiResponse.results[0].value[0].legend = {
              icon: {
                path: 'https://maps.gcm.telstra.com.au/api/map-ui/v1/assets/images/',
                type: ['svg', 'pdf', 'png'],
              },
            };
            apiResponse.results[0].value[0].pagination = {
              total: response.result.total.value,
              count: response.result.hits.length,
              size: parseInt(options.size, 10),
              from: parseInt(options.from, 10),
            };
          } else {
            apiResponse.results[0].value[0].radius = '1km';
          }
        }
      }
      return apiResponse;
    })
    .catch((error) => handleError(res, 500, 'Unable to map Telstra air data'));
}

async function searchIndex(res, options) {
  let searchPromise =
    options.type === 'map' ? 'searchGeoBoundingBox' : 'searchGeoDistance';
  const response = await searchES(options, searchPromise);

  if (response.error) {
    handleError(res, 500, 'Unable to fetch Telstra air data');
  } else if (response.result !== null) {
    return {
      result: options.zoom
        ? response.result.aggregations
        : response.result.hits,
    };
  } else {
    return { result: { total: { value: 0 }, hits: [] } };
  }
}
