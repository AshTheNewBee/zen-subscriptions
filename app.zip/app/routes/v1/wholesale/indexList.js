const indexListACT2 = [
  {
    name: '4G',
    type: 'outdoor',
    index: ['wlsale_4g_hh_700', 'wlsale_4g_hh_1800'],
  },
  {
    name: '4G',
    type: 'indoor',
    index: ['wlsale_4g_ib_700', 'wlsale_4g_ib_1800'],
  },
  {
    name: '4G',
    type: 'extAntenna',
    index: ['wlsale_4g_ea_700', 'wlsale_4g_ea_1800'],
  },
  { name: '3G', type: 'outdoor', index: ['wlsale_3g_hh'] },
  { name: '3G', type: 'indoor', index: ['wlsale_3g_ib'] },
  {
    name: '3G',
    type: 'extAntenna',
    index: ['wlsale_3g_ea'],
  },
];

module.exports = {
  indexListACT2,
};
