// routes/v1/wholesale/coverage.js
const {
  getValidCoordinates,
} = require('../../../components/controller/validation/validate');
const { serviceUrl, resMobileCoverage } = require('../../../components/consts');
const {
  searchES,
  getGenericCovResponse,
} = require('../../../components/controller/helpers/helper');

const { handleError } = require('../../../components/controller/errorHandler');

const { indexListACT2 } = require('./indexList');

module.exports = {
  v1_wholesale_coverage: (app) => {
    app.get(serviceUrl + '/v1/wholesale/coverage', (req, res) => {
      const config = {
        longitude: req.query.longitude,
        latitude: req.query.latitude,
        techTypes: '',
        internalView: true,
        legacy: true,
        useACT2Index: true,
      };
      sendResponse(config, req, res);
    });
  },
  getFilteredIndexArr,
};

function getFilteredIndexArr(config) {
  const defaultTechTypes = ['4G', '3G'];
  const filteredTechTypes = Array.isArray(config.techTypes)
    ? config.techTypes.filter((techType) => defaultTechTypes.includes(techType))
    : defaultTechTypes;

  const indexArray = indexListACT2;
  return indexArray.filter((index) => filteredTechTypes.includes(index.name));
}

async function sendResponse(config, req, res) {
  const filteredIndexArr = getFilteredIndexArr(config);
  try {
    const coordinates = await getValidCoordinates(
      config.longitude,
      config.latitude
    ).catch((err) => handleError(res, 400, 'Invalid request parameters'));
    const options = {
      latitude: coordinates.getLatitude(),
      longitude: coordinates.getLongitude(),
    };
    await searchServices(res, options, filteredIndexArr)
      .then((result) => {
        if (config.legacy) {
          resMobileCoverage.results[0].value = result;
        } else {
          let coverageRes = {};
          Object.keys(result).forEach((key) => {
            coverageRes[key] = {
              indoor: { coverage: result[key].indoor },
              outdoor: { coverage: result[key].outdoor },
            };
            if (
              !config.excludeCovTypes.includes('extAntenna') &&
              (!result[key].indoor || !result[key].outdoor)
            ) {
              coverageRes[key].extAntenna = {
                coverage: result[key].extAntenna,
              };
            }
          });
          resMobileCoverage.results[0].value = coverageRes;
        }
        res.send(resMobileCoverage);
      })
      .catch((err) => handleError(res, 500, 'Unable to find mobile coverage'));
  } catch (error) {
    return error;
  }
}

async function searchServices(res, options, _indexList) {
  try {
    let resultObj = {};

    let promiseAll = await Promise.all(
      _indexList.map(async (layer) => {
        if (!resultObj[layer.name]) {
          resultObj[layer.name] = {
            outdoor: false,
            indoor: false,
          };
        }
        options.index = layer.index;

        await searchIndex(res, options).then((response) => {
          resultObj[layer.name][layer.type] = response;
        });
      })
    )
      .then(() => {
        return resultObj;
      })
      .catch((error) => {
        handleError(res, 500, 'Unable to map mobile data');
      });
    return promiseAll;
  } catch (error) {
    handleError(res, 500, 'Unable to map mobile data');
  }
}

async function searchIndex(res, options) {
  if (Array.isArray(options.index) && options.index.length > 0) {
    const response = await searchES(options, 'searchGeoShape');

    return getGenericCovResponse(response, res, 'mobile');
  } else {
    return false;
  }
}
