// routes/v1/internet/smartmodem.js

const {
  searchGeoShape,
} = require('../../../components/controller/search/search_es6');

const {
  getValidCoordinates,
} = require('../../../components/controller/validation/validate');
const { serviceUrl, resSmartModem } = require('../../../components/consts');

const {
  searchES,
  getGenericCovResponse,
} = require('../../../components/controller/helpers/helper');

const { handleError } = require('../../../components/controller/errorHandler');

module.exports = function (app) {
  app.get(serviceUrl + '/v1/internet/smartmodem', (req, res) => {
    sendResponse(req, res);
  });
};

async function sendResponse(req, res) {
  try {
    const coordinates = await getValidCoordinates(
      req.query.longitude,
      req.query.latitude
    ).catch((error) => handleError(res, 400, 'Invalid request parameters'));
    const options = {
      latitude: coordinates.getLatitude(),
      longitude: coordinates.getLongitude(),
    };
    const result = await searchServices(res, options, resSmartModem);
    res.send(result);
  } catch (error) {
    return error;
  }
}

async function searchServices(res, options, apiResponse) {
  options.index = 'fixed_4g_hh';
  return await searchIndex(res, options)
    .then((response_4gfw_self) => {
      if (response_4gfw_self) {
        apiResponse.results[0].value = true;
        return apiResponse;
      } else {
        apiResponse.results[0].value = false;
        return apiResponse;
      }
    })
    .catch((error) => handleError(res, 500, 'Unable to map Smart Modem data'));
}

async function searchIndex(res, options) {
  const response = await searchES(options, 'searchGeoShape');

  return getGenericCovResponse(response, res, 'Smart Modem');
}
