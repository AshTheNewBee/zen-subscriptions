// routes/v1/internet/4gfw.js

const {
  getValidCoordinates,
} = require('../../../components/controller/validation/validate');
const { serviceUrl, resInternet4gfw } = require('../../../components/consts');

const {
  searchES,
  getGenericCovResponse,
} = require('../../../components/controller/helpers/helper');

const { handleError } = require('../../../components/controller/errorHandler');

module.exports = function (app) {
  app.get(serviceUrl + '/v1/internet/4gfw', (req, res) => {
    sendResponse(req, res);
  });
};

async function sendResponse(req, res) {
  try {
    const coordinates = await getValidCoordinates(
      req.query.longitude,
      req.query.latitude
    ).catch((error) => handleError(res, 400, 'Invalid request parameters'));
    const options = {
      latitude: coordinates.getLatitude(),
      longitude: coordinates.getLongitude(),
      useACT2Index: true,
    };
    const result = await searchServices(res, options, resInternet4gfw);
    res.send(result);
  } catch (error) {
    return error;
  }
}

async function searchServices(res, options, apiResponse) {
  options.index = options.useACT2Index ? 'fixed_4g_hh' : '4gfw_self';
  return await searchIndex(res, options)
    .then(async (response_4gfw_self) => {
      if (response_4gfw_self) {
        apiResponse.results[0].value[0].coverage = true;
        apiResponse.results[0].value[0].antennaRequired = false;
        return apiResponse;
      } else {
        options.index = options.useACT2Index ? 'fixed_4g_ea' : '4gfw_yagi';
        return await searchIndex(res, options).then((response_4gfw_yagi) => {
          if (response_4gfw_yagi) {
            apiResponse.results[0].value[0].coverage = true;
            apiResponse.results[0].value[0].antennaRequired = true;
            return apiResponse;
          } else {
            apiResponse.results[0].value[0].coverage = false;
            apiResponse.results[0].value[0].antennaRequired = false;
            return apiResponse;
          }
        });
      }
    })
    .catch((error) => handleError(res, 500, 'Unable to map 4GFW data'));
}

async function searchIndex(res, options) {
  const response = await searchES(options, 'searchGeoShape');
  return getGenericCovResponse(response, res, '4GFW');
}
