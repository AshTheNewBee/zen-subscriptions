// server.js
//define env var called "PLATFORM = AMP" in AWS launch template
const newrelic = process.env.PLATFORM === 'AMP' ? require('newrelic') : null;
const cors = require('cors');
const express = require('express');
const fse = require('fs-extra');
const morgan = require('morgan');
const morganJson = require('morgan-json');
const os = require('os');
const path = require('path');
const rfs = require('rotating-file-stream');
const routesList = require('./routes');
const { whitelist } = require('./components/consts');

const app = express();
const PORT = 5000;

const moment = require('moment-timezone');

morgan.token('date', function () {
  return moment().tz('Australia/Sydney').format();
});

// create a write stream (in append mode)
const logDirectory = path.join(__dirname, '../log');

// ensure log directory exists
fse.mkdirpSync(logDirectory);

// create a rotating write stream
const accessLogStream = rfs.createStream('access.log', {
  interval: '1d', // rotate daily
  path: logDirectory,
});

const format = morganJson({
  date: ':date',
  'remote-addr': ':remote-addr',
  method: ':method',
  url: ':url',
  'http-version': ':http-version',
  status: ':status',
  length: ':res[content-length]',
  'response-time': ':response-time',
  referrer: ':referrer',
  'user-agent': ':user-agent',
  instance: os.hostname() || 'null',
  'app-name': process.env.newrelic_app || 'null',
});

// setup the logger
//app.use(morgan('combined', { stream: accessLogStream }))
app.use(
  morgan(format, {
    stream: accessLogStream,
  })
);

const corsOptions = {
  origin: function (origin, callback) {
    if (whitelist.indexOf(origin) !== -1 || !origin) {
      callback(null, true);
    } else {
      callback(new Error('Not allowed by CORS'));
    }
  },
  methods: ['GET', 'POST', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'apikey', 'API-Key'],
};

app.use(cors(corsOptions));

app.use(express.json());

app.get('/', function (req, res) {
  const transactionHandle = newrelic ? newrelic.getTransaction() : null;
  transactionHandle && transactionHandle.ignore();
  res.send('Healthcheck OK');
});
routesList(app, {});

app.listen(5000);
