// server.js
const express = require('express');
const routesList = require('./routes');
const bodyParser = require('body-parser');

const app = express();
const PORT = 6000;

app.use(bodyParser.json());
app.use(
  bodyParser.urlencoded({
    extended: true,
  })
);
// application routing
app.get('/', function (req, res) {
  res.send('Healthcheck OK');
});
routesList(app, {});

// application listener
const server = app.listen(PORT);

// listen for an event
const handler = server.close();

module.exports = app;
module.exports = handler;
