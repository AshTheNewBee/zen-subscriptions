import {
  renderPointGraphics,
  renderLineGraphics,
  renderGraphics,
} from 'components/controller/GraphicHandler';
import { _mapView } from 'utils/_sampleData';

const promise = require('utils/_gpServiceLoader');
const esriLoader = require('utils/esri/EsriLoader');
const helper = require('components/helper/Helper');
const handler = require('components/controller/GraphicHandler');
const FilterFunctions = require('components/content/FilterFunctions');

const response = {
  results: [
    {
      dataType: 'gpArray',
      value: [
        {
          geometry: {
            coordinates: [121.026247, 14.555879],
            type: 'Point',
          },
          properties: {
            address: 'Paseo de Roxas cor Makati Ave, 1226, Philippines',
            city: 'Makati City',
            country: 'Philippines',
            type: 'office',
          },
        },
      ],
    },
    {
      dataType: 'gpArray',
      value: [
        {
          geometry: {
            coordinates: [121.026247, 14.555879],
            type: 'LineString',
          },
          properties: {
            _id: 'cable-ac-1',
            _type: 'network-line',
          },
        },
      ],
    },
  ],
};

const layer = {
  id: 'graphicLayer',
  graphics: {
    add: jest.fn(),
  },
};

const mapview = {
  view: {
    graphics: {
      add: jest.fn,
    },
  },
};

describe('unit testing GraphicHandler', () => {
  let graphicLayerSpy, renderPointGraphicsSpy, renderLineGraphicsSpy;

  afterEach(() => {
    jest.clearAllMocks();
  });

  beforeEach(() => {
    renderPointGraphicsSpy = jest.spyOn(handler, 'renderPointGraphics');
    renderLineGraphicsSpy = jest.spyOn(handler, 'renderLineGraphics');
    jest.spyOn(promise, 'getGPResponse').mockImplementation(() => {
      return response;
    });

    jest.spyOn(FilterFunctions, 'flattenRenderNodes').mockImplementation(() => {
      return [
        {
          value: 'network',
          loadGraphicData: true,
          loadMapData: undefined,
          dataType: ['point', 'line'],
        },
      ];
    });

    graphicLayerSpy = jest
      .spyOn(helper, 'FindLayers')
      .mockImplementation(() => {
        return layer;
      });
  });

  it('should renderPointGraphics if the type is point', async () => {
    await renderGraphics(mapview, 'apiKey', 'pop', 'point');
    //expect(await renderPointGraphics).toHaveBeenCalled()
  });

  it('should renderLineGraphics if the type is line', async () => {
    await renderGraphics(mapview, 'apiKey', 'line', 'line');
    //expect(await renderLineGraphics).toHaveBeenCalled()
  });

  it('should call renderPointGraphics if the param is point', async () => {
    const createPointMock = await jest
      .spyOn(esriLoader, 'createPointGraphic')
      .mockImplementation(() => {
        return response;
      });

    await renderPointGraphics(response, layer).catch((err) => err);
    expect(createPointMock).toHaveBeenCalled();
    //expect(layer.graphics.add).toHaveBeenCalled();
  });

  it('should call renderLineGraphics if the param is a line', async () => {
    const createPollyLineMock = await jest
      .spyOn(esriLoader, 'createPollyLineGraphic')
      .mockImplementation(() => {
        return response;
      });

    await renderLineGraphics(response, layer).catch((err) => err);
    expect(createPollyLineMock).toHaveBeenCalled();
  });

  // it('should return error if createPollyLineGraphic fails', async () => {
  //   await jest
  //     .spyOn(esriLoader, 'createPollyLineGraphic')
  //     .mockImplementation(() => {
  //       Promise.reject('error occured')
  //     });

  //     await renderLineGraphics(response, _mapView).catch(err => {
  //       expect(global.console.error).toHaveBeenCalledWith(
  //         'error occured while fetching PoP data'
  //       )
  //     })
  // });

  // it('should return error if createPollyLineGraphic fails', async () => {
  //   await jest
  //     .spyOn(esriLoader, 'createPointGraphic')
  //     .mockImplementation(() => {
  //       Promise.reject({error: 'error occured'})
  //     });

  //    await renderLineGraphics(response, _mapView).catch(err => {
  //       expect(global.console.error).toHaveBeenCalledWith(
  //         'error occured while fetching cable data'
  //       )
  //     })
  // });
});
