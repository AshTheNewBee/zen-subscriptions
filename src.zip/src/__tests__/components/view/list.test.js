import React from 'react';
import Enzyme, { mount, shallow } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import { ListComp } from 'components/view/List';

Enzyme.configure({ adapter: new Adapter() });

const routeFilters = [
  {
    path: '/network',
    name: 'network',
    component: 'network',
    icon: 'networkIcon',
    subRoutes: [
      {
        path: '/cableSystem',
        name: 'Cable System',
        component: 'cableSystem',
        subRoutes: [
          {
            path: '/AAE-1',
            name: 'AAE-1',
            component: 'AAE-1',
          },
          {
            path: '/AAG',
            name: 'AAG',
            component: 'AAG',
          },
        ],
      },
      {
        path: '/overlandCables',
        name: 'Overland Cables',
        component: 'overlandCables',
      },
    ],
  },
];

describe('Unit testing List', () => {
  it('should display list', () => {
    const props = { listItems: routeFilters };
    const wrapper = shallow(<ListComp {...props} />);
    expect(wrapper.find('.list').length).toBe(1);
  });

  it('should display list items', () => {
    const listItems = <ListComp className="filterList" />;
    const props = { listItems };
    const wrapper = shallow(<ListComp {...props} />);
    expect(wrapper.find('.filterList').length).toBe(1);
  });
});
