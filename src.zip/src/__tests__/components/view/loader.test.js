import React from 'react';
import Enzyme, { mount, shallow } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import { Loader } from 'components/view/Loader';

Enzyme.configure({ adapter: new Adapter() });

describe('Unit testing List', () => {
  it('should display loader icon if the state is true', () => {
    const props = { loading: true };
    const wrapper = shallow(<Loader {...props} />);
    expect(wrapper.find('.loader').length).toBe(1);
  });
});
