import React from 'react';
import { act } from '@testing-library/react';
import Enzyme, { mount, shallow } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import { Header } from 'components/view/AppBar';
import { graphicAttr } from 'utils/_sampleData';
const _context = require('utils/_context');
const NR = require('utils/_newRelicReporting');

Enzyme.configure({ adapter: new Adapter() });

let wrapper;
const reporting = jest.spyOn(NR, 'triggerNewRelicAction');

describe('Unit testing AppBar', () => {
  const contextMock = {
    apiKey: 'test',
  };
  const routeContextMock = {
    checkedList: ['all'],
    handleCheckedList: jest.fn(),
    expandedList: ['all'],
    handleExpandedList: jest.fn(),
  };
  beforeEach(() => {
    // jest
    //   .spyOn(_context, 'useAppDataContext')
    //   .mockImplementation(() => {
    //     return { apiKey: 'testAPIKey' }
    //   });
    jest.spyOn(_context, 'useAppDataContext').mockImplementation(() => {
      return { apiKey: 'testAPIKey' };
    });

    jest
      .spyOn(_context, 'useRouteListContext')
      .mockImplementation(() => routeContextMock);

    jest
      .spyOn(_context, 'useGraphicDataContext')
      .mockImplementation(() => graphicAttr);

    jest.spyOn(_context, 'useModeContext').mockImplementation(() => {
      return { setMode: jest.fn, mode: 'key' };
    });
  });

  it('should display AppBar', async () => {
    await act(async () => {
      wrapper = mount(<Header />);
    });
    expect(wrapper.find('.appBar').length).toBeGreaterThan(1);
    expect(wrapper.find('.toolbar').length).toBeGreaterThan(1);
  });

  it('should display Filter map button and text', async () => {
    await act(async () => {
      wrapper = mount(<Header />);
    });
    expect(wrapper.find('#filterTxt').length).toBeGreaterThan(1);
    expect(wrapper.find('#FilterListIcon').length).toBeGreaterThan(1);
  });

  it('should display key button and text', async () => {
    await act(async () => {
      wrapper = mount(<Header />);
    });
    expect(wrapper.find('#MapIcon').length).toBeGreaterThan(1);
    expect(wrapper.find('#keyTxt').length).toBeGreaterThan(1);
  });

  it('should display reset button and text', async () => {
    await act(async () => {
      wrapper = mount(<Header />);
    });
    expect(wrapper.find('#CachedIcon').length).toBeGreaterThan(1);
    expect(wrapper.find('#resetTxt').length).toBeGreaterThan(1);
    expect(wrapper.find('.reset').length).toBeGreaterThan(1);
  });

  it('should call reporting and setMode to reset when reset is clicked', async () => {
    const spy = jest
      .spyOn(_context, 'useModeContext')
      .mockImplementation(() => {
        return { setMode: jest.fn };
      });

    await act(async () => {
      wrapper = mount(<Header />);
    });
    wrapper.find('.reset').first().simulate('click');
    expect(reporting).toHaveBeenCalled();
    expect(spy).toHaveBeenCalled();
  });

  it('should render key card when key button is clicked', async () => {
    await act(async () => {
      wrapper = mount(<Header />);
    });
    wrapper.find('.key').first().simulate('click');

    expect(reporting).toHaveBeenCalled();
    expect(wrapper.find('.keyComponent').length).toBe(1);
  });
});

describe('with mode as graphicData', () => {
  beforeEach(() => {
    jest.spyOn(_context, 'useAppDataContext').mockImplementation(() => {
      return { apiKey: 'testAPIKey' };
    });

    jest
      .spyOn(_context, 'useGraphicDataContext')
      .mockImplementation(() => graphicAttr);

    jest.spyOn(_context, 'useModeContext').mockImplementation(() => {
      return { setMode: jest.fn, mode: 'graphicData' };
    });
  });

  it('should setMode as graphicData if cardContext is graphicData', async () => {
    await act(async () => {
      wrapper = mount(<Header />);
    });

    wrapper.update();
    expect(wrapper.find('.nav').props().mode).toBe('graphicData');
  });
});

describe('with mode as graphicData', () => {
  const routeContextMock = {
    checkedList: ['all'],
    handleCheckedList: jest.fn(),
    expandedList: ['all'],
    handleExpandedList: jest.fn(),
  };
  beforeEach(() => {
    jest.spyOn(_context, 'useAppDataContext').mockImplementation(() => {
      return { apiKey: 'testAPIKey' };
    });

    jest.spyOn(_context, 'useModeContext').mockImplementation(() => {
      return { setMode: jest.fn, mode: 'filter' };
    });

    jest
      .spyOn(_context, 'useRouteListContext')
      .mockImplementation(() => routeContextMock);
  });

  it('should render filter card when filter map button is clicked', async () => {
    await act(async () => {
      wrapper = mount(<Header />);
    });
    wrapper.find('.filter').first().simulate('click');
    expect(reporting).toHaveBeenCalled();
    expect(wrapper.find('.collapsableList').length).toBe(1);
  });
});
