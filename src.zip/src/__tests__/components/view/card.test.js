import React from 'react';
import Enzyme, { mount, shallow } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import { CardComp } from 'components/view/Card';

Enzyme.configure({ adapter: new Adapter() });

describe('Unit testing Card', () => {
  const props = {
    title: 'title',
    subtitle: 'subtitle',
    content: 'content',
    action: jest.fn(),
  };

  it('should display a card', () => {
    const wrapper = shallow(<CardComp {...props} />);
    expect(wrapper.find('.card').length).toBe(1);
  });

  it('should display a card header ', () => {
    const wrapper = shallow(<CardComp {...props} />);
    expect(wrapper.find('.cardHeader').length).toBe(1);
  });

  it('should display a card title', () => {
    const wrapper = shallow(<CardComp {...props} />);

    expect(wrapper.find('.title').length).toBe(1);
    expect(wrapper.find('.title').text()).toEqual('title');
  });

  it('should display a card subtitle', () => {
    const wrapper = shallow(<CardComp {...props} />);

    expect(wrapper.find('.subtitle').length).toBe(1);
    expect(wrapper.find('.subtitle').text()).toEqual('subtitle');
  });
});
