import React from 'react';
import Enzyme, { mount, shallow } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import { Nav, CloseAction } from 'components/content/Nav';

import { graphicAttr } from 'utils/_sampleData';

const _context = require('utils/_context');
const graphicData = require('components/content/GraphicData');

Enzyme.configure({ adapter: new Adapter() });

const contextMock = {
  mode: 'filter',
  setMode: jest.fn(),
};
const routeContextMock = {
  checkedList: ['all'],
  handleCheckedList: jest.fn(),
  expandedList: ['all'],
  handleExpandedList: jest.fn(),
};
beforeEach(() => {
  jest.spyOn(_context, 'useModeContext').mockImplementation(() => contextMock);
  jest
    .spyOn(_context, 'useGraphicDataContext')
    .mockImplementation(() => graphicAttr);
  // jest.spyOn(graphicData, 'GraphicData')
  // jest.spyOn(graphicData, 'GraphicTitle')
  jest
    .spyOn(_context, 'useRouteListContext')
    .mockImplementation(() => routeContextMock);
});

describe('Unit testing Nav', () => {
  it('should return filter Component and filter content if the mode is filter', () => {
    const prop = { mode: 'filter' };
    const wrapper = shallow(<Nav {...prop} />);

    expect(wrapper.find('.cardComp').length).toBe(1);
    expect(wrapper.props().title).toEqual('Filter map content');
  });

  it('should return key Component if the mode is key', () => {
    const prop = { mode: 'key' };
    const wrapper = shallow(<Nav {...prop} />);
    expect(wrapper.find('.cardComp').length).toBe(1);
    expect(wrapper.props().title).toEqual('Key');
  });

  it('should display a card header with close iconButton', () => {
    const wrapper = shallow(<CloseAction />);
    expect(wrapper.find('.closeBtn').length).toBe(1);
  });

  it('should display a card header with close iconButton', () => {
    const wrapper = mount(<CloseAction />);
    wrapper.find('.closeBtn').first().simulate('click');
  });

  it('should display graphicData if mode is graphicData', () => {
    const prop = { mode: 'graphicData' };
    const wrapper = shallow(<Nav {...prop} />);
    expect(wrapper.find('.graphicDataComp').length).toBe(1);
  });
});
