import React from 'react';
import Enzyme, { mount } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import { KeyListItem } from 'components/content/Keys';
import { state, checkedState, stateWithCables } from 'utils/_sampleData';

const _context = require('utils/_context');

Enzyme.configure({ adapter: new Adapter() });

describe('Unit testing KeyList', () => {
  beforeEach(() => {
    jest.spyOn(_context, 'useFilterNodeContext').mockImplementation(() => {
      return { state: checkedState };
    });
  });

  it('should load list items', () => {
    const wrapper = mount(<KeyListItem />);
    expect(wrapper.find('.keyListItem').length).toBeGreaterThan(0);
  });

  it('should load list items text', () => {
    const wrapper = mount(<KeyListItem />);
    expect(wrapper.find('.key').length).toBeGreaterThan(0);
  });

  it('should load list items icons', () => {
    const wrapper = mount(<KeyListItem />);
    expect(wrapper.find('.listItemIcon').length).toBeGreaterThan(0);
  });
});

describe('Unit testing KeyList with negative scenarios', () => {
  beforeEach(() => {
    jest.spyOn(_context, 'useFilterNodeContext').mockImplementation(() => {
      return { state };
    });
  });

  it('should not load keys if the icon is not given or checked is more than 0', () => {
    const wrapper = mount(<KeyListItem />);
    expect(wrapper.find('.listItemIcon').length).toBe(0);
  });

  it('should add landing station if keyList has cables', () => {
    jest.spyOn(_context, 'useFilterNodeContext').mockImplementation(() => {
      return { stateWithCables };
    });
    const wrapper = mount(<KeyListItem />);
    expect(wrapper.find('.landing station').length).toBe(0);
  });
});
