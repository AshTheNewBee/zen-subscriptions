import React from 'react';
import Enzyme, { mount, shallow } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import { act } from '@testing-library/react';
import {
  FilterListItems,
  CollapsableList,
  FilterListItem,
  FilterListIcons,
  FilterCheckBox,
} from 'components/content/FilterListItems';
import { routeFilters } from 'utils/data/_routes';
import { state, stateWithChildren } from 'utils/_sampleData';

const routeContext = require('utils/_context');
const NR = require('utils/_newRelicReporting');
const reporting = jest.spyOn(NR, 'triggerNewRelicAction');

Enzyme.configure({ adapter: new Adapter() });

const contextMock = {
  checkedList: ['all'],
  handleCheckedList: jest.fn(),
  expandedList: ['all'],
  handleExpandedList: jest.fn(),
};

afterEach(() => {
  jest.clearAllMocks();
});

//------------------------ CollapsableList (no child)----------------------------------

describe('Unit testing Filter List Items', () => {
  let wrapper;

  beforeEach(() => {
    jest.spyOn(routeContext, 'useFilterNodeContext').mockImplementation(() => {
      return { state };
    });

    jest.spyOn(routeContext, 'useAppDataContext').mockImplementation(() => {
      return { apiKey: 'testApiKey' };
    });
    jest
      .spyOn(routeContext, 'useRouteListContext')
      .mockImplementation(() => contextMock);
  });

  // it('should display FilterListItems', async () => {
  //   const props = {
  //     mode: 'filter',
  //   };
  //   wrapper = mount(<FilterListItems {...props} />);
  //   expect(wrapper.find('.collapsableList').length).toBe(1);
  // });

  it('should display FilterListItems', async () => {
    const props = {
      mode: 'filter',
    };
    wrapper = mount(<FilterListItems {...props} />);
    expect(wrapper.find('.collapsableList').length).toBe(1);
  });

  it('should only display filterListItem if filter state does not contain children', async () => {
    const props = {
      filterTree: routeFilters,
    };

    await act(async () => {
      wrapper = mount(<CollapsableList {...props} />);
    });

    wrapper.update();
    expect(wrapper.find('.filterListItem').length).toBe(1);
    expect(wrapper.find('.divider').length).toBe(0);
    expect(wrapper.find('.collapse').length).toBe(0);
    expect(wrapper.find('.list').length).toBe(0);
  });
});

describe('Unit testing Filter List Items2', () => {
  let wrapper;

  beforeEach(() => {
    jest.spyOn(routeContext, 'useFilterNodeContext').mockImplementation(() => {
      return { state };
    });

    jest.spyOn(routeContext, 'useAppDataContext').mockImplementation(() => {
      return { apiKey: 'testApiKey' };
    });
    jest
      .spyOn(routeContext, 'useRouteListContext')
      .mockImplementation(() => contextMock);
  });

  it('should only display filterListItem if filter state does not contain children', async () => {
    const props = {
      filterTree: routeFilters,
      mode: 'filter',
    };

    await act(async () => {
      wrapper = mount(<FilterListItems {...props} />);
    });

    wrapper.update();
    expect(wrapper.find('.collapsableList').length).toBe(1);
  });
});

//------------------------ CollapsableList with Children----------------------------------

describe('Unit testing Filter List Items with Children', () => {
  let wrapper;
  const contextMock = {
    state: stateWithChildren,
  };

  beforeEach(() => {
    jest
      .spyOn(routeContext, 'useFilterNodeContext')
      .mockImplementation(() => contextMock);

    jest.spyOn(routeContext, 'useAppDataContext').mockImplementation(() => {
      return { apiKey: 'testApiKey' };
    });
  });

  it('should only display filterListItem, Collapse, List and another CollapsableList if filter state contain children', async () => {
    const props = {
      filterTree: routeFilters,
    };

    await act(async () => {
      wrapper = mount(<CollapsableList {...props} />);
    });

    wrapper.update();
    expect(wrapper.find('.filterListItem').length).toBeGreaterThan(1);
    expect(wrapper.find('.divider').length).toBeGreaterThanOrEqual(1);
    expect(wrapper.find('.collapse').length).toBeGreaterThanOrEqual(1);
    expect(wrapper.find('.list').length).toBeGreaterThanOrEqual(1);
  });

  it('should display FilterListItem', async () => {
    const props = {
      item: stateWithChildren['all'],
    };

    await act(async () => {
      wrapper = mount(<FilterListItem {...props} />);
    });

    expect(wrapper.find('.listItem').length).toBeGreaterThanOrEqual(1);
    expect(wrapper.find('.filterListIcons').length).toBeGreaterThanOrEqual(1);
    expect(wrapper.find('.filterCheckBox').length).toBeGreaterThanOrEqual(1);
  });
});

//------------------------ FilterListIcons ----------------------------------

describe('Unit testing FilterListIcons', () => {
  let wrapper, handleChangeMock;

  beforeEach(() => {
    jest.spyOn(routeContext, 'useFilterNodeContext').mockImplementation(() => {
      return { state };
    });

    jest.spyOn(routeContext, 'useAppDataContext').mockImplementation(() => {
      return { apiKey: 'testApiKey' };
    });
    jest
      .spyOn(routeContext, 'useRouteListContext')
      .mockImplementation(() => contextMock);

    handleChangeMock = jest
      .spyOn(routeContext, 'useFilterNodeContext')
      .mockImplementation(() => {
        return { handleChange: jest.fn() };
      });
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should display RemoveIcon and handlechange when icon is clicked', async () => {
    const props = {
      nodeValue: 1,
      nodeExpanded: true,
      nodeDepth: 1,
    };

    await act(async () => {
      wrapper = mount(<FilterListIcons {...props} />);
    });

    expect(wrapper.find('.removeIcon').length).toBeGreaterThanOrEqual(1);
    expect(wrapper.find('.lessIcon').length).toBe(0);
    expect(wrapper.find('.addIcon').length).toBe(0);
    expect(wrapper.find('.moreIcon').length).toBe(0);

    wrapper.find('.removeIcon').at(1).simulate('click');
    expect(handleChangeMock).toHaveBeenCalled();
  });

  it('should display ExpandLessIcon and handlechange when icon is clicked', async () => {
    const props = {
      nodeValue: 1,
      nodeExpanded: true,
      nodeDepth: 2,
    };

    await act(async () => {
      wrapper = mount(<FilterListIcons {...props} />);
    });

    expect(wrapper.find('.removeIcon').length).toBe(0);
    expect(wrapper.find('.lessIcon').length).toBeGreaterThanOrEqual(1);
    expect(wrapper.find('.addIcon').length).toBe(0);
    expect(wrapper.find('.moreIcon').length).toBe(0);

    wrapper.find('.lessIcon').at(1).simulate('click');
    expect(handleChangeMock).toHaveBeenCalled();
  });

  it('should display AddIcon and handlechange when icon is clicked', async () => {
    const props = {
      nodeValue: 1,
      nodeExpanded: false,
      nodeDepth: 1,
    };

    await act(async () => {
      wrapper = mount(<FilterListIcons {...props} />);
    });

    expect(wrapper.find('.removeIcon').length).toBe(0);
    expect(wrapper.find('.lessIcon').length).toBe(0);
    expect(wrapper.find('.addIcon').length).toBeGreaterThanOrEqual(1);
    expect(wrapper.find('.moreIcon').length).toBe(0);

    wrapper.find('.addIcon').at(1).simulate('click');
    expect(handleChangeMock).toHaveBeenCalled();
  });

  it('should display ExpandMoreIcon and handlechange when icon is clicked', async () => {
    const props = {
      nodeValue: 1,
      nodeExpanded: false,
      nodeDepth: 2,
    };

    await act(async () => {
      wrapper = mount(<FilterListIcons {...props} />);
    });

    expect(wrapper.find('.removeIcon').length).toBe(0);
    expect(wrapper.find('.lessIcon').length).toBe(0);
    expect(wrapper.find('.addIcon').length).toBe(0);
    expect(wrapper.find('.moreIcon').length).toBeGreaterThanOrEqual(1);

    wrapper.find('.moreIcon').at(1).simulate('click');
    expect(reporting).toHaveBeenCalled();
    expect(handleChangeMock).toHaveBeenCalled();
  });

  it('should display FilterCheckBox and handle checkBox', async () => {
    const props = {
      node: stateWithChildren['all'],
    };

    await act(async () => {
      wrapper = mount(<FilterCheckBox {...props} />);
    });

    expect(wrapper.find('.filterCheckBox').length).toBeGreaterThanOrEqual(1);

    wrapper.find('.filterCheckBox').at(1).simulate('change');
    expect(handleChangeMock).toHaveBeenCalled();
  });

  it('should have checked value of false if props has checked value of 0', async () => {
    const props = {
      node: stateWithChildren['all'],
    };

    await act(async () => {
      wrapper = mount(<FilterCheckBox {...props} />);
    });

    const checked = wrapper.find('.filterCheckBox').at(1).props().checked;
    expect(checked).toBe(false);
  });

  it('should have checked value of true if props has checked value of 1', async () => {
    const props = {
      node: {
        checked: 1,
      },
    };

    await act(async () => {
      wrapper = mount(<FilterCheckBox {...props} />);
    });
    const checked = wrapper.find('.filterCheckBox').at(1).props().checked;
    expect(checked).toBe(true);
  });

  it('should have indeterminate value of true if props has checked value of 2', async () => {
    const props = {
      node: {
        checked: 2,
      },
    };

    await act(async () => {
      wrapper = mount(<FilterCheckBox {...props} />);
    });
    const indeterminate = wrapper.find('.filterCheckBox').at(1).props()
      .indeterminate;
    expect(indeterminate).toBe(true);
  });

  it('should have indeterminate value of false if props has checked value of 0', async () => {
    const props = {
      node: {
        checked: 0,
      },
    };

    await act(async () => {
      wrapper = mount(<FilterCheckBox {...props} />);
    });
    const indeterminate = wrapper.find('.filterCheckBox').at(1).props()
      .indeterminate;
    expect(indeterminate).toBe(false);
  });

  it('should call reporting when checkbox is checked', async () => {
    const props = {
      node: stateWithChildren['all'],
    };

    await act(async () => {
      wrapper = mount(<FilterCheckBox {...props} />);
    });

    const event = {
      preventDefault() {},
      target: { checked: 'true' },
    };

    const input = wrapper.find('input');
    input.getDOMNode().checked = !input.getDOMNode().checked;
    input.simulate('change', event);

    expect(handleChangeMock).toHaveBeenCalled();
    expect(reporting).toHaveBeenCalled();
  });

  it('should call reporting when checkbox is unchecked', async () => {
    const props = {
      node: stateWithChildren['all'],
    };

    await act(async () => {
      wrapper = mount(<FilterCheckBox {...props} />);
    });

    const event = {
      preventDefault() {},
      target: { checked: 'false' },
    };

    const input = wrapper.find('input');
    input.getDOMNode().checked = !input.getDOMNode().checked;
    input.simulate('change', event);

    expect(handleChangeMock).toHaveBeenCalled();
    expect(reporting).toHaveBeenCalled();
  });

  it('should check the partners if checked item has a partner', () => {});
});
