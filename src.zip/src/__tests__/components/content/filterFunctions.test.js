import { flattenFilterNodes } from 'components/content/FilterFunctions';

describe('Unit testing FlattenFilterNodes', () => {
  it('should not return anything if the nodes are empty', () => {
    const flatNodes = flattenFilterNodes({}, [], {}, 0);
    expect(flatNodes).toBe(undefined);
  });

  it('should return the flattern values', () => {
    const nodes = [
      {
        label: 'Network by Market',
        value: 'sub-search1',
      },
    ];
    const result = {
      'sub-search1': {
        checked: 0,
        value: 'sub-search1',
        label: 'Network by Market',
        isChild: false,
        isParent: false,
        parent: {},
        children: undefined,
        showCheckbox: true,
        showDivider: false,
        expanded: false,
        treeDepth: 0,
        index: 0,
        partners: undefined,
        icon: undefined,
      },
    };

    const flatNodes = flattenFilterNodes({}, nodes, {}, 0);
    expect(flatNodes).toEqual(result);
  });
});
