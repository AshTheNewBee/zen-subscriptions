import React from 'react';
import Enzyme, { shallow } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import {
  GraphicData,
  ProcessGraphicData,
  GraphicTitle,
  GraphicSubTitle,
} from 'components/content/GraphicData';
import {
  graphicAttr,
  graphicAttrTPN,
  graphicAttrCloudNode,
  graphicAttrColocations,
  graphicAttrDefault,
  graphicAttrPoP,
  graphicAttrCable,
  graphicAttrDataCentre,
  graphicAttrTeleports,
  graphicAttrPoPemptyAddress,
} from 'utils/_sampleData';
const _context = require('utils/_context');

Enzyme.configure({ adapter: new Adapter() });

describe('Unit testing GraphicData', () => {
  const processedData = {
    location: 'Indonesia',
  };

  beforeEach(() => {
    jest.spyOn(_context, 'useGraphicDataContext').mockImplementation(() => {
      return { graphicData: graphicAttr };
    });
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should display graphic Data ListItem and graphic text', () => {
    let wrapper = shallow(<GraphicData />);
    expect(wrapper.find('.graphicDataListItem').length).toBeGreaterThanOrEqual(
      1
    );
    expect(wrapper.find('.graphicTxt').length).toBeGreaterThanOrEqual(1);

    jest.spyOn(_context, 'useGraphicDataContext').mockImplementation(() => {
      return { graphicData: graphicAttrDefault };
    });
    wrapper = shallow(<GraphicData />);
    expect(wrapper.find('.graphicDataListItem').length).toBe(1);
    expect(wrapper.find('.graphicTxt').length).toBe(1);
  });

  it('should return title and processData of the graphic for TPN', () => {
    jest.spyOn(_context, 'useGraphicDataContext').mockImplementation(() => {
      return { graphicData: graphicAttrTPN };
    });

    expect(GraphicTitle()).toBe('Indonesia');
    expect(GraphicSubTitle()).toBe('TPN');
    expect(ProcessGraphicData()).toMatchObject(processedData);
  });

  it('should return title and processData of the graphic for PoP', () => {
    jest.spyOn(_context, 'useGraphicDataContext').mockImplementation(() => {
      return { graphicData: graphicAttrPoP };
    });

    const processedPoPData = { products: 'IPVPN', address: 'testAddress' };

    expect(GraphicTitle()).toBe('Indonesia');
    expect(GraphicSubTitle()).toBe('pop-pops');
    expect(ProcessGraphicData()).toMatchObject(processedPoPData);
  });

  it('should return title and processData of the graphic for PoP with empty address', () => {
    jest.spyOn(_context, 'useGraphicDataContext').mockImplementation(() => {
      return { graphicData: graphicAttrPoPemptyAddress };
    });

    const processedPoPData = {
      products: 'IPVPN',
      address: 'testAddress',
    };

    expect(GraphicTitle()).toBe('Indonesia');
    expect(GraphicSubTitle()).toBe('pop-pops');
    expect(ProcessGraphicData()).toMatchObject(processedPoPData);

    jest.spyOn(_context, 'useGraphicDataContext').mockImplementation(() => {
      return { graphicData: null };
    });

    expect(ProcessGraphicData()).toBeUndefined();
  });

  it('should return title and processData of the graphic for office', () => {
    jest.spyOn(_context, 'useGraphicDataContext').mockImplementation(() => {
      return { graphicData: graphicAttr };
    });

    const processedOfficeData = {
      address: 'testAddress',
    };

    expect(GraphicTitle()).toBe('Indonesia');
    expect(GraphicSubTitle()).toBe('Office');
    expect(ProcessGraphicData()).toMatchObject(processedOfficeData);
  });

  it('should return title and processData of the graphic for cable', () => {
    jest.spyOn(_context, 'useGraphicDataContext').mockImplementation(() => {
      return { graphicData: graphicAttrCable };
    });

    const processedCableData = {
      name: 'cableName',
      length: '2453 mts',
      'Fibre Pairs': '10',
    };

    expect(GraphicTitle()).toBe('testCity');
    expect(GraphicSubTitle()).toBe('network');

    expect(ProcessGraphicData()).toMatchObject(processedCableData);
  });

  it('should return title and processData of the graphic for CloudNode', () => {
    jest.spyOn(_context, 'useGraphicDataContext').mockImplementation(() => {
      return { graphicData: graphicAttrCloudNode };
    });

    expect(ProcessGraphicData()).toMatchObject(processedData);
    expect(GraphicTitle()).toBe('Indonesia');
  });

  it('should return title and processData of the graphic for Colocations', () => {
    jest.spyOn(_context, 'useGraphicDataContext').mockImplementation(() => {
      return { graphicData: graphicAttrColocations };
    });

    expect(ProcessGraphicData()).toMatchObject(processedData);
    expect(GraphicTitle()).toBe('Indonesia');
  });

  it('should return title and processData of the graphic for other', () => {
    jest.spyOn(_context, 'useGraphicDataContext').mockImplementation(() => {
      return { graphicData: graphicAttrDefault };
    });

    expect(ProcessGraphicData()).toMatchObject(processedData);
    expect(GraphicTitle()).toBe('Indonesia');
  });

  it('should return title and processData of the graphic for Teleports', () => {
    jest.spyOn(_context, 'useGraphicDataContext').mockImplementation(() => {
      return { graphicData: graphicAttrTeleports };
    });

    expect(ProcessGraphicData()).toMatchObject(processedData);
    expect(GraphicTitle()).toBe('Indonesia');
  });

  it('should return title and processData of the graphic for DataCentre', () => {
    jest.spyOn(_context, 'useGraphicDataContext').mockImplementation(() => {
      return { graphicData: graphicAttrDataCentre };
    });

    expect(ProcessGraphicData()).toMatchObject(processedData);
    expect(GraphicTitle()).toBe('Indonesia');
  });
});
