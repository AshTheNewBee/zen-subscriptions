import { FetchQueryParam, FindLayers } from 'components/helper/Helper';
import { _mapView } from 'utils/_sampleData';

describe('Helpers', () => {
  it('should return query when FetchQueryParam is called', () => {
    const qs = require('qs');
    jest.spyOn(qs, 'parse').mockImplementation(() => {
      return { filter: 'network, pop' };
    });
    expect(FetchQueryParam()).toEqual({ filter: 'network, pop' });
  });

  it('should return the found layer', () => {
    const _layer = FindLayers(_mapView.map, 'graphicLayer');
    expect(_layer.id).toBe('graphicLayer');
  });

  it('should not return the layer if layer is not found', () => {
    expect(FindLayers(_mapView.map, 'layerNotFound')).toEqual(undefined);
  });
});
