import React from 'react';
import { act } from '@testing-library/react';
import Enzyme, { mount, shallow } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import {
  WebMapView,
  displaySelectedGraphics,
  toggleLayerVisibility,
  HighlightGraphic,
  MapEventListner,
  updateList,
} from 'components/Map';
import { _mapView, _mapPopView, items } from 'utils/_sampleData';

const promise = require('utils/esri/EsriLoader');
const routeContext = require('utils/_context');
const graphicHandler = require('components/controller/GraphicHandler');
const helper = require('components/helper/Helper');
const map = require('components/Map');
const route = require('utils/data/_routes');

Enzyme.configure({ adapter: new Adapter() });

const appData = {
  apiKey: 'testAPIKey',
};

describe('Unit testing Map', () => {
  let wrapper, graphicLayerSpy;

  beforeEach(() => {
    jest.spyOn(graphicHandler, 'DisplayGraphics');
    graphicLayerSpy = jest
      .spyOn(helper, 'FindLayers')
      .mockImplementation(() => {
        return {
          id: 'graphicLayer',
          removeAll: jest.fn(),
          graphics: {
            items,
          },
        };
      });

    jest
      .spyOn(routeContext, 'useAppDataContext')
      .mockImplementation(() => appData);

    jest.spyOn(promise, 'loadMap').mockImplementation(() => {
      return Promise.resolve(_mapView);
    });
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  //updateList
  it('should call setState to append to the list', () => {
    const setState = jest.fn().mockImplementation(() => {
      return [];
    });

    updateList(true, [], 'a', setState);
    expect(setState).toHaveBeenCalled();
  });

  it('should not call setState to append to the list', () => {
    const setState = jest.fn().mockImplementation(() => {
      return ['a'];
    });

    updateList(true, ['a'], 'a', setState);
    expect(setState).not.toHaveBeenCalled();
  });

  it('should call setState to remove item from the list', () => {
    const setState = jest.fn().mockImplementation(() => {
      return ['a'];
    });

    updateList(false, [], 'a', setState);
    expect(setState).toHaveBeenCalled();
  });

  it('should display the map container', () => {
    wrapper = shallow(<WebMapView />);
    expect(wrapper.find('.mapContainer').length).toBe(1);
    expect(wrapper.find('.webmap').length).toBe(1);
  });

  it('should load the Map', async () => {
    const testSpy = jest.spyOn(promise, 'loadMap').mockImplementation(() => {
      return Promise.resolve(_mapView);
    });
    await act(async () => {
      wrapper = await mount(<WebMapView />);
    });
    expect(testSpy).toHaveBeenCalled();
  });

  it('should change the graphic visibility if checkedList conatains the graphic in a particular region', async () => {
    await displaySelectedGraphics(_mapView, ['testNetworkId-1', 'Asia']);
    expect(_mapView.view.graphics[0].visible).toBe(true);
  });

  it('should not show the graphics if the particular region is not contained on checkedList', async () => {
    jest.spyOn(route, 'regionList').mockImplementation(() => ['Africa']);

    await displaySelectedGraphics(_mapView, ['testNetworkId-1', 'Somewhere']);
    expect(_mapView.view.graphics[0].visible).toBe(true);
  });

  it('should change the POP graphic visibility if checkedList conatains the graphic', async () => {
    jest.spyOn(route, 'regionList').mockImplementation(() => ['Asia']);
    await displaySelectedGraphics(_mapView, ['_type', 'Asia']);
    expect(_mapView.view.graphics[2].visible).toBe(true);
  });

  it('should not change the graphic visibility if checkedList does not conatains the graphic', async () => {
    await displaySelectedGraphics(_mapView, []);
    expect(_mapView.view.graphics[0].visible).toBe(false);
  });

  it('should not change the graphic visibility if checkedList does not conatains the graphic,  passing popattr', async () => {
    await displaySelectedGraphics(_mapPopView, ['all']);
    expect(_mapPopView.view.graphics[0].visible).toBe(true);
  });

  it('should not change the graphic visibility if checkedList does not conatains the graphic passing  another popattr', async () => {
    await displaySelectedGraphics(_mapPopView, []);
    expect(_mapPopView.view.graphics[0].visible).toBe(false);
  });

  // it('should not toggle visiblility if the layer does not exists', () => {
  //   toggleLayerVisibility(_mapView, 'abc', false);
  //   expect(_mapPopView.map.layers.items[0].visible).toBe(true);
  // });

  it('should add checkedList, handleCheckedList, expandedList, handleExpandedList to RouteListProvider', async () => {
    await act(async () => {
      wrapper = shallow(<WebMapView />);
    });

    expect(wrapper.props().children[0].props.value.checkedList).toEqual([
      'all',
    ]);
    expect(wrapper.props().children[0].props.value.expandedList).toEqual([
      'all',
    ]);
  });

  // // it('should call displaySelectedGraphics after map is loaded', async () => {
  // //   const spy = jest.spyOn(map, 'displaySelectedGraphics');

  // //   jest.spyOn(promise, 'loadMap').mockImplementation(() => {
  // //     return Promise.resolve(_mapView);
  // //   });

  // //   await act(async () => {
  // //     wrapper = mount(<WebMapView />);
  // //   });

  // //   wrapper.update();
  // //   //expect(displaySelectedGraphics.mock.calls.length).toBe(1);
  // //   expect(spy).toHaveBeenCalled();
  // // });

  it('should display Header when graphic is clicked', async () => {
    jest.spyOn(promise, 'loadMap').mockImplementation(() => {
      return Promise.resolve(_mapView);
    });

    await act(async () => {
      wrapper = mount(<WebMapView />);
    });

    wrapper.update();
    expect(_mapView.view.on).toHaveBeenCalled();
    //expect(_mapView.view.hitTest).toHaveBeenCalled();
  });
});

describe('satellite layer', () => {
  let wrapper;
  beforeEach(() => {
    jest.spyOn(graphicHandler, 'DisplayGraphics');

    jest.spyOn(helper, 'FindLayers').mockImplementation(() => {
      return {
        id: 'satelliteLayer',
        removeAll: jest.fn(),
        graphics: {
          items,
        },
      };
    });

    jest
      .spyOn(routeContext, 'useAppDataContext')
      .mockImplementation(() => appData);

    jest.spyOn(promise, 'loadMap').mockImplementation(() => {
      return Promise.reject();
    });

    jest.spyOn(graphicHandler, 'DisplayGraphics');
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should show loader until mapView is loaded', () => {
    wrapper = shallow(<WebMapView />);
    expect(wrapper.find('.graphicLoader').length).toBe(1);
  });

  // it('should toggle off the visibility of satelliteLayer if checkedList contains satellite coverage', async () => {
  //   await displaySelectedGraphics(_mapView, []);
  //   expect(_mapPopView.map.layers.items[0].visible).toBe(false);
  // });

  it('should toggle on the visibility of satelliteLayer if checkedList contains satellite coverage', async () => {
    await displaySelectedGraphics(_mapView, ['infra-sat-coverage']);
    expect(_mapPopView.map.layers.items[0].visible).toBe(true);
  });

  // it('should toggle visible only if the layer exists', () => {
  //   toggleLayerVisibility(_mapView, 'satelliteCoverage', false);
  //   expect(_mapPopView.map.layers.items[0].visible).toBe(false);
  // });
});

//------------ RESET ----------------------------

describe('RESET', () => {
  let wrapper, graphicLayerSpy;

  beforeEach(async () => {
    jest.spyOn(graphicHandler, 'DisplayGraphics');
    graphicLayerSpy = jest
      .spyOn(helper, 'FindLayers')
      .mockImplementation(() => {
        return {
          id: 'graphicLayer',
          removeAll: jest.fn(),
          graphics: {
            items,
          },
        };
      });

    jest
      .spyOn(routeContext, 'useAppDataContext')
      .mockImplementation(() => appData);

    jest.spyOn(promise, 'loadMap').mockImplementation(() => {
      return Promise.resolve(_mapView);
    });

    const fn = jest.fn();
    const setCheckedListSpy = jest.spyOn(React, 'useState');
    //spying the states - should be in correct order
    setCheckedListSpy
      .mockImplementationOnce(() => ['reset', fn]) //mode
      .mockImplementationOnce(() => [['all'], fn]) //checkedList
      .mockImplementationOnce(() => [['all'], fn]) //expandedList
      .mockImplementationOnce(() => [_mapView, fn]) //mapView
      .mockImplementationOnce(() => [null, fn]) //graphicData
      .mockImplementationOnce(() => [true, fn]) //isFiltered
      .mockImplementationOnce(() => [false, fn]); //isLoaded

    await jest.spyOn(graphicHandler, 'DisplayGraphics');
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should show loader until mapView is loaded', () => {
    wrapper = shallow(<WebMapView />);
    expect(wrapper.find('.graphicLoader').length).toBe(1);
  });

  it('should call setCheckedList with all selection', async () => {
    const setCheckedListSpy = jest.spyOn(React, 'useState');

    jest.spyOn(promise, 'loadMap').mockImplementation(() => {
      return Promise.resolve(_mapView);
    });

    await act(async () => {
      wrapper = mount(<WebMapView />);
    });

    wrapper.update();
    expect(setCheckedListSpy).toHaveBeenCalled();
    expect(setCheckedListSpy).toHaveBeenCalledWith(['all']);
  });

  it('should call displaySelectedGraphics', async () => {
    // const displaySelectedGraphicsSpy = jest.spyOn(
    //   map,
    //   'displaySelectedGraphics'
    // );

    jest.spyOn(promise, 'loadMap').mockImplementation(() => {
      return Promise.resolve(_mapView);
    });

    await act(async () => {
      wrapper = mount(<WebMapView />);
    });

    wrapper.update();
    //expect(displaySelectedGraphicsSpy).toHaveBeenCalled();
  });

  it('should center map if it is not centered and set mode to false', async () => {
    const resetMapSpy = jest.spyOn(promise, 'resetMap');
    const setModeSpy = jest.spyOn(React, 'useState');

    jest.spyOn(promise, 'loadMap').mockImplementation(() => {
      return Promise.resolve(_mapView);
    });

    await act(async () => {
      wrapper = mount(<WebMapView />);
    });

    wrapper.update();
    expect(resetMapSpy).toHaveBeenCalled();
    expect(setModeSpy).toHaveBeenCalledWith(false);
  });

  it('should call set mode to graphic data and call setGraphicData if graphic is clicked', async () => {
    const setModeSpy = jest.spyOn(React, 'useState');
    jest.spyOn(promise, 'loadMap').mockImplementation(() => {
      return Promise.resolve(_mapView);
    });

    await act(async () => {
      wrapper = mount(<WebMapView />);
    });

    _mapView.view.hitTest('click');
    wrapper.update();

    expect(_mapView.view.on).toHaveBeenCalled();
    expect(_mapView.view.hitTest).toHaveBeenCalled();
    expect(setModeSpy).toHaveBeenCalled();
  });

  it('should show checkList if the filter query param is passed', async () => {
    const displayGraphic = await jest.spyOn(graphicHandler, 'DisplayGraphics');
    const setIsFilterSpy = jest.spyOn(React, 'useState');
    const helper = require('components/helper/Helper');

    jest.spyOn(helper, 'FetchQueryParam').mockImplementation(() => {
      return { filter: 'network, pop' };
    });
    await act(async () => {
      wrapper = mount(<WebMapView />);
    });
    wrapper.update();

    //await expect(setIsFilterSpy).toHaveBeenCalledWith(true);
    expect(displayGraphic).toHaveBeenCalled();
    await expect(setIsFilterSpy).toHaveBeenCalled();

    // expect(screen.find('FilterNodeProvider').length).toBe(1);
    // expect(screen.find('.collapsableList').length).toBe(1);
    //expect(wrapper.find('.collapsableList'))
    //expect(wrapper.props().children[0].props.value.filterList).toEqual(['network', 'pop']);
  });
});

describe('HighlightGraphic, MapEventListner', () => {
  let graphicLayerSpy;

  beforeEach(() => {
    jest.spyOn(graphicHandler, 'DisplayGraphics');
    graphicLayerSpy = jest
      .spyOn(helper, 'FindLayers')
      .mockImplementation(() => {
        return {
          id: 'graphicLayer',
          removeAll: jest.fn(),
          graphics: {
            items,
          },
        };
      });

    jest
      .spyOn(routeContext, 'useAppDataContext')
      .mockImplementation(() => appData);

    jest.spyOn(promise, 'loadMap').mockImplementation(() => {
      return Promise.resolve(_mapView);
    });
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should not call HighlightGraphic if there is no graphics', async () => {
    const _view = {
      hitTest: jest.fn(() =>
        Promise.resolve({
          results: [],
        })
      ),
    };
    const spy = jest.spyOn(map, 'HighlightGraphic');
    const event = {
      type: 'click',
    };

    await MapEventListner(_view, {}, event, jest.fn(), jest.fn());
    expect(spy).not.toHaveBeenCalled();
  });

  it('should not call HighlightGraphic if there is no graphics', async () => {
    const _view = {
      hitTest: jest.fn(() =>
        Promise.resolve({
          results: [
            {
              graphic: {
                clone: jest.fn(),
              },
            },
          ],
        })
      ),
    };
    const spy = jest.spyOn(map, 'HighlightGraphic');
    const event = {
      type: 'click',
    };

    await MapEventListner(_view, {}, event, jest.fn(), jest.fn());
    expect(spy).not.toHaveBeenCalled();
  });

  it('should change the graphic width to 3 if the symbol type is simple-line', () => {
    const graphic = {
      symbol: {
        type: 'simple-line',
        width: 1,
      },
    };

    const layer = {
      id: 'highlightedLayer',
      graphics: {
        add: jest.fn(),
      },
    };

    HighlightGraphic(graphic, layer);

    expect(graphic.symbol.width).toBeGreaterThanOrEqual(1);
    expect(layer.graphics.add).toHaveBeenCalled();
  });

  it('should change the graphic width and height to 32 if the symbol type is NOT simple-line', () => {
    const graphic = {
      symbol: {
        type: 'simple-marker',
        width: '2px',
        height: '2px',
      },
    };

    const layer = {
      id: 'highlightedLayer',
      graphics: {
        add: jest.fn(),
      },
    };
    HighlightGraphic(graphic, layer);

    expect(graphic.symbol.width).toBe('32px');
    expect(graphic.symbol.height).toBe('32px');
    expect(layer.graphics.add).toHaveBeenCalled();
  });

  it('should call HighlightGraphic with MapEventListner', async () => {
    const layer = {
      id: 'highlightedLayer',
      graphics: {
        add: jest.fn(),
        clone: jest.fn(),
      },
    };

    const view = _mapView.view;
    const spy = jest.spyOn(map, 'HighlightGraphic');
    const event = {
      type: 'click',
    };
    const modeSpy = jest.fn();
    const graphicSpy = jest.fn();

    await MapEventListner(view, layer, event, modeSpy, graphicSpy);

    expect(modeSpy).toHaveBeenCalled();
    expect(graphicSpy).toHaveBeenCalled();
    //expect(spy).toHaveBeenCalled();
  });

  it('should not call HighlightGraphic with MapEventListner if event is not click', async () => {
    const layer = {
      id: 'highlightedLayer',
      graphics: {
        add: jest.fn(),
        clone: jest.fn(),
      },
    };

    const view = _mapView.view;
    const spy = jest.spyOn(map, 'HighlightGraphic');
    const event = {
      type: 'notClick',
    };
    const modeSpy = jest.fn();
    const graphicSpy = jest.fn();

    await MapEventListner(view, layer, event, modeSpy, graphicSpy);

    expect(modeSpy).not.toHaveBeenCalled();
    expect(graphicSpy).not.toHaveBeenCalled();
    expect(spy).not.toHaveBeenCalled();
  });
});
