import React from 'react';
import { render, cleanup, act, waitForElement } from '@testing-library/react';
import Enzyme, { shallow, mount } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import App, { verifyKey } from '../../App';
const promise = require('utils/_gpServiceLoader');

Enzyme.configure({ adapter: new Adapter() });

describe('Unit testing App', () => {
  let wrapper;
  afterEach(cleanup);

  it('should render the webMapView if mode and host is legitimate', async () => {
    jest.spyOn(promise, 'verifyOKAPIAuthKey').mockImplementation(() => {
      return { key: 'testKey', error: false };
    });

    await act(async () => {
      wrapper = mount(<App />);
    });

    wrapper.update();
    expect(wrapper.find('.webMapView').length).toBe(1);
  });

  it('should show loder if it couldnt verify APIkey', () => {
    wrapper = shallow(<App />);
    expect(wrapper.find('WebMapView').length).toBe(0);
    expect(wrapper.find('.loader').length).toBe(1);
  });

  it('should return error if mode and host are not legitimate', async () => {
    jest.spyOn(promise, 'verifyOKAPIAuthKey').mockImplementation(() => {
      return Promise.resolve({ key: null, error: 'Invalid API token or mode' });
    });

    const response = await verifyKey('testKey', 'international');
    const result = { key: null, error: 'Invalid API token or mode' };
    expect(response).toMatchObject(result);
  });

  it('should return error if verifyOKAPIAuthKey promise fail', async () => {
    jest.spyOn(promise, 'verifyOKAPIAuthKey').mockImplementation(() => {
      return Promise.reject({ error: 'error' });
    });

    const response = await verifyKey('testKey', 'international');
    const result = {
      error: 'Error validating your API Token. Please try after some time.',
    };
    expect(response).toMatchObject(result);
  });
});
