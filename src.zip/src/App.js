import React, { useEffect, useState } from 'react';
import { WebMapView } from './components/Map';
import { apiUrl } from 'utils/_hosts';
import { verifyOKAPIAuthKey } from 'utils/_gpServiceLoader';
import { Loader } from 'components/view/Loader';
import { FetchQueryParam } from 'components/helper/Helper';
import './App.css';

import { AppDataProvider } from 'utils/_context';

function App() {
  const [_apiKey, setAPIKey] = useState(null);
  const query = FetchQueryParam();
  const mode = query.mode || window.mode;
  const apiKey = query.key || window.key;

  useEffect(() => {
    const verifyAPIKey = async () => {
      const okapiKey = await verifyKey(apiKey, mode);
      setAPIKey(okapiKey);
    };
    verifyAPIKey();
  }, [apiKey, mode]);

  return (
    <AppDataProvider value={{ apiKey }}>
      <div className="App">
        {_apiKey && !_apiKey.error ? (
          <WebMapView className="webMapView" />
        ) : (
          <Loader className="loader" />
        )}
      </div>
    </AppDataProvider>
  );
}

export const verifyKey = async (apiKey, mode) => {
  let params = {
    p1:
      window.parent !== window
        ? document.referrer.split('/').slice(0, 3).join('/')
        : window.location.origin,
    m1: mode,
  };

  try {
    let okapiKey = await verifyOKAPIAuthKey(
      apiUrl + '/auth/mapui',
      params,
      apiKey
    );
    //let error = !okapiKey && 'Invalid API token or mode'
    return { key: okapiKey.key, error: okapiKey.error };
  } catch (err) {
    return {
      error: 'Error validating your API Token. Please try after some time.',
    };
  }
};

export default App;
