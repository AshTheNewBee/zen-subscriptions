import React, { useEffect, useRef } from 'react';
import {
  ModeProvider,
  useAppDataContext,
  RouteListProvider,
  GraphicDataProvider,
} from 'utils/_context';
import { Loader } from 'components/view/Loader';
import { FetchQueryParam, FindLayers } from 'components/helper/Helper';
import { loadMap, resetMap } from 'utils/esri/EsriLoader';
import { center } from 'utils/_map';
import { Header } from 'components/view/AppBar';
import { DisplayGraphics } from 'components/controller/GraphicHandler';
import { regionList } from 'utils/data/_routes';

import 'stylesheets/_map.scss';

export const updateList = (toAppend, list, itemValue, setState) => {
  if (toAppend) {
    if (!list.includes(itemValue)) {
      setState((oldArray) => [...oldArray, itemValue]);
    }
  } else {
    setState((oldArray) => {
      return oldArray.filter((word) => word !== itemValue);
    });
  }
};

export const WebMapView = () => {
  //below [states and setStates] pairs has to be in below order for spies to work in unit tests
  const [mode, setMode] = React.useState(false);
  const [checkedList, setCheckedList] = React.useState(['all']);
  const [expandedList, setExpandedList] = React.useState(['all']);
  const [mapView, setMapView] = React.useState(null);
  const [isLoaded, setIsLoaded] = React.useState(false);
  const [isFiltered, setIsFiltered] = React.useState(false);

  const [graphicData, setGraphicData] = React.useState(null);

  const { apiKey } = useAppDataContext();
  const mapRef = useRef();

  const handleCheckedList = (itemValue, eventValue) => {
    if (eventValue === 1) {
      updateList(true, checkedList, itemValue, setCheckedList);
    } else {
      updateList(false, checkedList, itemValue, setCheckedList);
    }
  };
  const handleExpandedList = (itemValue, eventValue) => {
    if (eventValue) {
      updateList(true, checkedList, itemValue, setExpandedList);
    } else {
      updateList(false, checkedList, itemValue, setExpandedList);
    }
  };

  useEffect(() => {
    loadMap(mapRef).then(async (_mapView) => {
      const query = FetchQueryParam();
      const _filterList =
        query.filter &&
        query.filter
          .replace(/\s*,\s*/g, ',')
          .toLowerCase()
          .split(',');

      setMapView(_mapView);
      await DisplayGraphics(_mapView, apiKey).then(() => {
        setIsLoaded(true);
      });

      if (_filterList) {
        setCheckedList(_filterList);
        setIsFiltered(true);
        setMode('filter');
      }
      let satelliteLayer = FindLayers(_mapView.map, 'satelliteLayer');
      _mapView.map.layers.reorder(satelliteLayer, 1);
    });
  }, [apiKey]);

  useEffect(() => {
    if (mapView) {
      displaySelectedGraphics(mapView, checkedList);
    }
  }, [checkedList]);

  useEffect(() => {
    if (mode === 'reset') {
      setCheckedList(['all']);
      setExpandedList(['all']);
      if (mapView) {
        displaySelectedGraphics(mapView, checkedList);
        mapView.view.center !== center && resetMap(mapView.view);
        setMode(false);
      }
    }
  }, [mode]);

  if (mapView) {
    let highlightedLayer = FindLayers(mapView.map, 'highlightedLayer');
    highlightedLayer && highlightedLayer.removeAll();

    mapView.view.on('click', (event) => {
      highlightedLayer &&
        MapEventListner(
          mapView.view,
          highlightedLayer,
          event,
          setMode,
          setGraphicData
        );
    });

    // mapView.view.on('pointer-move', (event) => {
    //   highlightedLayer && highlightedLayer.removeAll();
    //   MapEventListner(mapView.view, highlightedLayer, event)
    // })
  }

  return (
    <div className="mapContainer">
      <RouteListProvider
        value={{
          checkedList,
          handleCheckedList,
          expandedList,
          handleExpandedList,
          isFiltered,
        }}
      >
        <GraphicDataProvider value={{ graphicData }}>
          <ModeProvider value={{ mode, setMode }}>
            <Header />
          </ModeProvider>
        </GraphicDataProvider>
      </RouteListProvider>
      <div className="webmap" id="viewDiv" ref={mapRef} />
      {!isLoaded && <Loader className="graphicLoader" />}
    </div>
  );
};

export const HighlightGraphic = (graphic, layer) => {
  graphic.symbol.type === 'simple-line'
    ? (graphic.symbol.width = 2)
    : (graphic.symbol.width = '32px');
  graphic.symbol.height = '32px';

  layer.graphics.add(graphic);
};

export const MapEventListner = (
  view,
  highlightedLayer,
  event,
  setMode,
  setGraphicData
) => {
  view.hitTest(event).then((response) => {
    if (response.results.length > 0) {
      let _graphic = response.results[0].graphic;
      let clonedGraphic = _graphic.clone();

      if (_graphic.symbol) {
        HighlightGraphic(clonedGraphic, highlightedLayer);

        if (
          event.type === 'click' &&
          _graphic.attributes._type !== 'network-point'
        ) {
          setMode('graphicData');
          setGraphicData(_graphic.attributes);
        }
      }
    }
  });
};

export const displaySelectedGraphics = (mapView, checkedList) => {
  let showGraphicsByType, showGraphicsByRegion;
  const showSatLayer =
    checkedList[0] === 'all' || checkedList.includes('infra-sat-coverage');
  FindLayers(mapView.map, 'satelliteLayer').visible = showSatLayer;

  let layer = FindLayers(mapView.map, 'graphicLayer');

  const emptyRegions = checkedList.every((item) => {
    return !regionList.includes(item);
  });

  layer.graphics.items.forEach((graphic) => {
    if (checkedList[0] === 'all') {
      //|| checkedList.length === 142
      graphic.visible = true;
    } else {
      showGraphicsByType = graphic.attributes.typeList
        ? graphic.attributes.typeList.some((typeItem) =>
            checkedList.includes(typeItem._id)
          )
        : checkedList.includes(graphic.attributes._id);

      showGraphicsByRegion = graphic.attributes.region.some((region) => {
        return checkedList.includes(region) && showGraphicsByType;
      });

      graphic.visible = emptyRegions
        ? showGraphicsByType
        : showGraphicsByRegion;
    }
  });
};
