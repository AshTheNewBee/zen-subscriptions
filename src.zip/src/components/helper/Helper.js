export const FetchQueryParam = () => {
  const qs = require('qs');
  const query = qs.parse(window.location.search, { ignoreQueryPrefix: true });
  return query;
};

export const FindLayers = (map, layerToFind) => {
  const found = map.layers.items.find((layer) => {
    return layer.id === layerToFind;
  });
  return found;
};
