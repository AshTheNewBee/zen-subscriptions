import { getGPResponse } from 'utils/_gpServiceLoader';
import {
  createPointGraphic,
  createPollyLineGraphic,
} from 'utils/esri/EsriLoader';
import { FindLayers } from 'components/helper/Helper';
import { flattenRenderNodes } from 'components/content/FilterFunctions';
import { routeFilters } from 'utils/data/_routes';

export const DisplayGraphics = async (mapView, apiKey) => {
  let renderNodes;
  renderNodes = flattenRenderNodes(renderNodes, routeFilters);

  await Promise.all(
    renderNodes.map(async (node) => {
      if (node.loadGraphicData && node.dataType.includes('point')) {
        await renderGraphics(
          mapView,
          apiKey,
          node.value,
          'point',
          node.label
        ).catch((err) =>
          console.error('error occured while fetching and creating Point Data')
        );
      }
      if (node.loadGraphicData && node.dataType.includes('line')) {
        await renderGraphics(
          mapView,
          apiKey,
          node.value,
          'line',
          node.label
        ).catch((err) =>
          console.error('error occured while fetching and creating Line Data')
        );
      }
    })
  );
};

export const renderGraphics = async (
  mapView,
  apiKey,
  feature,
  type,
  featureType
) => {
  const response = await getGPResponse(apiKey, {
    feature: feature,
    type: type,
    featureType: featureType,
  });

  type === 'point'
    ? await renderPointGraphics(response, mapView)
    : await renderLineGraphics(response, mapView);
};

export const renderPointGraphics = async (pointResponse, mapView) => {
  let layer = FindLayers(mapView.map, 'graphicLayer');

  pointResponse.results.forEach((item) => {
    let pointArr = item.value;

    pointArr &&
      pointArr.forEach(async (point) => {
        const graphic = await createPointGraphic(point).catch((err) =>
          console.error('error occured while fetching PoP data')
        );
        layer && layer.graphics.add(graphic);
      });
  });
};

export const renderLineGraphics = async (lineResponse, mapView) => {
  let layer = FindLayers(mapView.map, 'graphicLayer');
  lineResponse.results.forEach((item) => {
    let LineArr = item.value;

    LineArr &&
      LineArr.forEach(async (line) => {
        const graphic = await createPollyLineGraphic(line).catch((err) =>
          console.error('error occured while fetching cable data')
        );
        layer && layer.graphics.add(graphic);
      });
  });
};
