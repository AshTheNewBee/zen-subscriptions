import React, { useState } from 'react';
import { getGPResponse } from '../../../utils/_gpServiceLoader';
import { createPolygonGraphic } from '../../../utils/esri/EsriLoader';
const apiKey = 'DM1PCHMBnOOdCWv2fN3-';

/******************
 * @AllCountries
 *  Retrieve all the courntries which has Cloud Collaboration Coverage
 *  returns the list of courntries which has Cloud Collaboration Coverage
 *******************/
export const AllCountries = () => {
  return new Promise((resolve, reject) => {
    getGPResponse('infra/ccc/getAllCountries', { id: apiKey }, apiKey)
      .then((res) => {
        resolve(res.results[0].value);
      })
      .catch((err) => {
        console.error('error occured while fetching the countries');
        reject(err);
      });
  });
};

/******************
 * @CreateCountryPolygon
 *  Retrieve all CCC countries
 *  for each CCC country, retrieve country polygon data
 *  then call createPolygonGraphic to create and get the graphic.
 *  When graphic is retrieved, adds it to map view to display the graphics
 *******************/
export const CreateCCCPolygon = async (mapView) => {
  const countries = await AllCountries();
  return new Promise((resolve, reject) => {
    try {
      countries.length > 0 &&
        countries.forEach((country) => {
          getGPResponse(
            'infra/ccc/getCountriesById',
            { id: country.id },
            apiKey
          )
            .then((res) => {
              const value = res.results[0].value[0];
              return value;
            })
            .then((res) => {
              createPolygonGraphic(res).then((graphic) => {
                mapView.view.graphics.addMany([graphic]);
                resolve(mapView);
              });
            });
        });
    } catch (err) {
      console.error('error occured while fetching the polygon for country');
      reject(err);
    }
  });
};
