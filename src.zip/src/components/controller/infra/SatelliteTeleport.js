import { MapImage } from '../../../utils/esri/EsriLoader';

export const SatelliteTeleport = (mapView) => {
  return new Promise((resolve, reject) => {
    let mapViewLayer = MapImage();
    mapView.map.add(mapViewLayer);
  });
};
