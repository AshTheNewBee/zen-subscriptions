import { getGPResponse } from '../../../utils/_gpServiceLoader';
import {
  createPollyLineGraphic,
  createPointGraphic,
} from '../../../utils/esri/EsriLoader';

export const GetCables = (mapView, cableID) => {
  return new Promise((resolve, reject) => {
    getGPResponse('infra/getLinesById', {
      cableId: cableID, //'cable-aag',//'cable-ac-1',
    })
      .then((res) => {
        return res.results[0].value[0];
      })
      .then(async (res) => {
        await createPoints(res.properties, mapView);

        createPollyLineGraphic(res).then(([pollyLine]) => {
          mapView.view.graphics.addMany([pollyLine]);
          resolve(mapView);
        });
      })
      .catch((err) => {
        console.error('error occured while fetching the cables', err);
        reject(err);
      });
  });
};

const createPoints = (properties, mapView) => {
  const cableId = properties.label;

  return new Promise((resolve, reject) => {
    getGPResponse('infra/nodes', { cableId: cableId })
      .then((res) => {
        const pointsArr = res.results[0].value;
        pointsArr.forEach((point) => {
          createPointGraphic(point, properties).then((graphic) => {
            mapView.view.graphics.addMany([graphic]);
            resolve(mapView);
          });
        });
      })
      .catch((err) => {
        console.error('error occured while fetching the points', err);
        reject(err);
      });
  });
};

export const GetAllCables = (mapView) => {
  return new Promise((resolve, reject) => {
    getGPResponse('infra/getAllLines')
      .then((res) => {
        const linesArr = res.results[0].value;
        linesArr.forEach((line) => {
          createPollyLineGraphic(line).then(([graphic]) => {
            mapView.view.graphics.addMany([graphic]);
            resolve(mapView);
          });
        });
      })
      .catch((err) => {
        console.error('error occured while fetching the countries', err);
        reject(err);
      });
  });
};
