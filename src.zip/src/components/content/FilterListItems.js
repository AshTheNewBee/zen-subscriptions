import React, { useState, useEffect } from 'react';
import {
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Checkbox,
  Collapse,
  Divider,
} from '@material-ui/core';
import AddIcon from '@material-ui/icons/Add';
import RemoveIcon from '@material-ui/icons/Remove';
import ExpandLessIcon from '@material-ui/icons/ExpandLess';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import 'stylesheets/components/content/_filterListItem.scss';
import { useAppDataContext } from 'utils/_context';

import {
  FilterNodeProvider,
  useFilterNodeContext,
  useRouteListContext,
} from 'utils/_context';
import { flattenFilterNodes } from 'components/content/FilterFunctions';
import { routeFilters } from 'utils/data/_routes';
import { KeyListItem } from './Keys';
import { triggerNewRelicAction } from 'utils/_newRelicReporting';

export const FilterListItems = (props) => {
  const {
    checkedList,
    handleCheckedList,
    expandedList,
    handleExpandedList,
    isFiltered,
  } = useRouteListContext();
  let filterNodes;

  filterNodes = flattenFilterNodes(filterNodes, routeFilters);
  const [state, setState] = useState(filterNodes);

  const handleChange = (
    itemValue,
    eventKey,
    eventValue,
    updateParent = true
  ) => {
    let item = state[itemValue];

    if (item) {
      item[eventKey] = eventValue;

      setState((prevState) => ({
        ...prevState,
        [itemValue]: item,
      }));

      eventKey === 'expanded' && handleExpandedList(itemValue, eventValue);

      if (eventKey === 'checked') {
        const _item = state[itemValue];

        !(isFiltered || checkedList.includes('all')) &&
          _item.hasPartners &&
          _item.partners.forEach((partner) => {
            handleCheckedList(partner, eventValue);
            const partnerStateItem = state[partner];
            partnerStateItem[eventKey] = eventValue;

            setState((prevState) => ({
              ...prevState,
              [partner]: partnerStateItem,
            }));

            if (updateParent && partnerStateItem.isChild) {
              toggleParentStatus(
                partnerStateItem.parent.value,
                eventKey,
                eventValue
              );
            }
            toggleChildren(partnerStateItem, eventKey, eventValue, false);
          });

        if (eventValue === 1 && !_item.isParent) {
          handleCheckedList(itemValue, eventValue);
        } else {
          handleCheckedList(itemValue, 0);
        }

        toggleChildren(_item, eventKey, eventValue);
        if (updateParent && _item.isChild) {
          toggleParentStatus(_item.parent.value, eventKey, eventValue);
        }
      }
    } else {
      console.error('Incorrect selection');
    }
  };

  const toggleChildren = (_item, eventKey, eventValue, updateParent) => {
    _item.isParent &&
      _item.children.forEach((child) => {
        handleChange(child.value, eventKey, eventValue, updateParent);
      });
  };

  const toggleParentStatus = (itemValue, eventKey, eventValue) => {
    const parentEventValue = isEveryChildChecked(itemValue, eventValue)
      ? eventValue
      : 2;
    let item = state[itemValue];
    item[eventKey] = parentEventValue;
    setState((prevState) => ({
      ...prevState,
      [itemValue]: item,
    }));
    if (item.isChild) {
      toggleParentStatus(item.parent.value, eventKey, eventValue);
    }
  };

  const isEveryChildChecked = (itemValue, eventValue) => {
    const item = state[itemValue];
    return item.children.every(
      (child) => state[child.value].checked === eventValue
    );
  };

  useEffect(() => {
    checkedList.forEach((item) => {
      handleChange(item, 'checked', 1);
    });
    expandedList.forEach((item) => {
      handleChange(item, 'expanded', true);
    });
  }, []);

  return (
    <FilterNodeProvider value={{ state, handleChange }}>
      {props.mode === 'filter' ? (
        <CollapsableList
          filterTree={routeFilters}
          className="collapsableList"
        />
      ) : (
        <KeyListItem className="keyComponent" />
      )}
    </FilterNodeProvider>
  );
};

export const CollapsableList = (props) => {
  const { filterTree } = props;
  const { state } = useFilterNodeContext();

  return filterTree.map((item, i) => {
    const node = state[item.value];
    return (
      <React.Fragment key={i}>
        <FilterListItem item={node} className="filterListItem" />
        {node.showDivider && <Divider className="divider" />}
        {node.children && (
          <Collapse in={node.expanded} timeout="auto" className="collapse">
            <List component="div" className="list" disablePadding>
              <CollapsableList filterTree={node.children} />
            </List>
          </Collapse>
        )}
      </React.Fragment>
    );
  });
};

export const FilterListItem = (props) => {
  const { state } = useFilterNodeContext();
  const node = state[props.item.value];
  return (
    <ListItem
      className={`listItem listItem_${node.treeDepth} listItem_${node.value}`}
      key={node.value}
    >
      {node.showCheckBox !== false && (
        <FilterCheckBox node={node} className="filterCheckBox" />
      )}
      <ListItemText primary={node.label} className="listItemText" />
      {node.children && (
        <FilterListIcons
          nodeValue={node.value}
          nodeExpanded={node.expanded}
          nodeDepth={node.treeDepth}
          className="filterListIcons"
        />
      )}
    </ListItem>
  );
};

export const FilterListIcons = (props) => {
  const { apiKey } = useAppDataContext();
  const { nodeValue, nodeExpanded, nodeDepth } = props;
  const { handleChange } = useFilterNodeContext();

  return nodeExpanded ? (
    <ListItemIcon className="children remove">
      {nodeDepth === 1 ? (
        <RemoveIcon
          className="removeIcon"
          onClick={() => {
            handleChange(nodeValue, 'expanded', !nodeExpanded);
            triggerNewRelicAction(
              'Filter Panel',
              nodeValue,
              'mousclick',
              'cable',
              apiKey,
              ''
            );
          }}
        />
      ) : (
        nodeDepth > 1 && (
          <ExpandLessIcon
            className="lessIcon"
            onClick={() => {
              handleChange(nodeValue, 'expanded', !nodeExpanded);
              triggerNewRelicAction(
                'Filter Panel',
                nodeValue,
                'mousclick',
                'cable',
                apiKey,
                ''
              );
            }}
          />
        )
      )}
    </ListItemIcon>
  ) : (
    <ListItemIcon className="children add">
      {nodeDepth === 1 ? (
        <AddIcon
          className="addIcon"
          onClick={() => {
            handleChange(nodeValue, 'expanded', !nodeExpanded);
            triggerNewRelicAction(
              'Filter Panel',
              nodeValue,
              'mousclick',
              'cable',
              apiKey,
              ''
            );
          }}
        />
      ) : (
        nodeDepth > 1 && (
          <ExpandMoreIcon
            className="moreIcon"
            onClick={() => {
              handleChange(nodeValue, 'expanded', !nodeExpanded);
              triggerNewRelicAction(
                'Filter Panel',
                nodeValue,
                'mousclick',
                'cable',
                apiKey,
                ''
              );
            }}
          />
        )
      )}
    </ListItemIcon>
  );
};

export const FilterCheckBox = (props) => {
  const { apiKey } = useAppDataContext();
  const { node } = props;
  const { handleChange } = useFilterNodeContext();
  return (
    <Checkbox
      disableRipple
      className="filterCheckBox"
      value={node.value}
      onChange={(event) => {
        handleChange(node.value, 'checked', event.target.checked ? 1 : 0);
        event.target.checked === true
          ? triggerNewRelicAction(
              'Filter Panel',
              'checked ' + node.value,
              'mousclick',
              'cable',
              apiKey,
              ''
            )
          : triggerNewRelicAction(
              'Filter Panel',
              'unchecked ' + node.value,
              'mousclick',
              'cable',
              apiKey,
              ''
            );
      }}
      color="primary"
      checked={node.checked === 1 ? true : false}
      indeterminate={node.checked === 2 ? true : false}
    />
  );
};
