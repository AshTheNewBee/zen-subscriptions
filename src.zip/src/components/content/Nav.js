import React from 'react';
import { CardComp } from 'components/view/Card';
import { FilterListItems } from './FilterListItems';
import { GraphicData, GraphicTitle, GraphicSubTitle } from './GraphicData';

import ClearIcon from '@material-ui/icons/Clear';
import { ListComp } from 'components/view/List';
import { IconButton } from '@material-ui/core';

import { useModeContext } from 'utils/_context';

export const Nav = (props) => {
  const filterContent = (
    <ListComp
      className="filterList"
      listItems={<FilterListItems mode={props.mode} />}
    />
  );

  return (
    props.mode !== 'reset' &&
    (props.mode === 'graphicData' ? (
      <CardComp
        className="graphicDataComp"
        subtitle={GraphicSubTitle()}
        title={GraphicTitle()}
        content={<GraphicData />}
        action={CloseAction}
      />
    ) : (
      <CardComp
        className="cardComp"
        title={props.mode === 'filter' ? 'Filter map content' : 'Key'}
        content={filterContent}
        action={CloseAction}
      />
    ))
  );
};

export const CloseAction = () => {
  const { setMode } = useModeContext();
  return (
    <IconButton
      aria-label="settings"
      className="closeBtn"
      onClick={() => {
        setMode(false);
      }}
    >
      <ClearIcon />
    </IconButton>
  );
};
