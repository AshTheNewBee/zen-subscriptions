import React from 'react';
import { useFilterNodeContext } from 'utils/_context';
import { findIcon } from 'utils/data/_iconFinder';

import { ListItem, ListItemText, ListItemIcon } from '@material-ui/core';
import Icon from '@material-ui/core/Icon';

import 'stylesheets/components/content/_filterListItem.scss';

export const KeyListItem = () => {
  const { state } = useFilterNodeContext();
  let keyList = [];

  for (let key in state) {
    if (
      state[key].icon &&
      state[key].checked !== 0 &&
      !keyList.includes(state[key].label)
    ) {
      keyList.push(state[key].label);
    }
  }

  keyList.includes('Cable System') &&
    keyList.unshift(
      'Landing Station',
      'Telstra Core Network',
      'Telstra Core Network (Planned)',
      'Telstra Extended Network'
    ) &&
    keyList.splice(keyList.indexOf('Cable System'), 1);

  return keyList.map((key, i) => {
    const icon = findIcon(key);
    return (
      <ListItem className="keyListItem" key={i}>
        <ListItemIcon className="listItemIcon">
          <Icon>
            <img src={icon} alt={key} className={key} />
          </Icon>
        </ListItemIcon>
        <ListItemText className="key" primary={key} />
      </ListItem>
    );
  });
};
