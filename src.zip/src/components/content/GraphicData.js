/* eslint-disable no-undef */
import React from 'react';
import { useGraphicDataContext } from 'utils/_context';

import {
  ListItem,
  ListItemText,
  ListItemIcon,
  Typography,
  Link,
} from '@material-ui/core';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import 'stylesheets/components/content/_filterListItem.scss';

export const GraphicData = () => {
  const processedData = ProcessGraphicData();
  return (
    <React.Fragment>
      {processedData &&
        Object.entries(processedData).map(([key, value]) => {
          return (
            <ListItem className="graphicDataListItem" key={key}>
              <ListItemText
                className="graphicTxt"
                primary={key}
                secondary={
                  <Typography
                    variant="h5"
                    className="graphicData"
                    gutterBottom
                    color="textSecondary"
                  >
                    {value}
                  </Typography>
                }
              />
            </ListItem>
          );
        })}
    </React.Fragment>
  );
};

export const GraphicSubTitle = () => {
  const { graphicData } = useGraphicDataContext();
  return graphicData && `${graphicData?._featureType}`;
};

export const GraphicTitle = () => {
  const { graphicData } = useGraphicDataContext();
  return graphicData?.label && `${graphicData.label}`;
};

export const ProcessGraphicData = () => {
  const { graphicData } = useGraphicDataContext();

  if (graphicData) {
    let processedData = {
      location: graphicData?.country && graphicData.country,
    };

    switch (graphicData._type) {
      case 'other-office-point':
        processedData = {
          address: graphicData.address,
        };
        return processedData;

      case 'pop-pops-point':
        let _productList = [];

        graphicData.typeList.forEach((product) => {
          _productList = [..._productList, product.label];
        });

        processedData = {
          products: _productList.toString(),
          location: `${graphicData.country}`,
        };

        if (graphicData.address && graphicData.address !== '-')
          processedData.address = graphicData.address;
        return processedData;

      case 'network-line':
        processedData = {
          name: `${graphicData.name}`,
          length: graphicData.length,
          'Fibre Pairs': graphicData.fibrepairs,
        };
        return processedData;

      case 'media-line':
        const capacity = graphicData?.capacity && `${graphicData.capacity}`;
        processedData = {
          capacity: capacity,
        };
        return (
          (graphicData?.capacity || graphicData?.location) && processedData
        );

      default:
        return processedData;
    }
  }
};
