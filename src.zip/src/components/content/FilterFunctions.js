export const flattenFilterNodes = (
  filterNodes = {},
  nodes,
  parent = {},
  depth = 0
) => {
  if (!Array.isArray(nodes) || nodes.length === 0) {
    return;
  }
  nodes.forEach((node, index) => {
    const isParent = Array.isArray(node.children);
    filterNodes[node.value] = {
      checked: 0,
      value: node.value,
      label: node.label,
      icon: node.icon,
      isChild: parent.value !== undefined,
      isParent,
      parent,
      children: node.children,
      showCheckbox: node.showCheckbox !== undefined ? node.showCheckbox : true,
      showDivider: node.showDivider !== undefined ? node.showDivider : false,
      expanded: node.expanded !== undefined ? node.expanded : false,
      treeDepth: depth,
      index,
      partners: node.partners,
      hasPartners: node.hasPartners,
    };
    flattenFilterNodes(filterNodes, node.children, node, depth + 1);
  });
  return filterNodes;
};

export const flattenRenderNodes = (renderNodes = [], nodes) => {
  if (!Array.isArray(nodes) || nodes.length === 0) {
    return;
  }
  nodes.forEach((node, index) => {
    if (node.loadGraphicData || node.loadMapData) {
      renderNodes.push({
        index,
        value: node.value,
        label: node.label,
        loadGraphicData: node.loadGraphicData,
        loadMapData: node.loadMapData,
        dataType: node.dataType,
      });
    }
    flattenRenderNodes(renderNodes, node.children, node);
  });
  return renderNodes;
};

// export const FilterReducer = (state, action) => {
//   const newState = update(state, {
//     [action.fieldName]: {
//       [action.key]: {
//         $set: action.payload,
//       },
//     },
//   });
//   return newState;
// };
