import React from 'react';
import { Card, CardHeader, CardContent, Typography } from '@material-ui/core';
import 'stylesheets/view/_card.scss';

export const CardComp = (props) => {
  const { subtitle, title, content, action } = props;
  return (
    <Card className="card">
      <CardHeader className="cardHeader" action={action()} />
      <CardContent className="cardContent">
        {subtitle && (
          <Typography variant="h6" component="h2" className="subtitle">
            {subtitle}
          </Typography>
        )}
        <Typography variant="h5" component="h2" className="title">
          {title}
        </Typography>
        <Typography variant="h5" component="h2" className="content">
          {content}
        </Typography>
      </CardContent>
    </Card>
  );
};
