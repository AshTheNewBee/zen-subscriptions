import React from 'react';
import { loaderSymbol } from 'utils/_images';

export const Loader = () => {
  return (
    <img className="loader" id="loader" alt="loading" src={loaderSymbol} />
  );
};
