import React from 'react';
import { Nav } from 'components/content/Nav';
import { useModeContext, useAppDataContext } from 'utils/_context';

import { AppBar, Typography, Toolbar, Button } from '@material-ui/core';
import CachedOutlinedIcon from '@material-ui/icons/CachedOutlined';
import FilterListOutlinedIcon from '@material-ui/icons/FilterListOutlined';
import MapOutlinedIcon from '@material-ui/icons/MapOutlined';
import 'stylesheets/view/_appBar.scss';
import { triggerNewRelicAction } from 'utils/_newRelicReporting';

export const Header = (props) => {
  const { apiKey } = useAppDataContext();
  const { mode, setMode } = useModeContext();
  return (
    <React.Fragment>
      <AppBar className="appBar" position="static" color="transparent">
        <Toolbar className="toolbar">
          <Button
            aria-label="menu"
            className="appIcnbtn filter"
            onClick={() => {
              setMode('filter');
              triggerNewRelicAction(
                'Navigation Bar',
                'Filter Map Button',
                'mousclick',
                mode,
                apiKey,
                ''
              );
            }}
          >
            <FilterListOutlinedIcon className="appIcon" id="FilterListIcon" />
            <Typography variant="subtitle1" id="filterTxt">
              Filter map
            </Typography>
          </Button>

          <Button
            aria-label="menu"
            className="appIcnbtn key"
            onClick={() => {
              setMode('key');
              triggerNewRelicAction(
                'Navigation Bar',
                'Key Button',
                'mousclick',
                mode,
                apiKey,
                ''
              );
            }}
          >
            <MapOutlinedIcon className="appIcon" id="MapIcon" />
            <Typography variant="subtitle1" id="keyTxt">
              Key
            </Typography>
          </Button>

          <Button
            edge="end"
            className="appIcnbtn reset"
            onClick={() => {
              setMode('reset');
              triggerNewRelicAction(
                'Navigation Bar',
                'Reset Button',
                'mousclick',
                mode,
                apiKey,
                ''
              );
            }}
          >
            <CachedOutlinedIcon className="appIcon" id="CachedIcon" />
            <Typography variant="subtitle1" id="resetTxt">
              Reset map, view and filters
            </Typography>
          </Button>
        </Toolbar>
      </AppBar>
      {mode && <Nav mode={mode} className="nav" />}
    </React.Fragment>
  );
};
