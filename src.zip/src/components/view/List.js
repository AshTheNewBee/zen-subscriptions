import React from 'react';
import { List } from '@material-ui/core';

export const ListComp = (props) => {
  return (
    <List component="nav" aria-label="list" className="list">
      {props.listItems}
    </List>
  );
};
