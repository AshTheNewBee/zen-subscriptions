export const state = {
  all: {
    checked: 0,
    value: 'all',
    label: 'all',
    isChild: true,
    isParent: true,
    parent: {
      value: 'all',
      label: 'Select all',
      showCheckBox: false,
      showDivider: true,
      expanded: true,
      children: [[Object], [Object], [Object], [Object], [Object], [Object]],
    },
    showCheckbox: true,
    showDivider: false,
    expanded: false,
    treeDepth: 1,
    index: 0,
  },
};

export const stateWithChildren = {
  all: {
    checked: 0,
    value: 'all',
    label: 'all',
    isChild: true,
    isParent: true,
    parent: {
      value: 'all',
      label: 'Select all',
      showCheckBox: true,
      showDivider: true,
      expanded: true,
      children: [[Object], [Object], [Object], [Object], [Object], [Object]],
    },
    children: [{ value: 'sub-network1', label: 'Overland Cables' }],
    showCheckbox: true,
    showDivider: false,
    expanded: false,
    treeDepth: 1,
    index: 0,
  },

  'sub-network1': {
    checked: 0,
    value: 'sub-network1',
    label: 'sub-network1',
    isChild: true,
    isParent: true,
    parent: {
      value: 'all',
      label: 'Select all',
      showCheckBox: false,
      showDivider: true,
      expanded: true,
      children: [[Object], [Object], [Object], [Object], [Object], [Object]],
    },
    showCheckbox: true,
    showDivider: true,
    expanded: false,
    treeDepth: 1,
    index: 0,
  },
};

export const stateWithCables = {
  CableSystem: {
    checked: 0,
    value: 'Cable System',
    label: 'Cable System',
    isChild: true,
    isParent: true,
    parent: {
      value: 'all',
      label: 'Select all',
      showCheckBox: false,
      showDivider: true,
      expanded: true,
      children: [[Object], [Object], [Object], [Object], [Object], [Object]],
    },
    showCheckbox: true,
    showDivider: false,
    expanded: false,
    treeDepth: 1,
    index: 0,
  },
};

export const checkedState = {
  all: {
    checked: 1,
    value: 'all',
    label: 'all',
    isChild: true,
    isParent: true,
    parent: {
      value: 'all',
      label: 'Select all',
      showCheckBox: false,
      showDivider: true,
      expanded: true,
      children: [[Object], [Object], [Object], [Object], [Object], [Object]],
    },
    showCheckbox: true,
    showDivider: false,
    expanded: false,
    treeDepth: 1,
    index: 0,
    icon: true,
  },
};

export const graphicAttr = {
  address: 'testAddress',
  city: 'testCity',
  country: 'Indonesia',
  label: 'Indonesia',
  type: 'office',
  _featureType: 'Office',
  _type: 'other-office-point',
  _id: 'Office',
};

export const graphicAttrTPN = {
  address: 'testAddress',
  city: 'testCity',
  country: 'Indonesia',
  label: 'Indonesia',
  type: 'tpn',
  _type: 'TPN',
  _id: 'TPN',
  _featureType: 'TPN',
};

//   city: ""
// country: "Maldives"
// label: "E110"
// region: (2) ["Asia", "APAC"]
// typeList: ["sub-pop-internet"]
// _id: "pop-pops"
// _type: "pop-pops-point"
export const graphicAttrPoP = {
  type: 'pop',
  address: 'testAddress',
  city: 'testCity',
  country: 'Indonesia',
  label: 'Indonesia',
  _type: 'pop-pops-point',
  _featureType: 'pop-pops',
  typeList: [
    {
      _id: 'IPVPN',
      label: 'IPVPN',
    },
  ],
  _id: 'pop-pops',
};

export const graphicAttrPoPemptyAddress = {
  type: 'pop',
  address: 'testAddress',
  city: 'testCity',
  country: 'Indonesia',
  label: 'Indonesia',
  _type: 'pop-pops-point',
  _featureType: 'pop-pops',
  typeList: [
    {
      _id: 'IPVPN',
      label: 'IPVPN',
    },
  ],
  _id: 'pop-pops',
};

export const graphicAttrCloudNode = {
  address: 'testAddress',
  city: 'testCity',
  country: 'Indonesia',
  label: 'Indonesia',
  type: 'cloudnodes',
  _type: 'cloud Nodes',
  _featureType: 'cloud Nodes',
  _id: 'cloudnodes',
};

export const graphicAttrColocations = {
  address: 'testAddress',
  city: 'testCity',
  country: 'Indonesia',
  label: 'Indonesia',
  type: 'colocations',
  _featureType: 'colocations',
  _type: 'Co-Location',
  _id: 'id',
};

export const graphicAttrTeleports = {
  address: 'testAddress',
  city: 'testCity',
  country: 'Indonesia',
  label: 'Indonesia',
  type: 'teleports',
  _featureType: 'teleports',
  _type: 'Satellite Teleports',
};

export const graphicAttrDefault = {
  address: 'testAddress',
  city: 'testCity',
  country: 'Indonesia',
  label: 'Indonesia',
  type: 'other',
  _featureType: 'other',
  _type: 'other',
};

export const graphicAttrCable = {
  address: 'testAddress',
  type: 'Submarine Cable',
  _type: 'network-line',
  _featureType: 'network',
  label: 'testCity',
  fibrepairs: '10',
  location: 'testCity',
  length: '2453 mts',
  _id: 'cable-aag',
  name: 'cableName',
};

export const graphicAttrDataCentre = {
  address: 'testAddress',
  type: 'DataCentre',
  city: 'testCity',
  country: 'Indonesia',
  label: 'Indonesia',
  _type: 'Data Centre',
  _featureType: 'Data Centre',
};

//MAPVIEW

export const items = [
  {
    attributes: {
      networkid: 'testNetworkId-1',
      _id: 'testNetworkId-1',
      region: ['Asia', 'APAC'],
    },
    visible: false, //jest.fn().mockReturnValue(mockVisible),
    getAttribute: jest.fn().mockReturnValue('testNetworkId-1'),
  },
  {
    attributes: {
      networkid: 'testNetworkId-2',
      _id: 'testNetworkId-2',
      region: ['Asia', 'APAC'],
    },
    visible: true,
    getAttribute: jest.fn().mockReturnValue('testNetworkId-2'),
  },
  {
    typeList: [
      {
        _id: 'IPVPN',
        label: 'IPVPN',
      },
      {
        _id: 'IPVPN2',
        label: '2',
      },
    ],
    attributes: {
      networkid: 'testNetworkId-3',
      _id: 'testNetworkId-3',
      type: 'pop',
      _type: '_type',
      typeList: ['_type'],
      region: ['Asia', 'APAC'],
    },
    visible: false, //jest.fn().mockReturnValue(mockVisible),
    getAttribute: jest.fn().mockReturnValue('testNetworkId-3'),
  },
];

// export const layers = [
//   {
//     id: 'satelliteLayer',
//     visible: true,
//     removeAll: jest.fn(),
//   },
//   {
//     id: 'graphicLayer',
//     removeAll: jest.fn(),
//   },
//   {
//     id: 'highlightedLayer',
//     removeAll: jest.fn(),
//   },
// ];

export const layers = {
  items: [
    {
      id: 'satelliteLayer',
      visible: true,
      removeAll: jest.fn(),
    },
    {
      id: 'graphicLayer',
      removeAll: jest.fn(),
    },
    {
      id: 'highlightedLayer',
      removeAll: jest.fn(),
    },
  ],
  reorder: jest.fn(),
};

export const _map = {
  layers,
  find: jest.fn().mockImplementation(() => layers.items),
  graphics: {
    add: jest.fn(),
  },
};

export const graphic = {
  graphic: {
    attributes: {
      address: '4 Parsons St, Alice Springs, NT',
      countries: 'Australia',
      location: 'Alice Springs, NT',
      type: 'pop',
    },
    symbol: {
      type: 'simple-line',
    },
    clone: jest.fn().mockImplementation(() => graphic.graphic),
  },
};

export const _mapView = {
  view: {
    center: [112.86539062499608, -17.856691508017956],
    graphics: items,
    //on: jest.fn().when('click').then({ type: 'click'}),
    on: jest.fn().mockImplementation(() => {
      return {
        type: 'click',
        x: 1349,
        y: 133,
      };
    }),
    goTo: jest.fn(),
    hitTest: jest.fn(() =>
      Promise.resolve({
        results: [graphic],
      })
    ),
    hitList: jest.fn().mockImplementation(() => {
      return {
        results: [
          {
            graphic: graphicAttr,
          },
        ],
      };
    }),
    whenLayerView: jest.fn().mockImplementation(() => {
      return {
        highlight: jest.fn(),
        remove: jest.fn(),
      };
    }),
  },
  map: _map,
};

export const _mapPopView = {
  view: {
    graphics: items,
    //on: jest.fn().when('click').then({ type: 'click'}),
    on: jest.fn(),
    hitList: jest.fn().mockImplementation(() => {
      return {
        results: [
          {
            graphic: graphicAttrPoP,
          },
        ],
      };
    }),
  },
  map: _map,
};
