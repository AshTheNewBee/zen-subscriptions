export const loaderSymbol =
  process.env.PUBLIC_URL + '/assets/images/loader_lg.gif';

export const AUNextIP =
  process.env.PUBLIC_URL + '/assets/images/TGIcons/AUNextIP.svg';
export const broadcastFac =
  process.env.PUBLIC_URL + '/assets/images/TGIcons/broadcastFac.svg';

export const CCC = process.env.PUBLIC_URL + '/assets/images/TGIcons/CCC.svg';
export const cloudGateaway =
  process.env.PUBLIC_URL + '/assets/images/TGIcons/cloudGateaway.svg';
export const cloudNode =
  process.env.PUBLIC_URL + '/assets/images/TGIcons/cloudNode.svg';
export const coreNetwork =
  process.env.PUBLIC_URL + '/assets/images/TGIcons/coreNetwork.svg';
export const corePlanned =
  process.env.PUBLIC_URL + '/assets/images/TGIcons/corePlanned.svg';

export const PoP = process.env.PUBLIC_URL + '/assets/images/TGIcons/PoP.svg';
export const dataCentre =
  process.env.PUBLIC_URL + '/assets/images/TGIcons/dataCentre.svg';
export const extendedNetwork =
  process.env.PUBLIC_URL + '/assets/images/TGIcons/extendedNetwork.svg';
export const GMNPoP =
  process.env.PUBLIC_URL + '/assets/images/TGIcons/GMN-PoP.svg';
export const landingSt =
  process.env.PUBLIC_URL + '/assets/images/TGIcons/landingSt.svg';
export const NOC = process.env.PUBLIC_URL + '/assets/images/TGIcons/NOC.svg';
export const office =
  process.env.PUBLIC_URL + '/assets/images/TGIcons/office.svg';
export const serviceDesk =
  process.env.PUBLIC_URL + '/assets/images/TGIcons/serviceDesk.svg';

export const overlandCables =
  process.env.PUBLIC_URL + '/assets/images/TGIcons/overlandCables.svg';

export const partnerTeleport =
  process.env.PUBLIC_URL + '/assets/images/TGIcons/partnerTeleport.svg';
export const programmableNetwork =
  process.env.PUBLIC_URL + '/assets/images/TGIcons/programmableNetwork.svg';

export const satelliteCoverage =
  process.env.PUBLIC_URL + '/assets/images/TGIcons/satelliteCoverage.svg';
export const satelliteTeleport =
  process.env.PUBLIC_URL + '/assets/images/TGIcons/satelliteTeleport.svg';

export const SOC = process.env.PUBLIC_URL + '/assets/images/TGIcons/SOC.svg';
export const SIP = process.env.PUBLIC_URL + '/assets/images/TGIcons/SIP.svg';
