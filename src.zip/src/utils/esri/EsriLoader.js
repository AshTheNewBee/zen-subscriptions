import { loadModules } from 'esri-loader';
import { mdsLayers } from '../_hosts';
import { spatialReference, center, constraints } from '../_map';
import {
  simpleLineSymbol,
  simpleFillSymbol,
  pictureMarkerSymbol,
} from './_esriUtils';
import { satelliteLayer } from 'utils/_hosts';

/******************
 * @ref: https://developers.arcgis.com/javascript/latest/api-reference/esri-views-View.html
 * @loadMap
 * creates the map and load the map view at the ref's DOM node
 * returns the map and view components
 *  3D view : SceneView 2dView: MapView
 *******************/
export const loadMap = (ref) => {
  return new Promise((resolve, reject) => {
    loadModules(
      [
        'esri/Map',
        'esri/views/MapView',
        'esri/layers/WebTileLayer',
        'esri/Basemap',
      ],
      {
        css: true,
      }
    )
      .then(async ([Map, MapView, WebTileLayer]) => {
        const map = new Map();

        mdsLayers.forEach(function (l) {
          let mdslayer = new WebTileLayer(l.url, l.options);
          map.add(mdslayer);
        });

        const view = new MapView({
          container: ref.current,
          map: map,
          center: center,
          spatialReference: spatialReference,
          highlightOptions: {
            //color: '#0064D2',
            fillOpacity: 0,
            haloOpacity: 0.7,
          },
        });

        view.constraints = constraints;

        view.ui.move('zoom', 'bottom-right');

        addSatelliteLayer(map);
        addGraphicLayer(map, 'graphicLayer');
        addGraphicLayer(map, 'highlightedLayer');

        resolve({ map: map, view: view });
      })
      .catch((err) => {
        reject('error occured while loading the map');
      });
  });
};

export const addGraphicLayer = (map, layerName) => {
  loadModules(['esri/layers/GraphicsLayer']).then(async ([GraphicsLayer]) => {
    const layer = await new GraphicsLayer({
      id: layerName,
    });

    map.add(layer);
  });
};

export const resetMap = (view) => {
  view.goTo({
    center: center,
    zoom: 3,
  });
};

/******************
 * @addPolygon
 *  esValue: Polygon data set
 *  adds multi polygons as a single polygons to ringsArr
 *  creates graphics with simpleFillSymbol and attributes
 *  and returns the graphics
 *
 *******************/

export const createPolygonGraphic = (esValue) => {
  let polygon,
    ringsArr = [];
  const polygonRings = esValue.geometry.coordinates;
  const countryName = esValue.countryName;

  return new Promise((resolve, reject) => {
    try {
      loadModules(['esri/Graphic', 'esri/geometry/Polygon']).then(
        ([Graphic, Polygon]) => {
          polygonRings.forEach((rings) => {
            ringsArr = [...ringsArr, ...rings];
          });

          polygon = new Polygon({
            rings: ringsArr,
            spatialReference: { wkid: 4326 },
          });

          const polygonGraphic = new Graphic({
            geometry: polygon,
            symbol: simpleFillSymbol,
            attributes: countryName,
          });

          resolve(polygonGraphic);
        }
      );
    } catch (err) {
      console.error('error occured while creating the polygons', err);
      reject(err);
    }
  });
};

export const MapImage = () => {
  return new Promise((resolve, reject) => {
    try {
      loadModules([
        'esri/layers/support/MapImage',
        'esri/layers/MapImageLayer',
      ]).then(([MI, MapImageLayer]) => {
        // let mapImage = new MI({
        //   href:
        //     'https://www.telstraglobal.com/network-infrastructure-map/images/telstra-globe-texture-sc.png',
        //   spatialReference: { wkid: 4326 },
        //   extent: { xmin: -92.53, ymin: 27.361, xmax: -97.62, ymax: 31.575 },
        // });

        let layer = new MapImageLayer({
          id: 'image_layer',
          maxScale: 1000,
          url:
            'https://dev-services-gcm.sdpamp.com/arcgis/rest/services/satellite_image/MapServer',
        });

        //layer.addImage(mapImage);
        resolve(layer);
      });
    } catch (err) {
      console.error('error occured while adding satellite image overlay', err);
    }
  });
};

export const createPointGraphic = (
  esValue,
  symbol = 'markerSymbol',
  degree = 0
) => {
  const geom = esValue.geometry.coordinates;

  // let color = esValue.properties.color || '#0064D2';
  // const _symbol =
  //   symbol === 'markerSymbol'
  //     ? markerSymbol(color)
  //     : textSymbol(color, esValue.properties.label, degree);

  const _symbol = pictureMarkerSymbol(esValue.properties._type);

  return new Promise((resolve, reject) => {
    try {
      loadModules(['esri/Graphic']).then(([Graphic]) => {
        let point = {
          type: 'point',
          longitude: geom[0],
          latitude: geom[1],
        };

        let pointGraphic = new Graphic({
          geometry: point,
          symbol: _symbol,
          attributes: esValue.properties,
        });

        resolve(pointGraphic);
      });
    } catch (err) {
      console.error('error occured while creating the points', err);
      reject(err);
    }
  });
};

export const createPollyLineGraphic = (esValue) => {
  const polyLines = esValue.geometry.coordinates;
  return new Promise((resolve, reject) => {
    try {
      loadModules(['esri/Graphic']).then(async ([Graphic]) => {
        let polyline = {
          type: 'polyline',
          paths: polyLines,
        };
        let polylineGraphic = new Graphic({
          geometry: polyline,
          symbol: simpleLineSymbol(
            esValue.properties.stroke,
            esValue.properties.linetype
          ),
          attributes: esValue.properties,
          //popupTemplate: lineTemplate(),
        });

        resolve(polylineGraphic);
      });
    } catch (err) {
      console.error('error occured while creating the polygons', err);
      reject(err);
    }
  });
};

export function addSatelliteLayer(map) {
  return new Promise((resolve, reject) => {
    try {
      loadModules(['esri/layers/VectorTileLayer']).then(([VectorTileLayer]) => {
        const layer = new VectorTileLayer({
          id: 'satelliteLayer',
          visible: true,
          url: satelliteLayer,
          opacity: 0.25,
        });
        map.add(layer);
      });
    } catch (e) {
      console.error(e);
      reject(e);
    }
  });
}
