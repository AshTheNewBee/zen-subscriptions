import { findIcon } from 'utils/data/_iconFinder';

export const lineTemplate = () => {
  return {
    className: 'lineTemplate_{color}',
    declaredClass: 'lineTemplate',
    title: '{name}', //lineData[0].name,
    content: [
      {
        type: 'fields',
        fieldInfos: [
          {
            fieldName: 'label',
          },
          {
            fieldName: 'length',
            label: 'Approx. Length',
          },
          {
            fieldName: 'nodeCount',
            label: 'Fibre Pairs',
          },
        ],
      },
    ],
  };
};
//.esri-popup__header

export const simpleLineSymbol = (lineColor, lineType) => {
  const style = lineType === 'dashed' ? 'short-dot' : lineType;
  return {
    type: 'simple-line',
    color: lineColor,
    width: 1,
    style: style,
  };
};

export const simpleFillSymbol = {
  type: 'simple-fill',
  color: '#8A92C5',
  outline: {
    color: '#8A92C5',
    width: 1,
  },
};

export const markerSymbol = (color) => {
  return {
    type: 'simple-marker',
    color: color,
    size: '8px',
    outline: {
      color: color,
      width: 3,
    },
  };
};

export const textSymbol = (color, label, degree) => {
  return {
    type: 'text', // autocasts as new TextSymbol()
    color: color,
    text: label,
    xoffset: 0,
    yoffset: 5,
    angle: degree,
    horizontalAlignment: 'justify',
    verticalAlignment: 'bottom',
    font: {
      // autocasts as new Font()
      size: 8,
      family: 'sans-serif',
      weight: 'lighter',
    },
  };
};

export const zoomConfig = (zoomLevel) => {
  switch (zoomLevel) {
    case 7: {
      return 1;
    }
    case 6: {
      return 3;
    }
    case 5: {
      return 6;
    }
    case 4: {
      return 9;
    }
    case 3: {
      return 18;
    }
    default: {
      return 1;
    }
  }
};

export const pictureMarkerSymbol = (type) => {
  let icon = findIcon(type);
  return {
    type: 'picture-marker',
    url: icon,
    width: '24px',
    height: '24px',
    declaredClass: 'testClassIcon',
  };
};
