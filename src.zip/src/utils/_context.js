import React, { useContext } from 'react';

export const AppDataContext = React.createContext();
export const AppDataProvider = AppDataContext.Provider;
export const UseGoogleMapContext = () => useContext(AppDataContext);

export const ModeContext = React.createContext();
export const ModeProvider = ModeContext.Provider;
export const useModeContext = () => useContext(ModeContext);

export const RouteListContext = React.createContext();
export const RouteListProvider = RouteListContext.Provider;
export const useRouteListContext = () => useContext(RouteListContext);

export const FilterNodeContext = React.createContext();
export const FilterNodeProvider = FilterNodeContext.Provider;
export const useFilterNodeContext = () => useContext(FilterNodeContext);

export const GraphicDataContext = React.createContext();
export const GraphicDataProvider = GraphicDataContext.Provider;
export const useGraphicDataContext = () => useContext(GraphicDataContext);
