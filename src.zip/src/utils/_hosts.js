const http_protocol = 'https://';

//------------------- MDS API Data -------------------
const mdsData = {
  ApiUrl:
    http_protocol +
    'api{subDomain}.nowwhere.com.au/1.1.2/tile/58/{level}/{col}/{row}?key=',
  ApiKey: 'rHy6Z8Ee2gNrfd4W8I6ppfbvmjb216ZZgg5535su',
};

export const mdsLayers = [
  {
    options: {
      visible: true,
      subDomains: ['1', '2', '3', '4'],
      attribution: '2014 MapData Services',
    },
    url: mdsData.ApiUrl + mdsData.ApiKey,
  },
];

//------------------- Allowed domains which can use GCM prod API's -------------------
const client_prod_domains = [
  'tools.gcm.telstra.com.au',
  'www.telstra.com.au',
  'myservices.telstra.com.au',
  'nbnplus.service-now.com',
  'onesource.in.telstra.com.au',
  'onesource.inside.telstra.com',
  'boost.com.au',
  'lanes.telstra.com',
  'lanes.in.telstra.com.au',
  'author.telstrawholesale.com.au',
  'www.telstrawholesale.com.au',
  'mobilemaps.net.au',
  'communities.inside.telstra.com',
];

//------------------- client domains -------------------

function extractHostname(url) {
  let hostname;
  //find & remove protocol (http, ftp, etc.) and get hostname

  if (url.indexOf('://') > -1) {
    hostname = url.split('/')[2];
  } else {
    hostname = url.split('/')[0];
  }

  //find & remove port number
  hostname = hostname.split(':')[0];
  //find & remove "?"
  hostname = hostname.split('?')[0];

  return hostname;
}

function getRefHostname() {
  // Chech if iFrame, then return referrer else return hostname
  return window.parent !== window
    ? extractHostname(document.referrer + '<br/>')
    : window.location.hostname;
}

// const services_domain =
//   client_prod_domains.indexOf(getRefHostname()) >= 0
//     ? 'services.gcm.telstra.com.au'
//     : client_dev_domains.indexOf(getRefHostname()) >= 0
//     ? 'dev-services-gcm.sdpamp.com'
//     : 'test-services-gcm.sdpamp.com';
// const servicesUri =
//   client_prod_domains.indexOf(getRefHostname()) >= 0
//     ? '/arcgis/rest/services'
//     : client_dev_domains.indexOf(getRefHostname()) >= 0
//     ? '/arcgis/rest/services'
//     : '/gisserver/rest/services';

const api_domain =
  client_prod_domains.indexOf(getRefHostname()) >= 0
    ? 'tapi.telstra.com'
    : 'staging-tapi.telstra.com';

const client_dev_domains = [
  'localhost',
  'dev-maps.gcm.telstra.com.au',
  'dev-tools-gcm.sdpamp.com',
];

export const apiUrl =
  //'http://localhost:5000/services/gpservice/v1';
  http_protocol + api_domain + '/v1/gcm-geoprocessing-service';

// GCM service url for all Vector Tile services calls
const services_domain =
  client_prod_domains.indexOf(getRefHostname()) >= 0
    ? 'services.gcm.telstra.com.au'
    : client_dev_domains.indexOf(getRefHostname()) >= 0
    ? 'dev-services-gcm.sdpamp.com'
    : 'test-services-gcm.sdpamp.com';
const servicesUri =
  client_prod_domains.indexOf(getRefHostname()) >= 0
    ? '/arcgis/rest/services'
    : client_dev_domains.indexOf(getRefHostname()) >= 0
    ? '/arcgis/rest/services'
    : '/gisserver/rest/services';

export const servicesUrl = http_protocol + services_domain + servicesUri;

export const satelliteLayer = `${http_protocol}${services_domain}/arcgis/rest/services/Hosted/Satelite_Coverage/VectorTileServer`;
