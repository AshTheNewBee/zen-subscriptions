// New Relic add action events
export function triggerNewRelicAction(
  actionName,
  actionValue,
  triggerType,
  mode,
  apiKey,
  inputAddress = null
) {
  window.newrelic &&
    window.newrelic.addPageAction(actionName, {
      version: 'v1',
      mode: mode,
      apiKey: apiKey,
      actionValue: actionValue,
      result: 'success',
      triggerType: triggerType,
      inputAddress: inputAddress,
    });
}
