import { apiUrl } from 'utils/_hosts';

export async function verifyOKAPIAuthKey(url, params, apiKey) {
  try {
    const response = await fetch(
      url,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          apikey: apiKey,
        },
        body: JSON.stringify(params),
      },
      []
    );
    return response.status === 200
      ? { apiKey: apiKey }
      : { error: 'Invalid API token or mode' };
  } catch (error) {
    return { error: error };
  }
}

export async function loadServices(service) {
  switch (service) {
    case 'routes':
      return await 'routeDetails';
    case 'pop':
      return await 'offices';
    default:
      return;
  }
}

export const getGPResponse = async (apikey, params = '') => {
  const gpResponse = await fetch(
    apiUrl + '/telstraglobal/features',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        apikey: apikey,
      },
      body: JSON.stringify(params),
    },
    []
  );

  if (gpResponse.ok) {
    return gpResponse.json();
  } else {
    let err = new Error(gpResponse.statusText);
    err.response = gpResponse;
    console.error('error connecting to gpService');
    return err;
  }
};
