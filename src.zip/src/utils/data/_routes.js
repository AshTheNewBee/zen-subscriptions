//0=uncheck 1=check 2=partial
export const routeFilters = [
  {
    value: 'all',
    label: 'Select all',
    showCheckBox: false,
    showDivider: true,
    expanded: true,
    children: [
      {
        value: 'network',
        label: 'network',
        loadGraphicData: true,
        dataType: ['point', 'line'],
        partners: ['infra-sat-teleports' /*, 'other-boc'*/],
        hasPartners: true,
        children: [
          {
            value: 'network-subsea',
            label: 'Cable System',
            icon: true,
            showCheckbox: false,
            children: [
              {
                value: 'cable-aae1',
                label: 'AAE-1',
              },
              {
                value: 'cable-aag',
                label: 'AAG',
              },
              {
                value: 'cable-ac-1',
                label: 'AC-1',
              },
              {
                value: 'cable-ac-2',
                label: 'AC-2/Yellow',
              },
              {
                value: 'cable-ajc',
                label: 'AJC',
              },
              {
                value: 'cable-apcn2',
                label: 'APCN-2',
              },
              {
                value: 'cable-apng2',
                label: 'APNG-2',
              },
              {
                value: 'cable-apollo',
                label: 'Apollo',
              },
              {
                value: 'cable-strait-1',
                label: 'Bass Strait-1',
              },
              {
                value: 'cable-strait-2',
                label: 'Bass Strait-2',
              },
              {
                value: 'cable-bbg',
                label: 'BBG',
              },
              {
                value: 'cable-c2c',
                label: 'C2C',
              },
              {
                value: 'cable-eac',
                label: 'EAC',
              },
              {
                value: 'cable-eig',
                label: 'EIG',
              },
              {
                value: 'cable-endeavour',
                label: 'Endeavour',
              },
              {
                value: 'cable-fa1',
                label: 'FA-1',
              },
              {
                value: 'cable-faster',
                label: 'FASTER',
              },
              {
                value: 'cable-flag',
                label: 'FEA',
              },
              {
                value: 'cable-gondwana-1',
                label: 'Gondwana-1',
              },
              {
                value: 'cable-hawaiki',
                label: 'HAWAIKI',
              },
              {
                value: 'cable-hka',
                label: 'HKA',
              },
              {
                value: 'cable-i2i',
                label: 'i2i, i2icn',
              },
              {
                value: 'cable-indigo',
                label: 'Indigo West',
              },
              {
                value: 'cable-jakabare',
                label: 'JAKABARE',
              },
              {
                value: 'cable-japan-us',
                label: 'JUS',
              },
              {
                value: 'cable-matrix',
                label: 'Matrix',
              },
              {
                value: 'cable-ncp',
                label: 'NCP',
              },
              {
                value: 'cable-pacific-crossing-1',
                label: 'PC-1',
              },
              {
                value: 'cable-pan-am',
                label: 'Pan-Am',
              },
              {
                value: 'cable-plcn',
                label: 'PLCN',
              },
              {
                value: 'cable-ppc-1',
                label: 'PPC-1',
              },
              {
                value: 'cable-rnal',
                label: 'RNAL/FNAL',
              },
              {
                value: 'cable-safe',
                label: 'SAFE',
              },
              {
                value: 'cable-safe-sat3',
                label: 'SAT3/WASC',
              },
              {
                value: 'cable-smw3',
                label: 'SeaMeWe3, SMW3',
              },
              {
                value: 'cable-smw4',
                label: 'SeaMeWe4, SMW4',
              },
              {
                value: 'cable-smw5',
                label: 'SeaMeWe5, SMW5',
              },
              {
                value: 'cable-southern-cross',
                label: 'Southern Cross, SCCN',
              },
              {
                value: 'cable-tasman-2',
                label: 'TGA',
              },
              {
                value: 'cable-tgn-ia',
                label: 'TGN-IA',
              },
              {
                value: 'cable-tgn-pacific',
                label: 'TGN-Pacific',
              },
              {
                value: 'cable-tgn-tata',
                label: 'TGN-Tata Indicom',
              },
              {
                value: 'cable-unity',
                label: 'Unity (EAC-Pacific)',
              },
              {
                value: 'cable-wacs',
                label: 'WACS',
              },
            ],
          },
          {
            value: 'cable-backhaul-tw',
            label: 'Overland Cables',
            icon: true,
          },
        ],
      },
      {
        value: 'pop',
        label: 'Points of Presence',
        icon: true,
        children: [
          {
            value: 'pop-pops',
            label: 'Points of Presence',
            loadGraphicData: true,
            dataType: ['point'],
            showCheckbox: false,
            children: [
              {
                value: 'sub-pop-ipvpn',
                label: 'IPVPN',
              },
              {
                value: 'sub-pop-ipl-epl',
                label: 'Point to Point (IPL/EPL)',
              },
              {
                value: 'sub-pop-eplx',
                label: 'EPLX',
              },
              {
                value: 'sub-pop-evpn',
                label: 'EVPN (VPLS/EVPL)',
              },
              {
                value: 'sub-pop-internet',
                label: 'Internet (GID/IPT)',
              },
            ],
          },
          {
            value: 'pop-tpn',
            label: 'Programmable Network',
            loadGraphicData: true,
            dataType: ['point'],
            icon: true,
          },
          {
            value: 'pop-colocation',
            label: 'Colocations',
            loadGraphicData: true,
            dataType: ['point'],
            icon: true,
          },
        ],
      },
      {
        value: 'infra',
        label: 'Infrastructure',
        children: [
          {
            value: 'infra-data-centre',
            label: 'Data Centres',
            loadGraphicData: true,
            dataType: ['point'],
            icon: true,
            showCheckBox: false,
            children: [
              {
                value: 'Australia',
                label: 'Australia',
                children: [
                  {
                    value: 'Equinix SY3',
                    label: 'Sydney Equinix DC 3',
                  },
                  {
                    value: 'Broadway',
                    label: 'Broadway DC',
                  },
                  {
                    value: 'Equinix SY1',
                    label: 'Equinix SY1 DC',
                  },
                  {
                    value: 'Equinix SY4',
                    label: 'Equinix SY4 DC',
                  },
                  {
                    value: 'Clayton DC',
                    label: 'Clayton DC',
                  },
                  {
                    value: 'St. Leonard DC',
                    label: 'St. Leonard DC',
                  },
                  {
                    value: 'S1',
                    label: 'Sydney NextDC DC',
                  },
                  {
                    value: 'M1/MECS1',
                    label: 'Melbourne NextDC DC',
                  },
                  {
                    value: 'B1',
                    label: 'Brisbane NextDC DC',
                  },
                  {
                    value: 'C1',
                    label: 'Canberra NextDC DC',
                  },
                  {
                    value: 'P1',
                    label: 'Perth NextDC DC',
                  },
                  {
                    value: 'SYD1',
                    label: 'Sydney Metronode DC 1',
                  },
                  {
                    value: 'SYD2',
                    label: 'Sydney Metronode DC 2',
                  },
                  {
                    value: 'MEL1',
                    label: 'Melbourne Metronode DC 1',
                  },
                  {
                    value: 'MEL2',
                    label: 'Melbourne Metronode DC 2',
                  },
                  {
                    value: 'PER1',
                    label: 'Perth Metronode DC 1',
                  },
                  {
                    value: 'PER2',
                    label: 'Perth Metronode DC 2',
                  },
                  {
                    value: 'CAN1',
                    label: 'Canberra Metronode DC',
                  },
                  {
                    value: 'BRS1',
                    label: 'Brisbane Metronode DC',
                  },
                  {
                    value: 'ADE1',
                    label: 'Adelaide Metronode DC',
                  },
                  {
                    value: 'ME1',
                    label: 'Melbourne Equinix DC',
                  },
                  {
                    value: 'SY1',
                    label: 'Sydney Equinix DC 1',
                  },
                  {
                    value: 'SY2',
                    label: 'Sydney Equinix DC 2',
                  },
                  {
                    value: 'A1',
                    label: 'Adelaide DC',
                  },
                  {
                    value: 'Ed Parks',
                    label: 'Ed Parks DC',
                  },
                  {
                    value: 'Hawthorn',
                    label: 'Hawthorn DC',
                  },
                  {
                    value: 'Pulse DC',
                    label: 'Pulse DC',
                  },
                ],
              },
              {
                value: 'Hong Kong',
                label: 'Hong Kong',
                children: [
                  {
                    value: 'Equinix HK1',
                    label: 'Tsuen Wan DC',
                  },
                  {
                    value: 'HKCS2',
                    label: 'Hong Kong DC 2',
                  },
                  {
                    value: 'Equinix HK2',
                    label: 'Kwai Chung DC',
                  },
                  {
                    value: 'Equinix HK2',
                    label: 'Tseung Kwan DC',
                  },
                ],
              },
              {
                value: 'Japan',
                label: 'Japan',
                children: [
                  {
                    value: 'Equinix TY3',
                    label: 'Equinix TY3 DC',
                  },
                  {
                    value: 'TKDS1',
                    label: 'Tokyo DC 1',
                  },
                  {
                    value: 'Equinix OS1',
                    label: 'Equinix OS1 DC',
                  },
                  {
                    value: 'Equinix TY8',
                    label: 'Equinix TY8 DC',
                  },
                ],
              },
              // {
              //   value: 'Philippines',
              //   label: 'Philippines',
              //   children: [
              //     {
              //       value: 'IPC',
              //       label: 'IPC DC',
              //     },
              //   ],
              // },
              {
                value: 'Singapore',
                label: 'Singapore',
                children: [
                  // {
                  //   value: 'Epsilon',
                  //   label: 'Epsilon DC',
                  // },
                  {
                    value: 'Equinix SG1',
                    label: 'Equinix SG1 DC',
                  },
                  {
                    value: 'Equinix SG2',
                    label: 'Equinix SG2 DC',
                  },
                  {
                    value: 'Equinix SG3',
                    label: 'Equinix SG3 DC',
                  },
                  {
                    value: 'SGCS1',
                    label: 'Changi DC',
                  },
                  {
                    value: 'SGCS2',
                    label: '110 Paya Lebar DC',
                  },
                  // {
                  //   value: 'SGDS1',
                  //   label: 'Tai Seng DC',
                  // },
                ],
              },
              {
                value: 'New Zealand',
                label: 'New Zealand',
                children: [
                  {
                    value: 'Albany',
                    label: 'Albany DC',
                  },
                ],
              },
              {
                value: 'United Kingdom',
                label: 'United Kingdom',
                children: [
                  {
                    value: 'Docklands Hosting Centre',
                    label: 'Docklands Hosting Centre',
                  },
                  {
                    value: 'Equinix LD7',
                    label: 'Equinix LD7 DC',
                  },
                  {
                    value: 'Equinix LD9',
                    label: 'Equinix LD9 DC',
                  },
                ],
              },
              {
                value: 'United States',
                label: 'United States',
                children: [
                  {
                    value: 'Equinix CH4',
                    label: 'Equinix CH4 DC',
                  },
                  {
                    value: 'Equinix LA1',
                    label: 'Equinix LA1 DC',
                  },
                  {
                    value: 'Equinix NY4',
                    label: 'Equinix NY4 DC',
                  },
                  {
                    value: 'Equinix NY5',
                    label: 'Equinix NY5 DC',
                  },
                  {
                    value: 'Equinix SV5',
                    label: 'Equinix SV5 DC',
                  },
                  {
                    value: 'Equinix SV2',
                    label: 'Equinix SV2 DC',
                  },
                  // {
                  //   value: 'Coresite NY2',
                  //   label: 'Coresite NY2 DC',
                  // },
                ],
              },
              {
                value: 'China',
                label: 'China',
                children: [
                  {
                    value: 'BJDS1',
                    label: 'Beijing DC',
                  },
                  {
                    value: 'CQCS1',
                    label: 'Chongqing DC',
                  },
                  {
                    value: 'SHDS2',
                    label: 'Shanghai DC 1',
                  },
                  {
                    value: 'SZDS1',
                    label: 'Shenzhen DC',
                  },
                  {
                    value: 'TJCS1',
                    label: 'Tianjin DC',
                  },
                  {
                    value: 'Equinix SH1',
                    label: 'Equinix SH1 DC',
                  },
                  {
                    value: 'Shanghai IDX DC',
                    label: 'Shanghai DC 2',
                  },
                  {
                    value: 'Chayora DC',
                    label: 'Chayora DC',
                  },
                ],
              },
              {
                value: 'Swedan',
                label: 'Swedan',
                children: [
                  {
                    value: 'Equinix SK2',
                    label: 'Equinix SK2 DC',
                  },
                ],
              },
              {
                value: 'France',
                label: 'France, Paris',
                children: [
                  {
                    value: 'Equinix PA4',
                    label: 'Equinix PA4 DC',
                  },
                  {
                    value: 'Equinix PA6',
                    label: 'Equinix PA6 DC',
                  },
                ],
              },
              {
                value: 'Korea',
                label: 'Korea',
                children: [
                  {
                    value: 'SEDS1',
                    label: 'Seoul DC',
                  },
                ],
              },
              {
                value: 'Malaysia',
                label: 'Malaysia',
                children: [
                  {
                    value: 'KLDS2',
                    label: 'Kuala Lumpur DC',
                  },
                ],
              },
              {
                value: 'Taiwan',
                label: 'Taiwan',
                children: [
                  {
                    value: 'TPDS1',
                    label: 'Taipei DC',
                  },
                ],
              },
            ],
          },
          {
            value: 'infra-cloud-nodes',
            label: 'Cloud Node',
            loadGraphicData: true,
            dataType: ['point'],
            icon: true,
          },
          {
            value: 'infra-sat-teleports',
            label: 'Satellite Teleports',
            loadGraphicData: true,
            dataType: ['point'],
            icon: true,
            hasPartners: true,
            partners: ['infra-sat-coverage'],
          },
          {
            value: 'infra-sat-coverage',
            label: 'Satellite Coverage',
            mapData: true,
            icon: true,
            hasPartners: true,
            partners: ['infra-sat-teleports'],
          },
          {
            value: 'infra-partner-teleports',
            label: 'Partner Teleports',
            loadGraphicData: true,
            dataType: ['point'],
            icon: true,
          },
          /*
          {
            value: 'infra-ccc',
            label: 'Cloud Collaboration Coverage',
            icon: true,
          },
          {
            value: 'infra-cloud-gateway',
            label: 'Cloud Gateway',
            icon: true,
          },
          {
            value: 'infra-sip',
            label: 'Session Initiation Protocol (SIP) Connect',
            icon: true,
          },
          */
        ],
      },
      {
        value: 'other',
        label: 'Other',
        children: [
          {
            value: 'other-office',
            label: 'Office',
            loadGraphicData: true,
            dataType: ['point'],
            icon: true,
          },
          /*
          {
            value: 'other-noc',
            label: 'Network Operations Centre',
            icon: true,
          },
          {
            value: 'other-soc',
            label: 'Security Operation Centre',
            icon: true,
          },
          {
            value: 'other-boc',
            label: 'Broadcast Facilities',
            icon: true,
          },
          {
            value: 'other-sd',
            label: 'Service Desk',
            icon: true,
          },
          */
        ],
      },
      {
        value: 'media',
        label: 'Global Media Network',
        loadGraphicData: true,
        dataType: ['point', 'line'],
        icon: true,
        partners: ['infra-sat-teleports' /*, 'other-boc'*/],
        hasPartners: true,
      },
      {
        value: 'search',
        label: 'Filter by Region',
        children: [
          {
            value: 'Africa',
            label: 'Africa',
          },
          {
            value: 'Americas',
            label: 'Americas',
          },
          {
            value: 'APAC',
            label: 'APAC',
          },
          {
            value: 'Asia',
            label: 'Asia',
          },
          {
            value: 'Europe',
            label: 'Europe',
          },
          {
            value: 'Middle East',
            label: 'Middle East',
          },
        ],
      },
    ],
  },
];

export const regionList = [
  'Africa',
  'Americas',
  'APAC',
  'Asia',
  'Europe',
  'Middle East',
];
