import {
  landingSt,
  coreNetwork,
  corePlanned,
  extendedNetwork,
  overlandCables,
  PoP,
  programmableNetwork,
  AUNextIP,
  //broadcastFac,
  //CCC,
  //cloudGateaway,
  cloudNode,
  dataCentre,
  GMNPoP,
  //NOC,
  office,
  //serviceDesk,
  partnerTeleport,
  satelliteCoverage,
  satelliteTeleport,
  //SOC,
  //SIP,
} from 'utils/_images';

export const findIcon = (type) => {
  switch (type) {
    case 'network-point':
      return landingSt;
    //############ Yet to be added
    case 'network-line':
    case 'Cable System':
    case 'Telstra Core Network':
      return coreNetwork;
    case 'Telstra Core Network (Planned)':
      return corePlanned;
    case 'Telstra Extended Network':
      return extendedNetwork;
    //##########
    case 'Overland Cables':
      return overlandCables;

    case 'pop-pops-point':
    case 'Points of Presence':
    case 'Points Of Presence':
      return PoP;
    case 'pop-tpn-point':
    case 'Programmable Network':
      return programmableNetwork;
    case 'pop-colocation-point':
    case 'Colocations':
      return AUNextIP;

    case 'infra-data-centre-point':
    case 'Data Centres':
      return dataCentre;
    case 'infra-cloud-nodes-point':
    case 'Cloud Node':
      return cloudNode;
    case 'infra-sat-teleports-point':
    case 'Satellite Teleports':
      return satelliteTeleport;
    case 'Satellite Coverage-map':
      return satelliteCoverage;
    case 'infra-partner-teleports-point':
    case 'Partner Teleports':
      return partnerTeleport;
    // case 'infra-ccc':
    //   return CCC;
    // case 'infra-cloud-gateway':
    //   return cloudGateaway;
    // case 'infra-sip':
    //   return SIP;

    case 'other-office-point':
    case 'Office':
      return office;
    // case 'other-noc':
    //   return NOC;
    // case 'other-soc':
    //   return SOC;
    // case 'other-boc':
    //   return broadcastFac;
    // case 'other-sd':
    //   return serviceDesk;

    case 'media-point':
    case 'Global Media Network':
      return GMNPoP;
    case 'media-line':
      return coreNetwork;

    default:
      return landingSt;
  }
};
